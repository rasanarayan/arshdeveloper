<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->auth->check_session();
        $this->load->model('validate');
        $this->load->model('users');
        $this->load->model('binary_model');
        $this->load->model('all_model');
        $this->load->model('dash_model');
        $this->load->model('add_product');
        $this->load->model('user_genaral');
        $this->load->model('transaction_model');
    }


	public function index()
	{
		$this->load->model('users');
		$data['page_title']	= 'Manage Associate';
		$data['agents'] 	= $this->users->all_agents('agent');
		//echo "<pre>"; print_r($data['agents']); die;
		//$data = $this->users->active_agent('AGENT5');
		//echo"<pre>"; print_r($data['agents']); die;
		$this->load->template('agent/index',$data);
	}
	
	public function pending_selling_agents()
	{
		
		$master						= $this->users->get_master(array('id'=>'1'));
		$data['page_title']			= 'Sales Pending Associate';
		$data['installment'] 		= $this->users->agent_pending_sell($master['agent_month']);
		
		for($i=0; $i< count($data['installment']); $i++)
		{
		$array[]     = $data['installment'][$i]['created_by'];
		}
	
		$data['agents']             = $this->users->all_agents_detail($array);
		$this->load->template('agent/agent_pending_sale',$data);
	}
	
	public function identity_print($id = false)
	{
		if($id)
		{
			
		$data['user'] = $this->users->get_user($id)[0];
		$data['detail'] = $this->users->agents_detail($id)[0];
		//echo"<pre>"; print_r($data['detail']); die;
		
		$this->load->view('agent/print',$data);
		}
		else
		{
			$this->session->set_flashdata('error', 'agent Not Found');
	        redirect(base_url().'num_sellers');
		}
	}

    public function view($id = false)
	{
		if($id)
		{
			if($this->users->get_user_with_type($id,'agent')[0])
			{
				$data['page_title']	= 'View Associate';
			    $data['user'] = $this->users->get_user($id)[0];
				$data['detail'] = $this->users->agent_detail($id)[0];
				$data['agent_id'] = $id;

				$data['total_reffered'] = $this->dash_model->total_reffered($data['user']['user_type_id']);
				$data['monthly_reffered'] = $this->dash_model->monthly_reffered($data['user']['user_type_id']);
				$data['total_sale'] = $this->dash_model->total_sale($id);
				$data['monthly_sale'] = $this->dash_model->monthly_sale($id);
				$data['total_direct_income'] = $this->dash_model->total_direct_income($id);
				$data['monthly_direct_income'] = $this->dash_model->monthly_direct_income($id);
				$data['total_indirect_income'] = $this->dash_model->total_indirect_income($id);
				$data['monthly_indirect_income'] = $this->dash_model->monthly_indirect_income($id);
				$data['total_bonus_income'] = $this->dash_model->total_bonus_income($id);
				$data['monthly_bonus_income'] = $this->dash_model->monthly_bonus_income($id);
				$data['total_promotion_income'] = $this->dash_model->total_promotion_income($id);
                $data['monthly_promotion_income'] = $this->dash_model->monthly_promotion_income($id);
                $data['withdraw'] = $this->dash_model->get_withdrawall($id,'agent');
				$data['user_login'] = $this->dash_model->get_user_login($id);
                $data['customer'] = $this->user_genaral->get_customer_detail_using_agent_id($data['agent_id']);
                $data['transactions'] = $this->transaction_model->get_transaction_by_id($id);
				$this->load->template('agent/view',$data);
			}	
			else
			{
				$this->session->set_flashdata('error', 'Associate Not Found');
	        	redirect(base_url().'agent');
			}
			
		}
		else
		{
			$this->session->set_flashdata('error', 'Associate Not Found');
	        redirect(base_url().'agent');
		}
	    
	}
	
	 public function block($id = false)
	{	
		if($id)
		{
			

				$this->db->where('id',$id);
				if($this->db->update('user',array('updated_by'  => 	$this->session->userdata('id'),'block_status' => '2' , 'block_time' =>date('Y-m-d H:i:s') )))
				{

					$this->session->set_flashdata('msg', 'Associate Successfully blocked');
	        		redirect(base_url().'agent');
				}
				else{
					$this->session->set_flashdata('error', 'Associatet Not blocked Try Again');
	        		redirect(base_url().'agent');
				}
			

		}
		else{
			$this->session->set_flashdata('error', 'Associate Not Found');
	        redirect(base_url().'agent');
		}
	}

  public function unblock($id = false)
	{	
		if($id)
		{
			

				$this->db->where('id',$id);
			if($this->db->update('user',array('updated_by'  => 	$this->session->userdata('id'),'block_status' => '1', 'unblock_time' =>date('Y-m-d H:i:s'))))
				{

					$this->session->set_flashdata('msg', 'Associate Successfully Unblocked');
	        		redirect(base_url().'agent');
				}
				else{
					$this->session->set_flashdata('error', 'Associate Not Unblocked Try Again');
	        		redirect(base_url().'agent');
				}
			

		}
		else{
			$this->session->set_flashdata('error', 'Associate Not Found');
	        redirect(base_url().'agent');
		}
	}		
	
	


    public function auto_compleate()
    {
        if($this->input->get('term'))
        {
            $this->db->like('user_type_id',$this->input->get('term'));
            $data = $this->db->get_where('user',['user_type' => 'agent','delete_flag' => 0])->result_array();

            $array = [];
            foreach ($data as $key => $value) {
                
                $array[] = ['value' => $value['user_type_id'],'label' => $value['user_type_id']];

            }
            echo json_encode($array);

        }
    }


	/*///////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Add Agent
	///////////////////////////////////////////////////////////////////////////////////////////////////////*/


	public function add()
	{	
	    $data['page_title']	= 'Add Associate';
	     $data['user'] = $this->users->get_users();
       //echo"<pre>"; print_r($data['user']); die;
		$this->load->template('agent/register',$data);
	}

	
	public function save()
	{
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		/******************************************************
					Login Details Set Rules
		******************************************************/
		$this->form_validation->set_rules('user_name', 'Username', 'trim|required|min_length[5]|max_length[10]|alpha_dash|is_unique[user.user_name]',array('is_unique' => 'Username Is Already Exists'));
		$this->form_validation->set_rules('ref', 'Reference Id','callback_RefId_Check');
		//$this->form_validation->set_rules('leg', 'Leg','callback_validate_leg['.$this->input->post('ref').']');
		$this->form_validation->set_rules('pass', 'Password', 'min_length[5]|required');
		$this->form_validation->set_rules('con_pass', 'Confirm Password', 'required|matches[pass]');
		$this->form_validation->set_rules('coust_id', 'Coustomer Id', 'min_length[5]|callback_Coustmer_id');
		/*****************************************************
					Personal Information Set Rules
		******************************************************/
		$this->form_validation->set_rules('gur_type', 'Select Gurdian Type', 'trim|required');
		$this->form_validation->set_rules('gur_name', 'Gurdian Name', 'trim|required|min_length[2]|max_length[250]');
		$this->form_validation->set_rules('fi_name', 'First Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('mi_name', 'Middle Name', 'trim');
		$this->form_validation->set_rules('la_name', 'Last Name', 'trim|min_length[2]|max_length[30]');
		//$this->form_validation->set_rules('fa_name', 'Father Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('mo_name', 'Mother Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('bdate', 'Birth Date', 'trim|required|callback_date_valid');
		$this->form_validation->set_rules('jdate', 'Joining Date', 'trim|required|callback_date_valid');
		$this->form_validation->set_rules('proof_type', 'Id Proof Type', 'trim|required|max_length[240]');
		$this->form_validation->set_rules('proof_num', 'Id Proof Number', 'trim|required|min_length[5]|max_length[240]');
		$this->form_validation->set_rules('quali', 'Qualification', 'trim|required|min_length[3]|max_length[100]');
		$this->form_validation->set_rules('desig', 'Designation', 'trim|required|min_length[3]|max_length[50]');
		/*****************************************************
					Contact information
		******************************************************/
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean|max_length[100]');
		$this->form_validation->set_rules('mobile', 'Mobile Number', 'required|regex_match[/^[0-9]{10}$/]|min_length[10]|max_length[10]');
		$this->form_validation->set_rules('mobile2', 'Mobile Number2', 'regex_match[/^[0-9]{10}$/]|min_length[10]|max_length[12]');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[10]|max_length[500]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		$this->form_validation->set_rules('zip', 'Zip code', 'trim|required|min_length[4]|max_length[10]');
		$this->form_validation->set_rules('state', 'State', 'trim|required|min_length[2]|max_length[50]');
		$this->form_validation->set_rules('year', 'Year', 'trim');
		$this->form_validation->set_rules('jdate', 'Jdate', 'trim');
		$this->form_validation->set_rules('sex', 'Sex', 'trim|required');
		/*****************************************************
					Bank Details
		******************************************************/
		$this->form_validation->set_rules('bank', 'Bank Name', 'trim|required|min_length[3]|max_length[50]');
		$this->form_validation->set_rules('ac_number', 'A/C Number', 'trim|required|alpha_numeric|min_length[8]|max_length[20]');
		$this->form_validation->set_rules('ifsc_code', 'IFSC Code', 'trim|required|alpha_numeric|min_length[5]|max_length[20]');
		$this->form_validation->set_rules('branch_name', 'Branch Name', 'trim|required|min_length[5]|max_length[50]');
		
		//Identity  Details Set Rules
		/******************************************************/
		//$this->form_validation->set_rules('profile','profile','required|trim|min_length[10]|max_length[20]');
		$this->form_validation->set_rules('description','description','required|trim|min_length[10]|max_length[150]');
        //$this->form_validation->set_rules('dob','Date of birth','required|trim');
		//$this->form_validation->set_rules('join_date','Joining date','required|trim');
		$this->form_validation->set_rules('expire_date','Expire date','required|trim');
		/*****************************************************/
		//	User Name 
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add Agent';
             $data['user'] = $this->users->get_users();
			$this->load->template('agent/register',$data);
		}
		else
		{ 
			$this->load->model('my_custom_func_model');
			$new_agent_id = $this->my_custom_func_model->get_user_type_id('agent');

			$user_insert = array(
								'user_type'           => 	'agent',
								'user_type_id'        => 	$new_agent_id,
								'user_name'           => 	strtolower($this->input->post('user_name')),
								'pass'                => 	md5($this->input->post('pass')),
								'email'               => 	$this->input->post('email'),
								'mobile'              => 	$this->input->post('mobile'),
								'reference_id'        => 	$this->input->post('ref'),
								'created_by'		  => 	$this->session->userdata('id'),
								'updated_by'		  => 	$this->session->userdata('id'),
								'created_at' 		  => 	date('Y-m-d H:i:s'),
								'updated_at' 		  => 	date('Y-m-d H:i:s')
								);

			if($this->db->insert('user', $user_insert))
			{	
					$insert_id = $this->db->insert_id();
					$binary = [
						'agent_id'        =>    $new_agent_id,	
						'parent'          =>    strtoupper($this->input->post('ref')),
				        'coustmer'		  => 	strtoupper($this->input->post('coust_id')),
						//'leg'          	  =>    $this->input->post('leg')
					];	
					$this->db->insert('binary', $binary);
					if($this->input->post('leg') == 'left')
					{	//echo "<pre>"; print_r('hidd'); die;
						$paruser = $this->users->get_user($this->input->post('ref'))[0];
						if($paruser['user_type'] == 'agent')
						{
							$paragent_details = $this->users->agent_detail($paruser['id'])[0];
							agent_left_leg($paragent_details['mobile'],$paragent_details['fi_name'],$new_agent_id,"-");
						}
					}
					else
					{	
						$paruser = $this->users->get_user_details($this->input->post('ref'))[0];
						if($paruser['user_type'] == 'agent')
						{
							$paragent_details = $this->users->agent_detail($paruser['id'])[0];
							agent_right_leg($paragent_details['mobile'],$paragent_details['fi_name'],$new_agent_id,"-");
						}
					}
					//echo "<pre>"; print_r('bye'); die;
					//$this->binary_model->update_parent_after_insert($new_agent_id,strtoupper($this->input->post('ref')),$this->input->post('leg'));
					$agent_insert = array(
										'fi_name'    		  => 	$this->input->post('fi_name'),
										'mi_name'         	  => 	$this->input->post('mi_name'),
										'la_name'			  => 	$this->input->post('la_name'),
										'fa_name'	 	      => 	$this->input->post('fa_name'),
										'mo_name'		      =>	$this->input->post('mo_name'),
										'bdate'		          =>	date('Y-m-d',strtotime($this->input->post('bdate'))),
										'jdate'		          =>	date('Y-m-d',strtotime($this->input->post('jdate'))),
										'year'		          =>	$this->input->post('year'),
										'proof_type'		  =>	$this->input->post('proof_type'),
										'proof_num'		      =>	strtoupper($this->input->post('proof_num')),
										'quali'		          =>	$this->input->post('quali'),
										'desig'		          =>	$this->input->post('desig'),
										'email'		          =>	$this->input->post('email'),
										'mobile'		      =>	$this->input->post('mobile'),
										'mobile2'		      =>	$this->input->post('mobile2'),
										'address'		      =>	$this->input->post('address'),
										'city'		          =>	$this->input->post('city'),
										'zip'		          =>	$this->input->post('zip'),
										'state'	              =>	$this->input->post('state'),
										'bank'		          =>	$this->input->post('bank'),
										'ac_number'		      =>	$this->input->post('ac_number'),
										'ifsc_code'		      =>	strtoupper($this->input->post('ifsc_code')),
										'branch_name'		  =>	$this->input->post('branch_name'),
										'user_id'		      =>	$insert_id,
										'sex'		  	  		=>	$this->input->post('sex'),
										'gur_type'			  => 	$this->input->post('gur_type'),
										'gur_name'			  => 	$this->input->post('gur_name'),
										'description'	      =>   	$this->input->post('description'),
										'expire_date'	      =>   	$this->input->post('expire_date'),
										);
				if($this->db->insert('agent_details', $agent_insert))
				{
                     if(!empty($_FILES['my_image']['name']) && !empty($_FILES['my_bar']['name']) && !empty($_FILES['my_qr']['name']))
					{
						$path = $_FILES['my_image']['name'];
						$newName = md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
						$config['upload_path']		= './uploads/';
						$config['allowed_types']	= 'gif|jpg|png|jpeg';
						$config['max_size']			= 1000000;
						
						$location = "uploads/sushant/";
						$file1 = $_FILES['my_bar']['name'];
						$file_tmp1 = $_FILES['my_bar']['tmp_name']; 
						
						$file2 = $_FILES['my_qr']['name'];
						$file_tmp2 = $_FILES['my_qr']['tmp_name']; 
						
						$config['file_name'] = $newName;
						$this->load->library('upload', $config);
						if($this->upload->do_upload('my_image'))
						{
							$image_path_compressed = image_thumb($newName, 300, 250);
							//print_r($image_path_compressed); die;

							$subadmin_insert = array(
								'image'    	  => 	$newName,
								'barcode'         =>     $file1,
								'qrcode'         =>     $file2,
							);

							move_uploaded_file($file_tmp1, $location.$file1);
							move_uploaded_file($file_tmp2, $location.$file2);
							$this->db->where('id', $insert_id);
							if($this->db->update('user', $subadmin_insert))
							{
								welcome($this->input->post('mobile'),strtolower($this->input->post('user_name')));
								$this->session->set_flashdata('msg', 'Agent Successfully Added');
	        					redirect(base_url().'agent');
							}
							else
							{
								welcome($this->input->post('mobile'),strtolower($this->input->post('user_name')));
								$this->session->set_flashdata('error', 'Agent Successfully Added - '.$this->upload->display_errors());
								unlink('./uploads/'.$newName);
								unlink('./uploads/thumb/'.$newName);
	        					redirect(base_url().'agent');
							}
						}
						else
						{
							welcome($this->input->post('mobile'),strtolower($this->input->post('user_name')));
							$this->session->set_flashdata('error', 'Agent Successfully Added - '.$this->upload->display_errors());
	        				redirect(base_url().'agent');
						}
					}
					else
					{
						welcome($this->input->post('mobile'),strtolower($this->input->post('user_name')));
						$this->session->set_flashdata('msg', 'Agent Successfully Added');
	        			redirect(base_url().'agent');
		        	}
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Add Agent Try Again');
	        		redirect(base_url().'agent/add');
				}
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Add Agent Try Again');
	        	$this->db->delete('user', array('id' => $insert_id));
	        	redirect(base_url().'agent/add');
			}
		}
	}  //  Save Function


	// Check Coustmer Id
	function Coustmer_id($id)
	{
		if($id != '')
		{
			if($this->users->get_customer_id($id))
			{
	            return true;
			}
			else
			{
				$this->form_validation->set_message(__FUNCTION__ , 'Please Enter Valid Coustmer Id');
	            return false;
			}
		}
		else
		{
			return true;
		}
	}


	//	Reference Id
	function RefId_Check($id){
			if($this->validate->Agennt_RefId_Check($id) == true){
	            return true;
			}
			else{
				$this->form_validation->set_message(__FUNCTION__ , 'Please Enter Valid Reference Id');
	            return false;
			}
	}

	function validate_leg($leg,$agent){
		if($leg != ''){
			if($this->validate->Agennt_RefId_Check($agent)){
	            
				if($leg == $this->users->leg($agent)['last_leg'])
				{
					$this->form_validation->set_message(__FUNCTION__ , 'Left Leg Is Full Please Select Right');
					return false;
				}
				else
				{

					return true;
				}
			}
			else{ 
					$this->form_validation->set_message(__FUNCTION__ , 'Please Enter Valid Reference Id.');
					return false; 
				}

		}
		else{ 
				$this->form_validation->set_message(__FUNCTION__ , 'Please Select Leg.');
				return false; 
			}

	
	}

		public function date_valid($date)
		  {
		    $parts = explode("-", $date);
		    if (count($parts) == 3) {      
		      if (checkdate($parts[1], $parts[0], $parts[2]))
		      {
		        return TRUE;
		      }
		    }
		    $this->form_validation->set_message('date_valid', 'The Date field must be dd-mm-yyyy');
		    return false;
		  }



	/*///////////////////////////////////////////////////////////////////////////////////////////////////////
		  								START AGENT EDIT
	///////////////////////////////////////////////////////////////////////////////////////////////////////*/  

	
public function edit($id = false)
	{	
		if($id)
		{
			if($this->users->get_agent($id))
			{
				$data['page_title']	= 'Edit Associate';
				$data['user'] = $this->users->get_user($id)[0];
				$data['agent'] = $this->users->agent_detail($id)[0];
				//$data['leg'] = $this->users->leg($data['user']['reference_id']);
				$data['coustmer_id'] = $this->users->leg($data['user']['user_type_id'])['coustmer'];
				$this->load->template('agent/edit',$data);
			}	
			else
			{
				$this->session->set_flashdata('error', 'Agent Not Found');
	        	redirect(base_url().'agent');
			}
			
		}
		else
		{
			$this->session->set_flashdata('error', 'Agent Not Found');
	        redirect(base_url().'agent');
		}
	    
	}	

	public function update(){
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		/*****************************************************
					Personal Information Set Rules
		******************************************************/
		$this->form_validation->set_rules('pass', 'Password', 'min_length[5]');
		$this->form_validation->set_rules('con_pass', 'Confirm Password', 'matches[pass]');
		$this->form_validation->set_rules('fi_name', 'First Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('mi_name', 'Middle Name', 'trim');
		$this->form_validation->set_rules('la_name', 'Last Name', 'trim|min_length[2]|max_length[30]');
		//$this->form_validation->set_rules('fa_name', 'Father Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('mo_name', 'Mother Name', 'trim|required|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('bdate', 'Birth Date', 'trim|required|callback_date_valid');
		$this->form_validation->set_rules('jdate', 'Joining Date', 'trim|required|callback_date_valid');

		$this->form_validation->set_rules('proof_type', 'Id Proof Type', 'trim|required|max_length[240]');
		$this->form_validation->set_rules('proof_num', 'Id Proof Number', 'trim|required|min_length[5]|max_length[240]');

		$this->form_validation->set_rules('gur_type', 'Select Gurdian Type', 'trim|required');
		$this->form_validation->set_rules('gur_name', 'Gurdian Name', 'trim|required|min_length[2]|max_length[250]');
		$this->form_validation->set_rules('quali', 'Qualification', 'trim|required|min_length[3]|max_length[100]');
		$this->form_validation->set_rules('desig', 'Designation', 'trim|required|min_length[3]|max_length[50]');
		$this->form_validation->set_rules('sex', 'Sex', 'trim|required');

		/*****************************************************
					Contact information
		******************************************************/
		$this->form_validation->set_rules('email', 'Email', 'trim|valid_email|xss_clean|max_length[100]');
		$this->form_validation->set_rules('mobile', 'Mobile Number', 'required|regex_match[/^[0-9]{10}$/]|min_length[10]|max_length[10]');
		$this->form_validation->set_rules('mobile2', 'Mobile Number2', 'regex_match[/^[0-9]{10}$/]|min_length[10]|max_length[12]');

		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[10]|max_length[500]');
		$this->form_validation->set_rules('city', 'City', 'trim|required|min_length[2]|max_length[15]');
		$this->form_validation->set_rules('zip', 'Zip code', 'trim|required|min_length[4]|max_length[10]');
		$this->form_validation->set_rules('state', 'State', 'trim|required|min_length[2]|max_length[50]');
		$this->form_validation->set_rules('year', 'Year', 'trim');
		$this->form_validation->set_rules('jdate', 'Jdate', 'trim');

		$this->form_validation->set_rules('bank', 'Bank Name', 'trim|required|min_length[3]|max_length[50]');
		
		$this->form_validation->set_rules('ac_number', 'A/C Number', 'trim|required|alpha_numeric|min_length[8]|max_length[20]');
		
		$this->form_validation->set_rules('ifsc_code', 'IFSC Code', 'trim|required|alpha_numeric|min_length[5]|max_length[20]');

		$this->form_validation->set_rules('branch_name', 'Branch Name', 'trim|required|min_length[5]|max_length[50]');

		//Identity  Details Set Rules
		/******************************************************/
		//$this->form_validation->set_rules('profile','profile','required|trim|min_length[10]|max_length[20]');
		$this->form_validation->set_rules('description','description','required|trim|min_length[10]|max_length[100]');
        //$this->form_validation->set_rules('dob','Date of birth','required|trim');
		//$this->form_validation->set_rules('join_date','Joining date','required|trim');
		$this->form_validation->set_rules('expire_date','Expire date','required|trim');
		/*****************************************************/
		//	User Name 
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Edit Agent';
			$data['user'] = $this->users->get_user($this->input->post('main_id'))[0];
			$data['agent'] = $this->users->agent_detail($this->input->post('main_id'))[0];
			$data['coustmer_id'] = $this->users->leg($data['user']['user_type_id'])['coustmer'];
			$this->load->template('agent/edit',$data);
		}
		else
		{   
	        $data['agent'] = $this->users->agent_detail($this->input->post('main_id'))[0]; 
			$data['user'] = $this->users->get_user($this->input->post('main_id'))[0];
			
	        $datapss = $data['user']['pass'];
			//echo $datapss; die;
			$userpass =  $this->input->post('pass');
			if(($userpass)!= '')
			{	
			 $pass = md5($userpass);
			}
			else{
				
			 $pass = $datapss;	
			}

			$user_insert = array(
			    'user_name'           => 	strtolower($this->input->post('user_name')),
				'pass'                => 	$pass,
		        'email'               => 	$this->input->post('email'),
		        'mobile'              => 	$this->input->post('mobile'),
		        'updated_by'		  => 	$this->session->userdata('id'),
		        'updated_at' 		  => 	date('Y-m-d H:i:s')
			);
				$this->db->where('id', $this->input->post('main_id'));
			if($this->db->update('user', $user_insert)){

				

				$agent_insert = array(
					'fi_name'    		  => 	$this->input->post('fi_name'),
					'mi_name'         	  => 	$this->input->post('mi_name'),
					'la_name'			  => 	$this->input->post('la_name'),
					'fa_name'	 	      => 	$this->input->post('fa_name'),
					'mo_name'		      =>	$this->input->post('mo_name'),
					'bdate'		          =>	date('Y-m-d',strtotime($this->input->post('bdate'))),
					'jdate'		          =>	date('Y-m-d',strtotime($this->input->post('jdate'))),

					'proof_type'		  =>	$this->input->post('proof_type'),
					'proof_num'		      =>	strtoupper($this->input->post('proof_num')),
					
					'year'		          =>	$this->input->post('year'),
					'quali'		          =>	$this->input->post('quali'),
					'desig'		          =>	$this->input->post('desig'),
					'email'		          =>	$this->input->post('email'),
					'mobile'		      =>	$this->input->post('mobile'),
					'mobile2'		      =>	$this->input->post('mobile2'),
					'address'		      =>	$this->input->post('address'),
					'city'		          =>	$this->input->post('city'),
					'zip'		          =>	$this->input->post('zip'),
					'state'	              =>	$this->input->post('state'),
					'bank'		          =>	$this->input->post('bank'),
					'ac_number'		      =>	$this->input->post('ac_number'),
					'ifsc_code'		      =>	strtoupper($this->input->post('ifsc_code')),
					'branch_name'		  =>	$this->input->post('branch_name'),
					'sex'		  	  =>	$this->input->post('sex'),
					'gur_type'			  => 	$this->input->post('gur_type'),
					'gur_name'			  => 	$this->input->post('gur_name'),
					'description'	      =>   	$this->input->post('description'),
				   'expire_date'	      =>   	$this->input->post('expire_date'),
				);

					$this->db->where('user_id', $this->input->post('main_id'));
				if($this->db->update('agent_details', $agent_insert))
				{

					if(!empty($_FILES['my_image']['name']))
					{
						
						$path = $_FILES['my_image']['name'];
						$newName = md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
						$config['upload_path']		= './uploads/';
						$config['allowed_types']	= 'gif|jpg|png|jpeg';
						$config['max_size']			= 1000000;
						
						$location = "uploads/sushant/";
						$file1 = $_FILES['my_bar']['name'];
						$file_tmp1 = $_FILES['my_bar']['tmp_name']; 
						
						$file2 = $_FILES['my_qr']['name'];
						$file_tmp2 = $_FILES['my_qr']['tmp_name'];
						
						$config['file_name'] = $newName;
						$this->load->library('upload', $config);
						if($this->upload->do_upload('my_image'))
						{
						    $image_path_compressed = image_thumb($newName, 300, 250);
							//print_r($image_path_compressed); die;
							
    						$user = $this->auth->get_admin($this->input->post('main_id'));

    						if($user->image != 'user.png')
    						{
    							unlink('./uploads/'.$user->image);
    							unlink('./uploads/thumb/'.$user->image);
    						}

							$subadmin_insert = array(
								'image'    	  => 	$newName,
								'barcode'         =>     $file1,
								'qrcode'         =>     $file2,
							);

							move_uploaded_file($file_tmp1, $location.$file1);
							move_uploaded_file($file_tmp2, $location.$file2);
							$this->db->where('id', $this->input->post('main_id'));
							if($this->db->update('user', $subadmin_insert))
							{
								$this->session->set_flashdata('msg', 'Agent Successfully Saved');
	        					redirect(base_url().'agent');
							}
							else
							{
								$this->session->set_flashdata('error', 'Agent Successfully Saved - '.$this->upload->display_errors());
								unlink('./uploads/'.$newName);
								unlink('./uploads/thumb/'.$newName);
	        					redirect(base_url().'agent');
							}
						}
						else
						{
							$this->session->set_flashdata('error', 'Agent Successfully Saved - '.$this->upload->display_errors());
	        				redirect(base_url().'agent');
						}


					}
					else
					{
						$this->session->set_flashdata('msg', 'Agent Successfully Saved');
	        			redirect(base_url().'agent');
		        	}
					
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Save Agent Try Again');
	        		redirect(base_url().'agent');
				}
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Save Agent Try Again');
	        	redirect(base_url().'agent');
			}
		}
	}
	/*///////////////////////////////////////////////////////////////////////////////////////////////////////
		  								START ACTIVE / DEACTIVE
	///////////////////////////////////////////////////////////////////////////////////////////////////////*/  



    public function active($id)
	{

		$update = ['active' => 1];

		$this->db->where('agent_id', $id);
		if($this->db->update('binary', $update)){
			
			$this->session->set_flashdata('msg', 'Agent Successfully Deactivated');
        	redirect(base_url().'agent');
		}
	}
	public function deactive($agent_id){

		$update = ['active' => 0];
		
		$this->db->where('agent_id', $agent_id);
		if($this->db->update('binary', $update)){
			
			$this->session->set_flashdata('msg', 'Agent Successfully Activated');
        	redirect(base_url().'agent');

		}
	}





	/*///////////////////////////////////////////////////////////////////////////////////////////////////////
		  								DELETE AGENT 
	///////////////////////////////////////////////////////////////////////////////////////////////////////*/  

	
	public function delete($id = false)
	{	
		if($id)
		{
			if($this->users->get_user_with_type($id,'agent')[0])
			{

				$this->db->where('id',$id);
				if($this->db->update('user',array('updated_by'  => 	$this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
				{

					$user = $this->auth->get_admin($id);

					if($user->image != 'user.png')
					{
						unlink('./uploads/'.$user->image);
					}

					$this->session->set_flashdata('msg', 'Agent Successfully Deleted');
	        		redirect(base_url().'agent');
				}
				else{
					$this->session->set_flashdata('error', 'Agent Not Deleted Try Again');
	        		redirect(base_url().'agent');
				}
			}
			else{
				$this->session->set_flashdata('error', 'Agent Not Found');
	        	redirect(base_url().'agent');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Agent Not Found');
	        redirect(base_url().'agent');
		}
	}		



}