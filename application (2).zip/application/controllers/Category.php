<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Category extends CI_Controller 
{

	function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
		$this->load->model('category_model');
    }


	public function index()
	{
		$data['page_title']		=   'Category';
		$data['category']       =   $this->category_model->get_category();
		
		$this->load->template('category/index',$data);
	}

    public function add()
    {
        $data['page_title'] =   'Add Category';
		
        $this->load->template('category/add',$data);
    }

    public function save()
    {
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|min_length[3]|max_length[30]');
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title'] =   'Add Category';
			$this->load->template('category/add',$data);
		}
		else
		{ 
			$data = array(
						'category_name'     =>$this->input->post('category_name'),
						'created_by' 		=>$this->session->userdata('id'),
						'created_at' 		=>date('Y-m-d H:i:s'),
						);
			if($this->db->insert('document_category',$data))
			{
				$this->session->set_flashdata('msg','Category Successfully Uploaded');
				redirect(base_url().'category');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Insert Data - '.$this->upload->display_errors());
				redirect(base_url().'category');
			}
		}	
    }
	
	public function edit($id = false)
	{	
		if($id)
		{
			if($this->category_model->get_category_by_id($id))
			{
				$data['page_title']	= 'Edit Category';
				$data['category'] = $this->category_model->get_category_by_id($id)[0];
				$this->load->template('category/edit',$data);
			}	
			else
			{
				$this->session->set_flashdata('error', 'Category Not Found');
	        	redirect(base_url().'category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Category Not Found');
	        redirect(base_url().'category');
		}
	}	
	
	public function update()
	{
		$id = $this->input->get_post('category_id');
		if($this->category_model->get_category_by_id($id))
		{
			$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
			$this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|min_length[3]|max_length[30]');
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit Category';
				$data['category'] = $this->category_model->get_category_by_id($id)[0];
				$this->load->template('category/edit',$data);
			}
			else
			{
				$category_update = array(
									'category_name'       =>$this->input->post('category_name'),
									'updated_by'		  =>$this->session->userdata('id'),
									'updated_at' 		  =>date('Y-m-d H:i:s')
									);
				
				$this->db->where('category_id',$this->input->post('category_id'));
				if($this->db->update('document_category', $category_update))
				{
					$this->session->set_flashdata('msg', 'Category Successfully Saved');
					redirect(base_url().'category');
				}
				else
				{
					$this->session->set_flashdata('error', 'Category In Save Agent Try Again');
					redirect(base_url().'category');
				}
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Category Not Found');
	        redirect(base_url().'category');
		}
	}
	
    public function delete($id)
	{
        $data = $this->db->get_where('document_category',['category_id'=>$id])->result_array()[0];
        $this->db->where('category_id',$id);
        $this->db->delete('document_category');
        $this->session->set_flashdata('msg', 'Category Successfully Deleted');
        redirect(base_url().'category');
    }
	
	public function active($id = false)
	{	
		if($id)
		{
			$this->db->where('category_id',$id);
			if($this->db->update('document_category',array('updated_by'=>$this->session->userdata('id'),'status'=>'1')))
			{
				$this->session->set_flashdata('msg', 'Category Successfully Approved');
				redirect(base_url().'category');
			}
			else{
				$this->session->set_flashdata('error', 'Category Not Approved Try Again');
				redirect(base_url().'category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Category Not Found');
	        redirect(base_url().'category');
		}
	}

	public function deactive($id = false)
	{	
		if($id)
		{
			$this->db->where('category_id',$id);
			if($this->db->update('document_category',array('updated_by'=>$this->session->userdata('id'),'status'=>'2')))
			{	
				$this->session->set_flashdata('msg', 'Category Successfully Deactived');
				redirect(base_url().'category');
			}
			else{
				$this->session->set_flashdata('error', 'Category Not Deactived Try Again');
				redirect(base_url().'category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Category Not Found');
	        redirect(base_url().'category');
		}
	}	
}