<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Com_bal extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->auth->check_session();
        $this->load->model('com_bal_model');
    }


    public function index_view()
    {
       
        $data['page_title'] = 'Manage Comapany Balance';
        $data['balance']    = $this->com_bal_model->company_balance();
        $this->load->template('company_balance/index',$data);
    }

    public function add()
    {
        $data['page_title'] = 'Add Comapany Balance';
        $this->load->template('company_balance/add',$data);
    }

    public function edit($id)
    {
        $data['page_title'] = 'Edit Comapany Balance';
        $data['balance']    = $this->com_bal_model->company_balance_where($id);
        $this->load->template('company_balance/edit',$data);
    }

    public function save()
    {
        $this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

        $this->form_validation->set_rules('date', 'Date', 'trim|required');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');
        $this->form_validation->set_rules('remark', 'Remarks', 'trim|max_length[500]');

        if($this->form_validation->run() == FALSE)
        {
            $data['page_title'] = 'Add Comapany Balance';
            $this->load->template('company_balance/add',$data);
        }
        else
        { 
            $data = [
                            'type'              => 'investment',
                            'credit_by'         => '0',
                            'investment_id'     => '0',
                            'date'              => _ddate($this->input->post('date')),
                            'credit'            => $this->input->post('amount'),
                            'debit'             => '0.00',
                            'remark'             => $this->input->post('remark'),
                            'created_at'        => date('Y-m-d H:i:s')
                    ];

                if($this->db->insert('transaction', $data))
                {
                    $this->session->set_flashdata('msg', 'Balance Successfully Added');
                    redirect(base_url().'com_bal/index_view');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Problem In Add Balance Try Again');
                    redirect(base_url().'com_bal/add');
                }
        }
    }

     public function update()
    {
        $this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

        $this->form_validation->set_rules('date', 'Date', 'trim|required');
        $this->form_validation->set_rules('amount', 'Amount', 'trim|required|numeric');
        $this->form_validation->set_rules('remark', 'Remarks', 'trim|max_length[500]');

        if($this->form_validation->run() == FALSE)
        {
            $data['page_title'] = 'Edit Comapany Balance';
            $data['balance']    = $this->com_bal_model->company_balance_where($this->input->post('id'));
            $this->load->template('company_balance/edit',$data);
        }
        else
        { 
            $data = [
                            'type'              => 'investment',
                            'credit_by'         => '0',
                            'investment_id'     => '0',
                            'date'              => _ddate($this->input->post('date')),
                            'credit'            => $this->input->post('amount'),
                            'debit'             => '0.00',
                            'remark'            => $this->input->post('remark'),
                    ];

                    $this->db->where('id',$this->input->post('id'));
                if($this->db->update('transaction', $data))
                {
                    $this->session->set_flashdata('msg', 'Balance Successfully Save');
                    redirect(base_url().'com_bal/index_view');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Problem In Save Balance Try Again');
                    redirect(base_url().'com_bal/edit/'.$this->inut->post('id'));
                }
        }
    }


    public function delete($id)
    {    
        if($id)
        {
            if($this->com_bal_model->company_balance_where($id))
            {

                $this->db->where('id',$id);
                if($this->db->delete('transaction'))
                {
                    $this->session->set_flashdata('msg', 'Balance Successfully Deleted');
                    redirect(base_url().'com_bal/index_view');
                }
                else{
                    $this->session->set_flashdata('error', 'Balance Not Deleted Try Again');
                    redirect(base_url().'com_bal/index_view');
                }
            }
            else{
                $this->session->set_flashdata('error', 'Balance Not Found');
                redirect(base_url().'com_bal/index_view');
            }

        }
        else{
            $this->session->set_flashdata('error', 'Balance Not Found');
            redirect(base_url().'com_bal/index_view');
        }
    }       


}