<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


class Createplot extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
        $this->auth->check_session();
        $this->load->model('add_product');
        $this->load->model('setting_model');
        $this->load->model('transaction_model');
	}

	public function index()
	{
		$id 	= $this->uri->segments[3];
		$data['page_title']	= 'Products';
		$data['get_product_all'] = $this->add_product->get_created($id);
		//echo"<pre>"; print_r($data['get_product_all']); die;
		$this->load->template('add_product/create',$data);
	}


	
}
?>