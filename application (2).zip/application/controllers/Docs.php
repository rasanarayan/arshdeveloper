<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Docs extends CI_Controller 
{

	function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
		$this->load->model(array('docs_model'));
    }


	public function index()
	{
		$data['page_title']	=   'Docs';
		$data['docs']       =   $this->docs_model->get_document();
		if($this->input->post('visibilty_type')!='')
		{	
			$this->docs_model->update_visibility();
        }
		$this->load->template('docs/index',$data);
	}
	
	public function get_sub_category_data()
	{	$category_id	= $this->input->get_post('category_id');
		$sub_category 	= $this->docs_model->get_sub_category(array('category_id'=>$category_id));
		if(is_array($sub_category) && !empty($sub_category))
		{
			echo '<option value="">Select Sub Category</option>';
			foreach($sub_category as $val)
			{
				echo '<option value="'.$val['sub_category_id'].'">'.$val['sub_category_name'].'</option>';
			}
		}
		else
		{
			echo '<option value="">No Sub Category Found</option>';
		}
		
	}
	
    public function add()
    {
		$data['category']       	= $this->docs_model->get_category(array('status'=>'1'));
        $data['page_title'] =   'Add Document';
        $this->load->template('docs/add',$data);
    }

    public function save()
    {
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('category_id','Category','trim|required|max_length[30]');
		$this->form_validation->set_rules('sub_category_id','Sub Category','trim|required|max_length[30]');
		$this->form_validation->set_rules('name','Document Name','trim|required|max_length[30]');
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['category']       	= $this->docs_model->get_category(array('status'=>'1'));
			$data['page_title'] 		= 'Add Document';
			$this->load->template('docs/add',$data);
		}
		else
		{ 
			$path 						= $_FILES['file']['name'];
			$newName 					= md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
			$config['upload_path']      = './uploads/documents/';
			$config['allowed_types']    = 'pdf';
			$config['max_size']         = 2000000;
			$config['file_name'] 		= $newName;
			$this->load->library('upload', $config);
			if($this->upload->do_upload('file'))
			{
				if($this->session->userdata('id')=='1')
				{
					$verification_status = '1';
				}
				else
				{
					$verification_status = '0';
				}
				$data = array(
							'category_id'       		=>$this->input->post('category_id'),
							'sub_category_id'       	=>$this->input->post('sub_category_id'),
							'name'       				=>$this->input->post('name'),
							'file'      	 			=>$newName,
							'verification_status'       =>$verification_status,
							'created_by' 				=>$this->session->userdata('id'),
							);
				if($this->db->insert('docs', $data))
				{
					$this->session->set_flashdata('msg', 'Document Successfully Uploaded');
					redirect(base_url().'docs');
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
					unlink('./documents/'.$newName);
					redirect(base_url().'docs');
				}
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
				redirect(base_url().'docs');
			}
		}
    }

    public function delete($id)
	{
        $data = $this->db->get_where('docs',['id'=>$id])->result_array()[0];
        $this->db->where('id',$id);
        $this->db->delete('docs');
        if(file_exists(FCPATH.'documents/'.$data['file']))
		{
            unlink('./documents/'.$data['file']);
        }
        $this->session->set_flashdata('msg', 'Document Successfully Deleted');
        redirect(base_url().'docs');
    }
	
	public function approved($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('docs',array('updated_by'=>$this->session->userdata('id'),'verification_status'=>'1')))
			{
				$this->session->set_flashdata('msg', 'Document Successfully Approved');
				redirect(base_url().'docs');
			}
			else{
				$this->session->set_flashdata('error', 'Document Not Approved Try Again');
				redirect(base_url().'docs');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Document Not Found');
	        redirect(base_url().'docs');
		}
	}

	public function rejected($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('docs',array('updated_by'=>$this->session->userdata('id'),'verification_status'=>'2')))
			{	
				$this->session->set_flashdata('msg', 'Document Successfully Rejected');
				redirect(base_url().'docs');
			}
			else{
				$this->session->set_flashdata('error', 'Document Not Rejected Try Again');
				redirect(base_url().'docs');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Document Not Found');
	        redirect(base_url().'docs');
		}
	}	
}