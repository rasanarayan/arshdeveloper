<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Gallery extends CI_Controller 
{

	function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
		$this->load->model(array('gallery_model'));
    }


	public function index()
	{
		$data['page_title']		=   'Gallery';
		$data['result']       	=   $this->gallery_model->get_document();
		if($this->input->post('visibilty_type')!='')
		{	
			$this->gallery_model->update_visibility();
        }
		$this->load->template('gallery/index',$data);
	}

    public function add()
    {
        $data['page_title'] =   'Add Gallery';
        $this->load->template('gallery/add',$data);
    }

    public function save()
    {	
        $path 		= $_FILES['file']['name'];
        $newName 	= md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
        $config['upload_path']      = './uploads/gallery/';
        $config['allowed_types']    = 'jpeg|jpg|png|GPEG|JPG|PNG';
        $config['max_size']         = 2000000;
        $config['file_name'] 		= $newName;
        $this->load->library('upload', $config);
		
        if($this->upload->do_upload('file'))
        {	
			if($this->session->userdata('id')=='1')
			{
				$verification_status = '1';
			}
			else
			{
				$verification_status = '0';
			}
            $data = array(
						'name'       				=>$this->input->post('name'),
						'file'      	 			=>$newName,
						'verification_status'       =>$verification_status,
						'created_by' 				=>$this->session->userdata('id'),
						);
            if($this->db->insert('gallery', $data))
            {
                $this->session->set_flashdata('msg', 'Gallery Successfully Uploaded');
                redirect(base_url().'gallery');
            }
            else
            {
                $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
                unlink('./gallery/'.$newName);
                redirect(base_url().'gallery');
            }
        }
        else
        {	//echo "<pre>"; print_r($_POST); die;
            $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
            redirect(base_url().'docs');
        }
    }

    public function delete($id){

        $data = $this->db->get_where('gallery',['id'=>$id])->result_array()[0];
        $this->db->where('id',$id);
        $this->db->delete('gallery');
        if(file_exists(FCPATH.'gallery/'.$data['file']))
		{
            unlink('./gallery/'.$data['file']);
        }
        $this->session->set_flashdata('msg', 'Gallery Successfully Deleted');
        redirect(base_url().'gallery');
    }
	
	public function approved($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('gallery',array('updated_by'=>$this->session->userdata('id'),'verification_status'=>'1')))
			{
				$this->session->set_flashdata('msg', 'Gallery Successfully Approved');
				redirect(base_url().'gallery');
			}
			else{
				$this->session->set_flashdata('error', 'Gallery Not Approved Try Again');
				redirect(base_url().'gallery');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Gallery Not Found');
	        redirect(base_url().'gallery');
		}
	}

	public function rejected($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('gallery',array('updated_by'=>$this->session->userdata('id'),'verification_status'=>'2')))
			{	
				$this->session->set_flashdata('msg', 'Gallery Successfully Rejected');
				redirect(base_url().'gallery');
			}
			else{
				$this->session->set_flashdata('error', 'Gallery Not Rejected Try Again');
				redirect(base_url().'gallery');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Gallery Not Found');
	        redirect(base_url().'gallery');
		}
	}	
}