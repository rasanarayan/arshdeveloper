<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manual_receipt extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->auth->check_session();
        $this->load->model('manual_receipt_model');
    }


    public function index()
    {
       
        $data['page_title'] = 'Manage Receipt';
        $data['receipt']    = $this->manual_receipt_model->manual_receipt();
        $this->load->template('manual_receipt/index',$data);
    }

    public function view($id = false)
    {
        if($this->manual_receipt_model->manual_receipt_where($id))
        {
            $data['page_title'] = 'Manage Receipt';
            $data['receipt']    = $this->manual_receipt_model->manual_receipt_where($id);
            $this->load->template('manual_receipt/view',$data);
        }   
        else
        {
            $this->session->set_flashdata('error', 'Receipt Not Found');
            redirect(base_url().'manual_receipt');
        }    
    }


    public function print($id = false)
    {
        if($this->manual_receipt_model->manual_receipt_where($id))
        {
            $data['page_title'] = 'Manage Receipt';
            $data['receipt']    = $this->manual_receipt_model->manual_receipt_where($id);
            $this->load->view('manual_receipt/print',$data);
        }   
        else
        {
            $this->session->set_flashdata('error', 'Receipt Not Found');
            redirect(base_url().'manual_receipt');
        }    
    } 


    public function edit($id = false)
    {
        if($this->manual_receipt_model->manual_receipt_where($id))
        {
            $data['page_title'] = 'Manage Receipt';
            $data['receipt']    = $this->manual_receipt_model->manual_receipt_where($id);
            $this->load->template('manual_receipt/edit',$data);
        }   
        else
        {
            $this->session->set_flashdata('error', 'Receipt Not Found');
            redirect(base_url().'manual_receipt');
        }    
    }

    public function add()
    {
        $data['page_title'] = 'Create Receipt';
        $this->load->template('manual_receipt/add',$data);
        
    }


    public function save()
    {
        $this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
        
        
        $this->form_validation->set_rules('receipt_no', 'Receipt No', 'trim|is_natural|min_length[1]|max_length[20]');
        $this->form_validation->set_rules('coust_id', 'Customer ID', 'trim|is_natural|min_length[1]|max_length[10]');
        $this->form_validation->set_rules('date', 'date', 'trim|required');
        $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('install_amount', 'Installment Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('install_num', 'Installment Number', 'trim|is_natural|min_length[1]|max_length[30]');
        $this->form_validation->set_rules('sales_id', 'Sales ID', 'trim|is_natural|min_length[1]|max_length[30]');
        $this->form_validation->set_rules('paid_amount', 'Paid Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('pay_mode', 'Payment Mode', 'trim|required');
        $this->form_validation->set_rules('due_date', 'Due Date', 'trim|required');
        $this->form_validation->set_rules('late_charge', 'Late Charges', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('pay_detail', 'Payment Detail', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('next_due_date', 'Next Due Date', 'trim|required');
        $this->form_validation->set_rules('total', 'Total', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('received_by', 'Received By', 'trim|required|min_length[2]|max_length[240]');

        $this->form_validation->set_rules('name2', 'Name', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('plot_number', 'Plot Number', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('duration', 'Duration', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('plot_size', 'Plot Size', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('location', 'Location', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('total_install', 'Total Installment', 'trim|required|is_natural|min_length[2]|max_length[30]');


        $this->form_validation->set_rules('total_amount', 'Total Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('total_paid', 'Total Paid', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('total_remai', 'Total Remaining', 'trim|required|numeric|min_length[2]|max_length[30]');

        if ($this->form_validation->run() == FALSE)
        {
            $data['page_title'] = 'Create Receipt';
            $this->load->template('manual_receipt/add',$data);
        }
        else
        { 
            $data   =   [
                            'receipt_no'        =>  $this->input->post('receipt_no'),
                           // 'coust_id'          =>  $this->input->post('coust_id'),
                            'date'              =>  _ddate($this->input->post('date')),
                            'name'              =>  ucfirst($this->input->post('name')),
                            'install_amount'    =>  $this->input->post('install_amount'),
                            'install_num'       =>  $this->input->post('install_num'),
                           // 'sales_id'          =>  $this->input->post('sales_id'),
                            'paid_amount'       =>  $this->input->post('paid_amount'),
                            'pay_mode'          =>  $this->input->post('pay_mode'),
                            'due_date'          =>  _ddate($this->input->post('due_date')),
                            'late_charge'       =>  $this->input->post('late_charge'),
                            'pay_detail'        =>  ucfirst($this->input->post('pay_detail')),
                            'next_due_date'     =>  _ddate($this->input->post('next_due_date')),
                            'total'             =>  $this->input->post('total'),
                            'received_by'       =>  ucfirst($this->input->post('received_by')),
                            'name2'             =>  ucfirst($this->input->post('name2')),
                            'plot_number'       =>  $this->input->post('plot_number'),
                            'duration'          =>  $this->input->post('duration'),
                            'plot_size'         =>  $this->input->post('plot_size'),
                            'location'          =>  ucfirst($this->input->post('location')),
                            'total_install'     =>  $this->input->post('total_install'),
                            'total_amount'      =>  $this->input->post('total_amount'),
                            'total_paid'        =>  $this->input->post('total_paid'),
                            'total_remai'       =>  $this->input->post('total_remai'),
                            'created_by'        =>  $this->session->userdata('id'),
                            'created_at'        =>  date('Y-m-d H:i:s')
                        ];

                if($this->db->insert('manual_receipt', $data))
                {
                    $this->session->set_flashdata('msg', 'Receipt Successfully Saved');
                    redirect(base_url().'manual_receipt');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Problem In Save Receipt Try Again');
                    redirect(base_url().'manual_receipt');
                }
        }
    }



    public function update()
    {
        $this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
        
        
        $this->form_validation->set_rules('receipt_no', 'Receipt No', 'trim|is_natural|min_length[1]|max_length[20]');
        $this->form_validation->set_rules('coust_id', 'Customer ID', 'trim|is_natural|min_length[1]|max_length[10]');
        $this->form_validation->set_rules('date', 'date', 'trim|required');

        $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('install_amount', 'Installment Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('install_num', 'Installment Number', 'trim|required|is_natural|min_length[1]|max_length[30]');
        $this->form_validation->set_rules('sales_id', 'Sales ID', 'trim|is_natural|min_length[1]|max_length[30]');
        $this->form_validation->set_rules('paid_amount', 'Paid Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('pay_mode', 'Payment Mode', 'trim|required');
        $this->form_validation->set_rules('due_date', 'Due Date', 'trim|required');
        $this->form_validation->set_rules('late_charge', 'Late Charges', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('pay_detail', 'Payment Detail', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('next_due_date', 'Next Due Date', 'trim|required');
        $this->form_validation->set_rules('total', 'Total', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('received_by', 'Received By', 'trim|required|min_length[2]|max_length[240]');

        $this->form_validation->set_rules('name2', 'Name', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('plot_number', 'Plot Number', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('duration', 'Duration', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('plot_size', 'Plot Size', 'trim|required|is_natural|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('location', 'Location', 'trim|required|min_length[2]|max_length[240]');
        $this->form_validation->set_rules('total_install', 'Total Installment', 'trim|required|is_natural|min_length[2]|max_length[30]');


        $this->form_validation->set_rules('total_amount', 'Total Amount', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('total_paid', 'Total Paid', 'trim|required|numeric|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('total_remai', 'Total Remaining', 'trim|required|numeric|min_length[2]|max_length[30]');

        if ($this->form_validation->run() == FALSE)
        {
            $data['page_title'] = 'Create Receipt';
            $data['receipt']    = $this->manual_receipt_model->manual_receipt_where($this->input->post('id'));
            $this->load->template('manual_receipt/add',$data);
        }
        else
        { 
            $data   =   [
                            'receipt_no'        =>  $this->input->post('receipt_no'),
                            'coust_id'          =>  $this->input->post('coust_id'),
                            'date'              =>  _ddate($this->input->post('date')),
                            'name'              =>  ucfirst($this->input->post('name')),
                            'install_amount'    =>  $this->input->post('install_amount'),
                            'install_num'       =>  $this->input->post('install_num'),
                            'sales_id'          =>  $this->input->post('sales_id'),
                            'paid_amount'       =>  $this->input->post('paid_amount'),
                            'pay_mode'          =>  $this->input->post('pay_mode'),
                            'due_date'          =>  _ddate($this->input->post('due_date')),
                            'late_charge'       =>  $this->input->post('late_charge'),
                            'pay_detail'        =>  ucfirst($this->input->post('pay_detail')),
                            'next_due_date'     =>  _ddate($this->input->post('next_due_date')),
                            'total'             =>  $this->input->post('total'),
                            'received_by'       =>  ucfirst($this->input->post('received_by')),
                            'name2'             =>  ucfirst($this->input->post('name2')),
                            'plot_number'       =>  $this->input->post('plot_number'),
                            'duration'          =>  $this->input->post('duration'),
                            'plot_size'         =>  $this->input->post('plot_size'),
                            'location'          =>  ucfirst($this->input->post('location')),
                            'total_install'     =>  $this->input->post('total_install'),
                            'total_amount'      =>  $this->input->post('total_amount'),
                            'total_paid'        =>  $this->input->post('total_paid'),
                            'total_remai'       =>  $this->input->post('total_remai')
                            
                        ];

                    $this->db->where('id',$this->input->post('id'));
                if($this->db->update('manual_receipt', $data))
                {
                    $this->session->set_flashdata('msg', 'Receipt Successfully Saved');
                    redirect(base_url().'manual_receipt');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Problem In Save Receipt Try Again');
                    redirect(base_url().'manual_receipt');
                }
        }
    }




    public function delete($id = false)
    {   
        if($id)
        {
            if($this->manual_receipt_model->manual_receipt_where($id))
            {
                $this->db->where('id',$id);
                if($this->db->delete('manual_receipt'))
                {    
                    $this->session->set_flashdata('msg', 'Receipt Successfully Deleted');
                    redirect(base_url().'manual_receipt');
                }
                else{
                    $this->session->set_flashdata('error', 'Receipt Not Deleted Try Again');
                    redirect(base_url().'manual_receipt');
                }
            }
            else{
                $this->session->set_flashdata('error', 'Receipt Not Found');
                redirect(base_url().'manual_receipt');
            }

        }
        else{
            $this->session->set_flashdata('error', 'Receipt Not Found');
            redirect(base_url().'manual_receipt');
        }
    }       



}