<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Payment extends CI_Controller 
{

	public function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
        $this->load->model(array('payment_model','dash_model'));
        $this->load->model('users');
        $this->load->model('user_genaral');
        $this->load->model('transaction_model');
    }

   public function sell_payments()
    {
    	$data['page_title']	= 'Sales Payments';
		$data['admin'] = $this->users->subadmin_detail_drop('subadmin');
    	$data['datam'] = $this->payment_model->get_sell_payments('sales');
		//echo"<pre>"; print_r($data['admin']); die;
    	$this->load->template('payment/sell_payments',$data);
    }
    
     public function pending_installment_admin()
    {
		
		$master						= $this->users->get_master(array('id'=>'1'));
    	$data['page_title']			= 'Pending Installment Purchase';
    	$data['installment'] 		= $this->payment_model->purcahse_installment($master['installment_month']);
		//echo"<pre>"; print_r($data['installment']); die;
    	$this->load->template('payment/pending_installment_admin',$data);
    }
    
    
     public function upcoming_installment()
   {
       $data['page_title']	= 'Upcoming installment Payments';
       $data['installment'] = $this->payment_model->saless_installment();
       //echo"<pre>"; print_r($data['installment']); die;
       $this->load->template('payment/upcoming_sell_payments',$data);
   }
   
    public function upcoming_instllment_purcahse()
   {
       $data['page_title']	= 'Upcoming purchase installment Payments';
       $data['purchase_installment'] = $this->payment_model->purchase_installment();
      //echo"<pre>"; print_r($data['purchase_installment']); die;
       $this->load->template('payment/upcoming_purchase_payments',$data);
   }
    
    public function pending_installment_custumer()
    {
		$master						= $this->users->get_master(array('id'=>'1'));
    	$data['page_title']			= 'Pending Installment Customer';
    	$data['installment'] 		= $this->payment_model->sale_installment($master['installment_month']);
    	$this->load->template('payment/pending_installment_custumer',$data);
    }

    public function sell_view($id)
    {
        $data['page_title'] = 'View Sale Installment Receipt';
        $data['sell_payment'] = $this->payment_model->get_sell_payment($id)[0];
        $this->load->template('payment/sell_receipt',$data);
    }

    public function sell_print($id)
    {
        $data['page_title'] = 'Print Sale Installment Receipt';
        $data['sell_payment'] = $this->payment_model->get_sell_payment($id)[0];
        $this->load->view('payment/sale_print',$data);
    }

    public function sell()
    {
    	$data['page_title']	= 'Sales Payment';
    	$data['all_sales'] 	= $this->payment_model->get_installment_yes_all();
		//echo"<pre>"; print_r($data['all_sales']); die;
    	$this->load->template('payment/sell',$data);
    }
	
	public function promise()
    {
        $data['page_title']	= 'Promises';
    	$data['all_promises'] = $this->payment_model->get_promise_details();
    	$this->load->template('payment/promise_details',$data);
    }

    public function save_sell()
    {	
    	$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
    	$this->form_validation->set_rules('customer_id','Customer Name','required');
    	$this->form_validation->set_rules('time_id','Time Name','required');
    	if ($this->form_validation->run() == FALSE)
		{	
			$data['page_title']	= 'Sales Payment';
	    	$data['all_sales'] = $this->payment_model->get_installment_yes_all();
	    	$this->load->template('payment/sell',$data);
		}
		else
		{	
			redirect(base_url().'payment/add_sell/'.$_POST['customer_id'].'?time_id='.$_POST['time_id'].'');
		}
    }


    public function add_sell($id = FALSE)
    {	
		$time = $this->input->get_post('time_id');
		
    	if($id)
    	{
    		if($this->payment_model->get_sell_for_payment($id))
    		{
    			$data['page_title']			= 'Pay Sales Installment';
    			$data['sell_data'] 			= $this->payment_model->get_sell_for_payment($id)[0];
				$data['payment'] 			= $this->payment_model->get_sell_paid_installment($id);
    			$data['get_installment'] 	= $this->payment_model->get_sell_installment($id,$time);
				//echo"<pre>"; print_r($data['get_installment']); die;
				$data['promise_data'] = $this->payment_model->get_promise($id);
				
				$installment_id = $data['get_installment']['id'];
				//echo $installment_id; die;
				$data['promise_alert'] = $this->payment_model->get_promise_alert($id,$installment_id);
    			$this->load->template('payment/add_sell',$data);
    		}
    		else
    		{
    			$this->session->set_flashdata('error','Customer Name Is Not Valid Please Try Again');
	        	redirect(base_url().'payment/sell');
    		}
    	}
    	else
    	{
    		$this->session->set_flashdata('error','Customer Name Is Not Valid Please Try Again');
	        redirect(base_url().'payment/sell');
    	}
    }
	
	public function get_sell_product_data()
	{
		$result = $this->db->get_where('sell_product',['id'=>$_POST['id']])->row_array();
		//echo"<pre>"; print_r($result); die;
		if(is_array($result) && !empty($result))
		{	
			$time_installment = explode(',',$result['time_installment']);
			$time_amount = explode(',',$result['time_amount']);
			echo '<option value="">Select Time </option>'; 
			for($i=0; $i<count($time_installment); $i++ )
			{
				echo '<option value="'.$time_installment[$i].'">'.$time_installment[$i].'-'.$time_amount[$i].'</option>'; 
			}
		}
		else
		{
			echo '<option value="">Time Not Available</option>'; 
		}
	}
	
    public function sell_pay()
    {	
		if($this->input->post('promise_date') != ''  && $this->input->post('promise_remarks') != '' )				
		{
			 $promise = array(
							'sell_product_id'       => 	$this->input->post('sell_id'),
							'installment_id'        => 	$this->input->post('installment_id'),
							'promise_date'          =>  $this->input->post('promise_date'),
							'promise_remarks'       =>  $this->input->post('promise_remarks'),
							'created_at'            =>  date('Y-m-d H:i:s'),
							'updated_at'            =>  date('Y-m-d H:i:s'),
							'created_by'            =>  $this->session->userdata('id'),
							'updated_by'            =>  $this->session->userdata('id')
							);
			$this->db->insert('promise_tbl', $promise);				
		}
		$payment = array(
						'main_id'           	=> 	$this->input->post('sell_id'),
						'installment_id'        => 	$this->input->post('installment_id'),
						'type'           		=> 	'sales',
						'date'                  =>  _ddate($this->input->post('date')),
						'amount_install'        =>  $this->input->post('instal_remaining'),
						'late_charge'           => 	trim($this->input->post('late_charge')),
						'pay_type'           	=> 	$this->input->post('payment_mode'),
						'pay_detail'           	=> 	$this->input->post('payment_mode_detail'),
						'created_at'            =>  date('Y-m-d H:i:s'),
						'updated_at'            =>  date('Y-m-d H:i:s'),
						'created_by'            =>  $this->session->userdata('id'),
						'updated_by'            =>  $this->session->userdata('id')
						);
		if($this->db->insert('payment', $payment))
		{	
			
			$payment_id = $this->db->insert_id();
			$no_of_ins = '';
			$total_amount = $this->input->post('instal_remaining');
			while($total_amount > 0)
			{	
				$get_installments = $this->db->order_by('id','asc')->get_where('sell_installment_detail',['status' => '0','sell_product_id' => $this->input->post('sell_id'),'time'=>$this->input->post('time_id')])->result_array();
			
				foreach($get_installments as $key => $sing_insal) 
				{
					if($total_amount >= $sing_insal['instal_remaining'])
					{
							$no_of_ins .= $sing_insal['no_of_installment'].', ';
							if($sing_insal['pay_date'] == '')
							{
								$pay_date = $this->input->post('date');
							}
							else
							{
								$pay_date = $sing_insal['pay_date'].' , '.$this->input->post('date');
							}
							if($sing_insal['pay_mode'] == '')
							{
								$pay_mode = $this->input->post('payment_mode');
							}
							else
							{
								$pay_mode = $sing_insal['pay_mode'].' , '.$this->input->post('payment_mode');
							}
							if($sing_insal['pay_detail'] == '')
							{
								$pay_detail = $this->input->post('payment_mode_detail');
							}
							else
							{
								$pay_detail = $sing_insal['pay_detail'].' , '.$this->input->post('payment_mode_detail');
							}
							$update_installment = array(
														'status'                      => 1,
														'instal_remaining'            => 0.00,
														'pay_date'                    => $pay_date,
														'pay_detail'                  => $pay_detail,
														'pay_mode'                    => $pay_mode
													);
							$this->db->where('id', $sing_insal['id']);
							$this->db->update('sell_installment_detail', $update_installment);
							$total_amount -= $sing_insal['instal_remaining'];
							if($total_amount == 0)
							{
								break;
							}
						}
						else if($total_amount > 0)
						{
							$no_of_ins .= $sing_insal['no_of_installment'].', ';
							if($sing_insal['pay_date'] == '')
							{
								$pay_date = $this->input->post('date');
							}
							else
							{
								$pay_date = $sing_insal['pay_date'].' , '.$this->input->post('date');
							}
							if($sing_insal['pay_mode'] == '')
							{
								$pay_mode = $this->input->post('payment_mode');
							}
							else
							{
								$pay_mode = $sing_insal['pay_mode'].' , '.$this->input->post('payment_mode');
							}
							if($sing_insal['pay_detail'] == '')
							{
								$pay_detail = $this->input->post('payment_mode_detail');
							}
							else
							{
								$pay_detail = $sing_insal['pay_detail'].' , '.$this->input->post('payment_mode_detail');
							}
							$update_installment = array(
														'instal_remaining'            => $sing_insal['instal_remaining'] - $total_amount,
														'pay_date'                    => $pay_date,
														'pay_detail'                  => $pay_detail,
														'pay_mode'                    => $pay_mode
														);
							$this->db->where('id', $sing_insal['id']);
							$this->db->update('sell_installment_detail', $update_installment);
							$total_amount = 0;
							break;
					   }
				   }
				}
				$no_of_ins = rtrim($no_of_ins,', ');
				$this->db->where('id',$payment_id);
				$this->db->update('payment',['no_of_ins' => $no_of_ins]);
			   
				// sales
				$update_sell = array(
									'rem_amount'            => ($this->input->post('sale_remaning_amt') - $this->input->post('instal_remaining'))
									);
				$this->db->where('id', $this->input->post('sell_id'));
				$this->db->update('sell_product', $update_sell);
				
				
				if($this->input->post('payment_mode')!='Cheque')
				{
					$sell_insert_id 		= $this->input->post('sell_id');
					$commission_agent 		= $this->user_genaral->commission_agent_ins($sell_insert_id,floatval($this->input->post('instal_remaining')),_ddate($this->input->post('date')),'installment_',$payment_id,$this->input->post('payment_mode'));
					$promotio_agent 		= $this->user_genaral->promotion_agent_ins($sell_insert_id,floatval($this->input->post('instal_remaining')),_ddate($this->input->post('date')),'installment_',$payment_id,$this->input->post('payment_mode'));
					$commission_parterner 	= $this->user_genaral->commission_parterner_ins($sell_insert_id,floatval($this->input->post('instal_remaining')),_ddate($this->input->post('date')),'installment_',$payment_id,$this->input->post('payment_mode'));
					$after_shares_amount 	= $commission_agent + $promotio_agent + $commission_parterner;
					$new_due 				= $this->input->post('instal_remaining') - $after_shares_amount;
					$sales_profit 			= $this->user_genaral->share_company_after_all_ins($sell_insert_id,floatval($new_due),_ddate($this->input->post('date')),'installment_',$payment_id,$this->input->post('payment_mode'));
					if($this->input->post('late_charge') > 0)
					{
						$transaction = [
										'type'              =>  'late_payment',
										'credit'            =>  $this->input->post('late_charge'), 
										'credit_by'         =>  0,
										'date'              =>  _ddate($this->input->post('date')),
										'mode'              =>  $this->input->post('payment_mode'),
										'investment_id'     =>  $payment_id,
										'created_by'        =>  $this->session->userdata('id'),
										'created_at'        =>  date('Y-m-d H:i:s')
										];
						$this->db->insert('transaction', $transaction);
					}
				}
				$this->session->set_flashdata('msg', 'Payment Added Successfully');
				redirect(base_url().'payment/sell_payments');
			}
		else
		{
			$this->session->set_flashdata('error', 'Problem In Add Payment Try Again');
			redirect(base_url().'payment/sell');
		}
	}

    
    public function sale_edit($id){
        $data['page_title'] = 'Update Check Status in Sales Installment';
        $data['sale'] 		= $this->payment_model->get_sell_installment_by_id($this->payment_model->_payment($id)['installment_id']);
        $data['payment'] 	= $this->payment_model->_payment($id);
		//echo "<pre>"; print_r($data['sale']); die;
	   $this->load->template('payment/edit_sale',$data);
    }

    public function sale_update()
    {	
		 $id = $this->input->post('id');
		 $data['sale'] 		= $this->payment_model->get_sell_installment_by_id($this->payment_model->_payment($id)['installment_id']);
		 $data['payment'] 	= $this->payment_model->_payment($id);
         $partamount=$data['payment']['amount_install'];
		 $partdate=$data['payment']['date'];
		 //echo"<pre>"; print_r ($partdate); die;
		$payment = array(
						'date'                  =>  _ddate($this->input->post('date')),
						'late_charge'           =>  trim($this->input->post('late_charge')),
						'pay_type'              =>  $this->input->post('payment_mode'),
						'pay_detail'            =>  $this->input->post('payment_mode_detail'),
						'cheque_status'         =>  $this->input->post('cheque_status'),
						'cheque_charge'         =>  $this->input->post('cheque_charge'),
						'cheque_date'           =>  $this->input->post('cheque_date'),
						'updated_at'            =>  date('Y-m-d H:i:s'),
						'updated_by'            =>  $this->session->userdata('id')
						);
		
        		
		$this->db->where('id', $this->input->post('id'));
		if($this->db->update('payment', $payment))
		{
			if($this->input->post('cheque_status')=='1')
			{
				$sell_insert_id 		= $this->input->post('sell_id');
				 //print_r($sell_insert_id); die;
				
				$commission_agent 		= $this->user_genaral->commission_agent_ins($sell_insert_id,floatval($partamount),_ddate($partdate),'installment_',$id,$this->input->post('payment_mode'));
				$promotio_agent 		= $this->user_genaral->promotion_agent_ins($sell_insert_id,floatval($partamount),_ddate($partdate),'installment_',$id,$this->input->post('payment_mode'));
				$commission_parterner 	= $this->user_genaral->commission_parterner_ins($sell_insert_id,floatval($partamount),_ddate($partdate),'installment_',$id,$this->input->post('payment_mode'));
				$after_shares_amount 	= $commission_agent + $promotio_agent + $commission_parterner;
				$new_due 				= $this->input->post('instal_remaining') - $after_shares_amount;
				$sales_profit 			= $this->user_genaral->share_company_after_all_ins($sell_insert_id,floatval($new_due),_ddate($partdate),'installment_',$id,$this->input->post('payment_mode'));
				if($this->input->post('late_charge') > 0)
				{
					$transaction = [
									'type'              =>  'late_payment',
									'credit'            =>  $this->input->post('late_charge'), 
									'credit_by'         =>  0,
									'date'              =>  _ddate($partdate),
									'mode'              =>  $mode,
									'investment_id'     =>  $id,
									'created_by'        =>  $this->session->userdata('id'),
									'created_at'        =>  date('Y-m-d H:i:s')
									];
					$this->db->insert('transaction', $transaction);
				}
			}
			$this->session->set_flashdata('msg', 'Payment Updated Successfully');
			redirect(base_url().'payment/sell_payments');
		}
		else
		{
			$this->session->set_flashdata('error', 'Problem In Update Payment Try Again');
			redirect(base_url().'payment/sell_payments');
		}
    }


    public function delete_sale($id)
    {

        $payment = $this->payment_model->_payment($id);

        




        /// multiple install ment

        $total_amount = $payment['amount_install'];
        while($total_amount > 0){

            $get_installments = $this->db->query('SELECT * FROM `sell_installment_detail` where sell_product_id = "'.$payment['main_id'].'" and sell_installment_detail.instal_remaining != sell_installment_detail.instal_amount order by id desc')->result_array();

                foreach ($get_installments as $key => $sing_insal) {

                    if($total_amount >= $sing_insal['instal_amount'] - $sing_insal['instal_remaining']){

                        $total_amount -= $sing_insal['instal_amount'] - $sing_insal['instal_remaining'];

                        $pay_date   = explode(' , ', $sing_insal['pay_date']); array_pop($pay_date);
                        $pay_date   = implode(' , ', $pay_date);

                        $pay_mode   = explode(' , ', $sing_insal['pay_mode']); array_pop($pay_mode);
                        $pay_mode   = implode(' , ', $pay_mode);

                        $pay_detail   = explode(' , ', $sing_insal['pay_detail']); array_pop($pay_detail);
                        $pay_detail   = implode(' , ', $pay_detail);
                        

                        $update_installment = array(
                            'status'            => 0,
                            'instal_remaining'  => $sing_insal['instal_amount'],
                            'pay_date'          => $pay_date,
                            'pay_detail'        => $pay_detail,
                            'pay_mode'          => $pay_mode
                        );

                        $this->db->where('id', $sing_insal['id']);
                        $this->db->update('sell_installment_detail', $update_installment);
                        if($total_amount == 0){
                            break;
                        }

                    }
                    else if($total_amount > 0){

                        $pay_date   = explode(' , ', $sing_insal['pay_date']); array_pop($pay_date);
                        $pay_date   = implode(' , ', $pay_date);

                        $pay_mode   = explode(' , ', $sing_insal['pay_mode']); array_pop($pay_mode);
                        $pay_mode   = implode(' , ', $pay_mode);

                        $pay_detail   = explode(' , ', $sing_insal['pay_detail']); array_pop($pay_detail);
                        $pay_detail   = implode(' , ', $pay_detail);

                        $update_installment = array(
                            'status'            => 0,
                            'instal_remaining'  => $sing_insal['instal_remaining'] + $total_amount,
                            'pay_date'          => $pay_date,
                            'pay_detail'        => $pay_detail,
                            'pay_mode'          => $pay_mode
                        );

                        $this->db->where('id',$sing_insal['id']);
                        $this->db->update('sell_installment_detail', $update_installment);


                        $total_amount = 0;
                        break;
                    }

                }



        }
        

        /// multiple install ment


        $sale_rem = $this->payment_model->get_sell($payment['main_id'])['rem_amount'] + $payment['amount_install'];
        

        $update_sell = array(
            'rem_amount'            => $sale_rem
        );

        $this->db->where('id', $payment['main_id']);
        $this->db->update('sell_product', $update_sell);

        $this->db->where('type','installment_commission');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_direct_income');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_bonus_income');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_indirect_income');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_promotion');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_sales');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','installment_profit');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        $this->db->where('type','late_payment');
        $this->db->where('investment_id',$id);
        $this->db->delete('transaction');

        
        $this->db->where('id', $id);
        $this->db->delete('payment');

        $this->session->set_flashdata('msg', 'Payment Deleted Successfully');
        redirect(base_url().'payment/sell_payments');
    }

    /******************************************************************************************************
                                        START Purchase
    *******************************************************************************************************/
    public function purchase_payment()
    {
    	$data['page_title']    = 'Purchase Payments';
        $data['data'] = $this->payment_model->get_sell_payments('purchase');
        $this->load->template('payment/purchase_payment',$data);
    }

     public function purchase()
    {
        $data['page_title'] = 'Purchase Payment';
        $data['all_purchase'] = $this->payment_model->get_pruchase_install_yes_all();
        $this->load->template('payment/purchase',$data);
    }

    public function save_purchase()
    {
        $this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
        $this->form_validation->set_rules('purchase_id', 'Purchase Id', 'required');
        
        if ($this->form_validation->run() == FALSE)
        {
            $data['page_title'] = 'Purchase Payment';
            $data['all_purchase'] = $this->payment_model->get_pruchase_install_yes_all();
            $this->load->template('payment/purchase',$data);
        }
        else
        {
            redirect(base_url().'payment/add_purchase/'.$_POST['purchase_id']);
        }
    }

    public function add_purchase($id = FALSE)
    {
        if($id)
        {
            if($this->payment_model->find_saleer($id))
            {
                $data['page_title'] = 'Pay Purchase Installment';
                $data['id'] = $id;
                $data['purchase'] = $this->payment_model->find_saleer($id)[0];
                $paid = $data['purchase']['share'] - $data['purchase']['advance'] - $data['purchase']['balance'];
                $data['payment'] = $paid;
                $data['get_installment'] = $this->payment_model->get_purchase_installment($id);
                
                $Parterners = [];
                $Parterners[] = ['id' => 0,'user_type_id' => 'company','fullname' => 'Champs'];
                foreach ($this->transaction_model->all_business() as $key => $value) {
                    $Parterners[] = ['id' => $value['id'],'user_type_id' => $value['user_type_id'],'fullname' => $this->transaction_model->get_business_name($value['id'])];
                }

                $data['Parterners'] = $Parterners;

                $this->load->template('payment/add_purchase',$data);
            }
            else
            {
                $this->session->set_flashdata('error', 'Purchase Id Is Not Valid Please Try Again');
                redirect(base_url().'payment/purchase');
            }
        }
        else
        {
            $this->session->set_flashdata('error', 'Purchase Id Is Not Valid Please Try Again');
            redirect(base_url().'payment/purchase');
        }
    }

    public function purchase_pay()
    {
            $payment = array(
                'main_id'               =>  $this->input->post('saler_id'),
                'installment_id'        =>  $this->input->post('installment_id'),
                'type'                  =>  'purchase',
                'date'                  =>  _ddate($this->input->post('date')),
                'amount_install'        =>  $this->input->post('instal_remaining'),
                'late_charge'           =>  trim($this->input->post('late_charge')),
                'pay_type'              =>  $this->input->post('payment_mode'),
                'pay_detail'            =>  $this->input->post('payment_mode_detail'),
                'created_at'            =>  date('Y-m-d H:i:s'),
                'updated_at'            =>  date('Y-m-d H:i:s'),
                'created_by'            =>  $this->session->userdata('id'),
                'updated_by'            =>  $this->session->userdata('id')
            );

            if($this->db->insert('payment', $payment))
            {
                $insert_id = $this->db->insert_id();


                $total_amount = $this->input->post('instal_remaining');
                while($total_amount > 0){

                    $get_installments = $this->db->order_by('id','asc')->get_where('purchase_installment_detail',['status' => '0','saller_id' => $this->input->post('saler_id')])->result_array();

                    foreach ($get_installments as $key => $sing_insal) {

                        if( $total_amount >= $sing_insal['instl_remaning']){

                            $update_installment = array(
                                'status'                      => 1,
                                'instl_remaning'            => 0.00
                            );
                            $this->db->where('id', $sing_insal['id']);
                            $this->db->update('purchase_installment_detail', $update_installment);
                            $total_amount -= $sing_insal['instl_remaning'];
                            if($total_amount == 0){
                                break;
                            }
                            
                        }
                        else if($total_amount > 0)
                        {
                            $update_installment = array(
                                'instl_remaning'            => $sing_insal['instl_remaning'] - $total_amount
                            );
                            $this->db->where('id', $sing_insal['id']);
                            $this->db->update('purchase_installment_detail', $update_installment);
                            $total_amount = 0;
                            break;
                        }

                    }

                }

                

                



                foreach ($this->input->post('parter_id') as $key => $value) {
                    $transaction = [
                        'type'          =>   'purchase_installment',
                        'debit'         =>   $this->input->post('paid')[$key],  
                        'debit_by'      =>   $this->input->post('parter_id')[$key], 
                        'date'          =>   _ddate($this->input->post('date')),
                         'mode'         =>   $this->input->post('payment_mode'),
                        'investment_id' =>   $insert_id,   
                        'created_by'    =>   $this->session->userdata('id'),    
                        'created_at'    =>  date('Y-m-d H:i:s')
                    ];
                    $this->db->insert('transaction', $transaction);
                }

                $update_sell = array(
                    'balance'            => ($this->input->post('sale_remaning_amt') - $this->input->post('instal_remaining'))
                );

                $this->db->where('id', $this->input->post('saler_id'));
                $this->db->update('purchase_seller_dynamic', $update_sell);

                $seller = $this->db->get_where('purchase_seller_dynamic',['id' => $this->input->post('saler_id')])->row_array();

                seller_sell_installment($seller['mobile'],substr($seller['name'],0,15),$this->input->post('instal_remaining'),"P0".$seller['main_id'],date('d-m-y'),date('H:i'),($this->input->post('sale_remaning_amt') - $this->input->post('instal_remaining')));
                
                $this->session->set_flashdata('msg', 'Payment Added Successfully');
                redirect(base_url().'payment/purchase_payment');

            }
            else
            {
                $this->session->set_flashdata('error', 'Problem In Add Payment Try Again');
                redirect(base_url().'payment/purchase');
            }
    }

    /******************************************************************************************************
                                        Edit Purchase
    *******************************************************************************************************/
    
    public function purchase_edit($id)
    {
        if($this->payment_model->_payment($id)){

            $data['page_title'] = 'Edit Purchase Installment';
            $data['purchase_edit'] = $this->payment_model->get_purchase_installment_by_id($this->payment_model->_payment($id)['installment_id']);
            $data['payment'] = $this->payment_model->_payment($id);
            $this->load->template('payment/edit_purchase',$data);

        }
        else
        {
            $this->session->set_flashdata('error', 'Payment Not Found Try Again');
            redirect(base_url().'payment/purchase');
        }
    }

    public function purchase_update()
    {
            $payment = array(
                'date'                  =>  _ddate($this->input->post('date')),
                'late_charge'           =>  trim($this->input->post('late_charge')),
                'pay_type'              =>  $this->input->post('payment_mode'),
                'pay_detail'            =>  $this->input->post('payment_mode_detail'),
                'updated_at'            =>  date('Y-m-d H:i:s'),
                'updated_by'            =>  $this->session->userdata('id')
            );

                $this->db->where('id', $this->input->post('id'));
            if($this->db->update('payment', $payment))
            {

                $transaction = [
                    'type'              =>  'purchase_installment',
                    'debit'             =>  $this->input->post('amount_install') + $this->input->post('late_charge'), 
                    'date'              =>  _ddate($this->input->post('date'))
                ];

                $this->db->where('type', 'purchase_installment');
                $this->db->where('investment_id', $this->input->post('id'));
                $this->db->update('transaction', $transaction);

                $this->session->set_flashdata('msg', 'Payment Updated Successfully');
                redirect(base_url().'payment/purchase_payment');
            }
            else
            {
                $this->session->set_flashdata('error', 'Problem In Update Payment Try Again');
                redirect(base_url().'payment/purchase_payment');
            }
    }

    public function delete_purchase($id)
    {


        $payment = $this->payment_model->_payment($id);

        

        $total_amount = $payment['amount_install'];
        while($total_amount > 0){

            $get_installments = $this->db->query('SELECT * FROM `purchase_installment_detail` where saller_id = "'.$payment['main_id'].'" and purchase_installment_detail.instl_remaning != purchase_installment_detail.instal_amount order by id desc')->result_array();

                foreach ($get_installments as $key => $sing_insal) {

                    if($total_amount >= $sing_insal['instal_amount'] - $sing_insal['instl_remaning']){

                        $total_amount -= $sing_insal['instal_amount'] - $sing_insal['instl_remaning'];

                        $update_installment = array(
                            'status'            => 0,
                            'instl_remaning'  => $sing_insal['instal_amount']
                        );

                        $this->db->where('id', $sing_insal['id']);
                        $this->db->update('purchase_installment_detail', $update_installment);
                        if($total_amount == 0){
                            break;
                        }

                    }
                    else if($total_amount > 0){

                        $update_installment = array(
                            'status'            => 0,
                            'instl_remaning'  => $sing_insal['instl_remaning'] + $total_amount
                        );

                        $this->db->where('id',$sing_insal['id']);
                        $this->db->update('purchase_installment_detail', $update_installment);


                        $total_amount = 0;
                        break;
                    }

                }



        }



        $sale_rem = $this->payment_model->get_purchase_saller($this->payment_model->get_purchase_installment_by_id($payment['installment_id'])['saller_id'])['balance'] + $payment['amount_install'];
        
        
        $update_sell = array(
            'balance'            => $sale_rem
        );

        $this->db->where('id', $payment['main_id']);
        $this->db->update('purchase_seller_dynamic', $update_sell);

        $this->db->where('type', 'purchase_installment');
        $this->db->where('investment_id', $id);
        $this->db->delete('transaction');

        $this->db->where('id', $id);
        $this->db->delete('payment');

        $this->session->set_flashdata('msg', 'Payment Deleted Successfully');
        redirect(base_url().'payment/purchase_payment');
    }



}