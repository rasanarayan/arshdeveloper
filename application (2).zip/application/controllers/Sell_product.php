<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Sell_product extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
        $this->auth->check_session();
        $this->load->model('sel_product');
        $this->load->model('users');
        $this->load->model('add_product');
        $this->load->model('user_genaral');
        $this->load->model('report_model');
        $this->load->model('setting_model');
	}

	public function inv()
	{
		$this->load->view('sell_product/inv');
	}

	public function index()
	{
		$data['page_title']	= 'Sell Products';
		$data['sell'] = $this->sel_product->get_product_all('sell');
		//echo "<pre>"; print_r($data['sell']); die;
		$this->load->template('sell_product/index',$data);
	}
	
	public function all_sell()
	{
		$data['page_title']	= 'All Sell Products';
		$data['sell'] 		= $this->sel_product->get_sell_all('sell');
		$this->load->template('sell_product/all_sell',$data);
	}
	
	public function full_payment_product()
	{
		$data['page_title']	= 'Full Installment Paid';
		$data['sell'] = $this->sel_product->get_product_full_installment('sell');
		$this->load->template('sell_product/full_installment',$data);
	}
	
	public function registry()
	{
		$data['page_title']	= 'Registry Document';
		$data['product_id']	= $this->uri->segment(3);
		$data['registry'] 	= $this->sel_product->get_registry_by_product($data['product_id']);
		
		if(!is_array($data['registry']) && empty($data['registry']))
		{
			redirect(base_url().'sell_product/registry_add/'.$data['product_id'],'');
		}
		$data['document'] 	= $this->sel_product->get_document_by_product($data['product_id']);
		$this->load->template('sell_product/registry',$data);
	}
	public function registry_add()
    {
		$data['product_id']	= $this->uri->segment(3);
		$data['registry'] 	= $this->sel_product->get_registry_by_product($data['product_id']);
		if(is_array($data['registry']) && !empty($data['registry']))
		{
			redirect(base_url().'sell_product/registry/'.$data['product_id'],'');
		}
        $data['page_title'] =   'Add Registry';
		$data['product_id']	= $this->uri->segment(3);
		
        $this->load->template('sell_product/registry_add',$data);
    }
	 
	public function registry_save()
    {	
		$product_id	= $this->uri->segment(3);
		$data['product_id']	= $this->uri->segment(3);
        $path = $_FILES['file']['name'];
        $newName = md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
        $config['upload_path']      = './uploads/documents/';
        $config['allowed_types']    = 'pdf';
        $config['max_size']         = 2000000;
        $config['file_name'] = $newName;
        $this->load->library('upload', $config);
        if($this->upload->do_upload('file'))
        {
            $data = array(
						'document_name'       	=>$this->input->post('name'),
						'sell_product_id'       =>$product_id,
						'file'      			=>$newName,
						'created_at'         	=>date('Y-m-d H:i:s'),
						);
            if($this->db->insert('registry_documnet',$data))
            {
				 $data = array(
								'sell_product_id'       =>$product_id,
								'registry_name'       	=>$this->input->post('registry_name'),
								'registry_date'       	=>$this->input->post('registry_date'),
								'created_at'         	=>date('Y-m-d H:i:s'),
								);
				$this->db->insert('registry_product',$data);
				
				$update_product = array(
								'registry_status'  	=>'1',
								'updated_at'        =>date('Y-m-d H:i:s')
								);
				$this->db->where('id',$product_id);
				$this->db->update('sell_product',$update_product);
				
                $this->session->set_flashdata('msg', 'Document Successfully Uploaded');
                redirect(base_url().'sell_product/registry/'.$product_id,'');
				
            }
            else
            {
                $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
                unlink('./uploads/documents/'.$newName);
                redirect(base_url().'sell_product/document/'.$product_id);
            }
        }
        else
        {
            $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
            redirect(base_url().'sell_product/document/'.$product_id);
        }
    }
	public function document()
    {
        $data['page_title'] =   'Add Document';
		$data['product_id']	= $this->uri->segment(3);
		
        $this->load->template('sell_product/document_add',$data);
    }

    public function document_save()
    {	
		$product_id	= $this->uri->segment(3);
		$data['product_id']	= $this->uri->segment(3);
        $path = $_FILES['file']['name'];
        $newName = md5(microtime(true)).".".pathinfo($path, PATHINFO_EXTENSION); 
        $config['upload_path']      = './uploads/documents/';
        $config['allowed_types']    = 'pdf';
        $config['max_size']         = 2000000;
        $config['file_name'] = $newName;
        $this->load->library('upload', $config);
        if($this->upload->do_upload('file'))
        {
            $data = array(
						'document_name'       	=>$this->input->post('name'),
						'sell_product_id'       =>$product_id,
						'file'      			=> $newName,
						'created_at'         	=> date('Y-m-d H:i:s'),
						);
						
            if($this->db->insert('registry_documnet',$data))
            {
                $this->session->set_flashdata('msg', 'Document Successfully Uploaded');
                redirect(base_url().'sell_product/registry/'.$product_id,'');
				
            }
            else
            {
                $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
                unlink('./uploads/documents/'.$newName);
                redirect(base_url().'sell_product/document/'.$product_id);
            }
        }
        else
        {
            $this->session->set_flashdata('error', 'Problem In File Upload - '.$this->upload->display_errors());
            redirect(base_url().'sell_product/document/'.$product_id);
        }
    }
	
	public function doc_delete($id)
	{	
        $data = $this->db->get_where('registry_documnet',['documnet_id'=>$id])->result_array()[0];
		//echo "<pre>"; print_r($data); die;
        $this->db->where('documnet_id',$id);
        $this->db->delete('registry_documnet');
        
        if(file_exists(FCPATH.'uploads/documents/'.$data['file'])){
            unlink('./uploads/documents/'.$data['file']);
        }

        $this->session->set_flashdata('msg', 'Document Successfully Deleted');
        redirect(base_url().'sell_product/registry/'.$data['sell_product_id']);
    }
	

	public function view($id = false)
	{
		if($id)
		{
			if($this->sel_product->get_product($id))
			{
				$data['page_title']	= 'Sale View';
				$data['sale'] = $this->sel_product->get_product($id)[0];
				$data['installment_detail'] = $this->sel_product->installment_detail_asc($id);
				$this->load->template('sell_product/view',$data);
			}
			else
			{
				$this->session->set_flashdata('error', 'Sale Not Found');
	        	redirect(base_url().'sell_product');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sale Not Found');
	        redirect(base_url().'sell_product');
		}
	}

	public function sale_print($id = false)
	{
		if($id)
		{
			if($this->sel_product->get_product($id))
			{
				$data['page_title']	= 'Sales';
				$data['sale'] = $this->sel_product->get_product($id)[0];
				$data['installment_detail'] = $this->sel_product->installment_detail_asc($id);
				
				$this->load->view('sell_product/print',$data);
			}
			else
			{
				$this->session->set_flashdata('error', 'Sale Not Found');
	        	redirect(base_url().'sell_product');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sale Not Found');
	        redirect(base_url().'sell_product');
		}
	}

	public function sale_report($id = false)
	{
		if($id)
		{
			if($this->db->get_where('sell_product',['id' => $id,'delete_flag' => 0])->result_array())
			{
				$data['page_title']		= 'Sell Report';
				$data['sale']			= $this->report_model->get_sale($id);
				$data['product']		= $this->report_model->get_product($data['sale']['product_id']);
				$data['transaction']	= $this->report_model->sale_profit_report($id);
				$data['all_comission']	= $this->report_model->get_margin_all($id);
				$data['adavnce']	= $this->report_model->get_advance($id);
				$data['adavnce_fry']	= $data['adavnce']['adva_payment'];
				$data['selling_amount']	= $data['adavnce']['selling_amount'];
				//echo"<pre>"; print_r($data['adavnce_fry']); die;
				$this->load->template('sell_product/report',$data);
			}
			else
			{
				$this->session->set_flashdata('error', 'Sale Not Found');
	        	redirect(base_url().'sell_product');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sale Not Found');
	        redirect(base_url().'sell_product');
		}
	}


	public function print_invoice($id = false)
	{
		if($id)
		{
			if($this->sel_product->get_product($id))
			{
				$this->load->model('setting_model');
				$data['page_title']	= 'Sales';
				$data['sale'] = $this->sel_product->get_product($id)[0];
				if($data['sale']['install_packges'] == 'Yes')
				{
					$data['installment_detail'] = $this->sel_product->installment_detail_asc($id);
					$data['installment_expire'] = $this->sel_product->installment_expire_date($id);
					$data['installment_due'] = _vdate($data['installment_detail'][0]['date']);
					$data['installment_expire'] = _vdate($data['installment_expire'][0]['date']);
				}
				else
				{
					$data['installment_due'] = "NA";
					$data['installment_expire'] = "NA";
				}
				$data['customr']	  	=	$this->user_genaral->get_user($this->sel_product->get_product($id)[0]['coust_name']);
				$data['coust_detail'] 	= $this->sel_product->coust_detail($this->sel_product->get_product($id)[0]['coust_name']);
				$data['coust_photo'] 	= $this->db->get_where('user', array('id' => $this->sel_product->get_product($id)[0]['coust_name']))->result_array()[0];
				$data['product_detail'] = $this->sel_product->product_detail($this->sel_product->get_product($id)[0]['product_id']);
				$this->load->view('sell_product/print_invoice',$data);
			}
			else
			{
				$this->session->set_flashdata('error', 'Sale Not Found');
	        	redirect(base_url().'sell_product');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sale Not Found');
	        redirect(base_url().'sell_product');
		}
	}

	public function get_product_data()
	{
		echo json_encode($this->sel_product->get_product_data($_POST['id']));
	}

	public function get_plan_data()
	{
		echo json_encode($this->db->get_where('plan_code',['id'=>$_POST['id']])->result_array());
	}

	public function get_bookings()
	{
		$data = $this->db->get_where('sell_product',['coust_name'=>$_POST['id'],'type'=>'1','delete_flag' => '0'])->result_array();
		if(count($data) > 0)
		{
			$result = '<option value="">Select Booking</option>';
			foreach ($data as $key => $value) 
			{
				$result .= '<option value="'.$value["id"].'">'.$value["id"].'</option>';
			}
		}
		else
		{
			$result = '<option value="">No Bookings</option>';
		}
		echo $result;
	}

	public function get_booking_data()
	{
		echo json_encode($this->db->get_where('sell_product',['id'=>$_POST['id']])->result_array());
	}
	/*///////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Crate / Add  Product
	///////////////////////////////////////////////////////////////////////////////////////////////////////*/
	
	public function installment_add($id)
    {
		$data['product_id']			= $this->uri->segment(3);
		$data['sale'] 				= $this->sel_product->get_product($id)[0];
	
		$installment_total 			= $this->sel_product->installment_total($id);
		
		if($installment_total['instal_total']=='')
		{
			$data['installment_total']	= 0;
		}
		else
		{
			$data['installment_total']	= $installment_total['instal_total'];
		}
		//echo "<pre>"; print_r($data['installment_total']); die;
		$data['page_title']			= 'Installment Add';
        $this->load->template('sell_product/installment_add',$data);
    }
	
	public function installment_save($id)
	{	//echo "<pre>"; print_r($_POST); die;
		$sell_insert_id = $id;
		$instal_pk = $_POST['install_packges'];	// value (Yes / No) time
		if($instal_pk == 'Yes')
		{
			$date = $_POST['date'];
			$time = $_POST['time'];	// Time(montyly, quertly etc..)
			$plus_time;
			if($time == 'Monthly')
			{
				$plus_time = '1';
			}
			else if($time == 'Quarterly')
			{
				$plus_time = '3';
			}
			else if($time == 'Half Yearly')
			{
				$plus_time = '6';
			}
			else if($time == 'Yearly')
			{
				$plus_time = '12';
			}
			$no_install 		= $_POST['no_of_installment'];	
			$instal_pk 			= $_POST['new_installment_amount'];	
			//echo"<pre>"; print_r($instal_pk); die;
			$installment 		= $instal_pk / $no_install;
			$new_date 			= strtotime($date);
			$previous_instal 	= $this->sel_product->installment_detail_desc($id);
			
			if(is_array($previous_instal) && !empty($previous_instal))
			{
				$sale 				= $this->sel_product->get_product($id)[0];
				//echo"<pre>"; print_r($sale); die;
				$update_sell = array(
						'install_packges'    =>    $this->input->post('install_packges'),
						'no_of_installment'  =>    $sale['no_of_installment']+$this->input->post('no_of_installment'),	
						'time_installment'   =>    $sale['time_installment'].','.$this->input->post('time'),
						'time_amount'        =>    $sale['time_amount'].','.$instal_pk,
						'updated_at'         =>    date('Y-m-d H:i:s'),
						'plan_id'			 =>	   $this->input->post('plan_code'),
						);
				//echo"<pre>"; print_r($update_sell); die;
				$this->db->where('id',$id);
				$this->db->update('sell_product',$update_sell);
		
				$rem_amount 	= $this->input->post('new_installment_amount');
				for($i=1; $i <= $no_install; $i++)
				{
					$rem_amount =  $rem_amount -$installment;
					$new_date = strtotime("+".$plus_time." months", $new_date);
					$instal_detail = array(
										'install_packges'   =>	$this->input->post('install_packges'),				
										'no_of_installment' =>	$i,
										'time'   			=>	$this->input->post('time'),
                                        'total'   			=>	$instal_pk,											
										'deal_amount'   	=>	$this->input->post('selling_amount'),					
										'adva_payment'   	=>	$this->input->post('adva_payment'),					
										'instal_amount'   	=>	$installment,	
										'remaining_amount'  =>	$rem_amount,				
										'instal_remaining'  =>	$installment,				
										'date'   	        =>	date('Y-m-d',$new_date),				
										'sell_product_id'   =>	$sell_insert_id
										);
					//echo "<pre>"; print_r($instal_detail); die;
					$insert = $this->db->insert('sell_installment_detail',$instal_detail);
				}
				
			}
			else
			{
				$update_sell = array(
						'install_packges'    =>    $this->input->post('install_packges'),
						'no_of_installment'  =>    $this->input->post('no_of_installment'),	
						'time_installment'   =>    $this->input->post('time'),
                        'time_amount'        =>    $instal_pk,						
						'updated_at'         =>    date('Y-m-d H:i:s'),
						'plan_id'			 =>	   $this->input->post('plan_code'),
						);
				$this->db->where('id',$id);
				$this->db->update('sell_product',$update_sell);
				
				//$rem_amount 		= floatval($this->input->post('selling_amount')) - floatval($this->input->post('adva_payment'));
				$rem_amount 		= $this->input->post('new_installment_amount');
				for($i=1; $i <= $no_install; $i++)
				{
					$rem_amount -= $installment;
					$new_date = strtotime("+".$plus_time." months", $new_date);
					$instal_detail = array(
										'install_packges'   =>	$this->input->post('install_packges'),				
										'no_of_installment' =>	$i,
										'time'   			=>	$this->input->post('time'),					
										'deal_amount'   	=>	$this->input->post('selling_amount'),					
										'adva_payment'   	=>	$this->input->post('adva_payment'),					
										'instal_amount'   	=>	$installment,
                                        'total'   			=>	$instal_pk,										
										'remaining_amount'  =>	$rem_amount,				
										'instal_remaining'  =>	$installment,				
										'date'   	        =>	date('Y-m-d',$new_date),				
										'sell_product_id'   =>	$sell_insert_id
										);
					
					$insert = $this->db->insert('sell_installment_detail',$instal_detail);
				}
			}
			if($insert = TRUE)
			{
				$this->session->set_flashdata('msg', 'Installment Successfully Added');
				redirect(base_url().'sell_product');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Installment Added Try Again');
				redirect(base_url().'sell_product/installment_add/'.$id.'','');
			}
		}
	}
	
	public function add()
	{
	    $data['page_title']			= 'Sales';
		$data['customer'] 			= $this->users->all_agents('customer');
		$data['get_product_all'] 	= $this->add_product->get_product_all_sales('product');
        $data['agent']             	= $this->users->all_agents('agent');
		//echo "<pre>"; print_r($data['agent']); die;
		$this->load->template('sell_product/add',$data);
	}

	public function save()
	{	
		$selling_amount = $this->input->post('adva_payment');
		if($this->user_genaral->get_user($this->session->userdata('id'))['user_type'] == 'agent')
		{
			$status_sale = '1';
		}
		else
		{
			$status_sale = '0';	
		}

		$add_product = array(
							'coust_name'  		 =>    $this->input->post('coust_name'),
							'product_id'   		 =>    $this->input->post('product_id'),
							'date'               =>    date('Y-m-d',strtotime($this->input->post('date'))),
							'ploat_size_yrd'   	 =>    $this->input->post('ploat_size_yrd'),
							'ploat_size_h'   	 =>    $this->input->post('ploat_size_h'),
							'ploat_size'   		 =>    $this->input->post('ploat_size'),
							'selling_amount'     =>    $this->input->post('selling_amount'),
							'adva_payment'   	 =>    $this->input->post('adva_payment'),
							'rem_amount'         =>    $this->input->post('rem_amount'),
							'payment_mode'       =>    $this->input->post('payment_mode'),
							'pay_detail'         =>    $this->input->post('payment_mode_detail'),
							'first_receipt_date' =>    _ddate($this->input->post('first_receipt_date')),
							'receipt_no'         =>    $this->input->post('receipt_no'),
							'book_no'         	 =>    $this->input->post('book_no'),
							//'install_packges'    =>    $this->input->post('install_packges'),
							//'no_of_installment'  =>    $this->input->post('no_of_installment'),	
							//'time_installment'   =>    $this->input->post('time'),	
							'created_by'         =>    $this->input->post('parent_agent'),
							'updated_by'         =>    $this->session->userdata('id'),
							'created_at'         =>    date('Y-m-d H:i:s'),
							'updated_at'         =>    date('Y-m-d H:i:s'),
							'remarks'  			 =>    $this->input->post('remarks'),
							//'plan_id'			 =>	   $this->input->post('plan_code'),
							'sell_status'		 =>	   $status_sale
							);
		//echo "<pre>"; print_r($add_product); die;
		if($this->db->insert('sell_product', $add_product))
		{
			$sell_insert_id = $this->db->insert_id();
		    if($this->session->userdata('id') == '1' )
			{
			$add_p = ['status'	=>	1];
			}else {
			$add_p = ['status'	=>	3];
			}
			$this->db->where('id', $this->input->post('product_id'));
			$this->db->update('create_product', $add_p);
			
			/*$instal_pk = $_POST['install_packges'];	// value (Yes / No) time
			if($instal_pk == 'Yes')
			{
				$date = $_POST['date'];
				$time = $_POST['time'];	// Time(montyly, quertly etc..)
				$plus_time;
				if($time == 'Monthly')
				{
					$plus_time = '1';
				}
				else if($time == 'Quarterly')
				{
					$plus_time = '3';
				}
				else if($time == 'Half Yearly')
				{
					$plus_time = '6';
				}
				else if($time == 'Yearly')
				{
					$plus_time = '12';
				}
				$no_install 	= $_POST['no_of_installment'];	
				$instal_pk 		= $_POST['instal_amount'];	
				$installment 	= $instal_pk / $no_install;
				$new_date 		= strtotime($date);
				$rem_amount 	= floatval($this->input->post('deal_amount')) - floatval($this->input->post('adva_payment'));
				
				for($i=1; $i <= $no_install; $i++)
				{
					$rem_amount -= $installment;
					$new_date = strtotime("+".$plus_time." months", $new_date);
					$instal_detail = array(
										'install_packges'   =>	$this->input->post('install_packges'),				
										'no_of_installment' =>	$i,
										'time'   			=>	$this->input->post('time'),					
										'deal_amount'   	=>	$this->input->post('deal_amount'),					
										'adva_payment'   	=>	$this->input->post('adva_payment'),					
										'instal_amount'   	=>	$installment,	
										'remaining_amount'  =>	$rem_amount,				
										'instal_remaining'  =>	$installment,				
										'date'   	        =>	date('Y-m-d',$new_date),				
										'sell_product_id'   =>	$sell_insert_id
										);
					$insert = $this->db->insert('sell_installment_detail',$instal_detail);
				}
				if($insert = TRUE)
				{
					////////////// payments
					if($this->session->userdata('user_type') == 'subadmin')
					{
						$commission_agent = $this->user_genaral->commission_agent($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'');
						$promotio_agent = $this->user_genaral->promotion_agent($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'');
						$commission_parterner = $this->user_genaral->commission_parterner($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'');
						$after_shares_amount = $commission_agent + $promotio_agent + $commission_parterner;
						$new_due = $selling_amount - $after_shares_amount;
						$sales_profit = $this->user_genaral->share_company_after_all($sell_insert_id,floatval($new_due),_ddate($this->input->post('date')),'');
						$this->sel_product->agent_promotion();
						/////////////  payments end
					}
					// $sales_share = $this->user_genaral->share_company_expence_etc($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')));
					// 
					// $net_profit = $selling_amount - $after_shares_amount;
					// if($net_profit > 0)
					// {
					// }
					// $net_profit -= $sales_profit;
					// if($net_profit > 0)
					// {
					// 	$this->user_genaral->profit_company($sell_insert_id,floatval($net_profit),_ddate($this->input->post('date')));
					// }
					/////////////  payments end
					//
					/////////////  payments end
					customer_sale($this->user_genaral->customer_detail($this->input->post('coust_name'))['mobile'],$this->user_genaral->customer_detail($this->input->post('coust_name'))['fi_name'],$sell_insert_id,$this->input->post('selling_amount'),$this->input->post('adva_payment'),$this->input->post('rem_amount'));
					$this->session->set_flashdata('msg', 'Sell Product Successfully Added');
					redirect(base_url().'sell_product');
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Sell Product Try Again');
					redirect(base_url().'num_sellers/add');
				}
			}
			else
			{*/
				// ////////////// payments
				if($this->session->userdata('user_type') == 'subadmin')
				{
					$commission_agent 		= $this->user_genaral->commission_agent($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'',$this->input->post('payment_mode'));
					
					$promotio_agent 		= $this->user_genaral->promotion_agent($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'',$this->input->post('payment_mode'));
					
					$commission_parterner 	= $this->user_genaral->commission_parterner($sell_insert_id,floatval($selling_amount),_ddate($this->input->post('date')),'',$this->input->post('payment_mode'));
					
					$after_shares_amount 	= $commission_agent + $promotio_agent + $commission_parterner;
					
					$new_due 				= $selling_amount - $after_shares_amount;
					
					$sales_profit 			= $this->user_genaral->share_company_after_all($sell_insert_id,floatval($new_due),_ddate($this->input->post('date')),'',$this->input->post('payment_mode'));
					
					$this->sel_product->agent_promotion();
				}
				// /////////////  payments end
				customer_sale($this->user_genaral->customer_detail($this->input->post('coust_name'))['mobile'],$this->user_genaral->customer_detail($this->input->post('coust_name'))['fi_name'],$sell_insert_id,$this->input->post('selling_amount'),$this->input->post('adva_payment'),$this->input->post('rem_amount'));
				$this->session->set_flashdata('msg', 'Sell Product Successfully Added');
				redirect(base_url().'sell_product');
			//}
		}
	}
	/*/////////////////////////////////////////////////////////////////////////////////////////////////////
									 Edit Shell Product
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/  
/*	public function edit($id = false)
	{	
		if($id)
		{
			$data['page_title']			= 'Edit Sell Products';
			//$data['get_product'] 		= $this->sel_product->get_product($id)[0];
			$data['installment_detail'] = $this->sel_product->installment_detail($id);
			$data['cust'] 				= $this->sel_product->get_product($id);
			$data['customer'] 			= $this->users->all_agents('customer');
			$data['get_product_all'] 	= $this->add_product->get_product_all('product');
			$this->load->template('sell_product/edit',$data);
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
			redirect(base_url().'Sell_product');
		}
	} */
	
	public function edit($id = false)
	{	
		if($id)
		{
			$data['page_title']			= 'Edit Sell Products';
			//$data['get_product'] 		= $this->sel_product->get_product($id)[0];
			$data['installment_detail'] = $this->sel_product->installment_detail($id);
			$data['cust'] 				= $this->sel_product->get_product($id);
			$data['customer'] 			= $this->users->all_agents('customer');
			$data['get_product_all'] 	= $this->add_product->get_product_all('product');
			$data['product_det'] 	    = $this->add_product->get_product_detail($id);
			$product_id             = $data['product_det'][0]['product_id'];
			$data['product_name'] 	= $this->add_product->get_product_name($product_id);
			$selling_amount             = $data['product_det'][0]['selling_amount'];
			$size                       = $data['product_det'][0]['ploat_size'];
			$data['get_product_new'] 	= $this->add_product->get_product_all_sales_plot($selling_amount,$size);
			$this->load->template('sell_product/edit',$data);
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
			redirect(base_url().'Sell_product');
		}
	}
	
	public function update()
	{
		
		$update_product = array(
								'product_id'   		 =>    $this->input->post('product'),
								'selling_amount'     =>    $this->input->post('selling_amount'),
								'ploat_size'   		 =>    $this->input->post('ploat_size'),
								'adva_payment'   	 =>    $this->input->post('adva_payment'),
								'rem_amount'         =>    $this->input->post('rem_amount'),
								'date'               =>    date('Y-m-d',strtotime($this->input->post('date'))),
								'updated_by'         =>    $this->session->userdata('id'),
								'updated_at'         =>    date('Y-m-d H:i:s'),
								'type'               =>    '1'
								);
								//echo"<pre>"; print_r($update_product); die;
		$this->db->where('id', $this->input->post('id'));
		if($this->db->update('sell_product', $update_product))
		{
		$id_main 		= $this->input->post('product_id');
		$change_data = array(
								'status'             =>    '0',
								'updated_at'         =>    date('Y-m-d H:i:s'),
								);
		
		$this->db->where('id',$id_main);
		if($this->db->update('create_product', $change_data))
        {
		$id_mains 		= $this->input->post('product');
		$change_datas = array(
								'status'             =>    '1',
								'updated_at'         =>    date('Y-m-d H:i:s'),
								);
		
		}
         $this->db->where('id',$id_mains);
		 $updatedata = $this->db->update('create_product', $change_datas);
        
		$histroy = array(
		                        'first_id'           =>     $this->input->post('product_id'), 
								'second_id'          =>    $this->input->post('product'),
								'date'               =>    date('Y-m-d'),
								'type'               =>    'plot to plan',
								'created_by'         =>    $this->session->userdata('id'),
								'created_at'         =>    date('Y-m-d H:i:s'),
								);
		
		
		
		$this->db->insert('planplot_histroy',$histroy);
		if($updatedata = TRUE)
		{
			$this->session->set_flashdata('msg', 'Plot converted into plan Successfully');
			redirect(base_url().'sell_product');
		}
		else
		{
			$this->session->set_flashdata('error', 'Not convereted');
			redirect(base_url().'sell_product/edit');
		}
      }

	}	
/*
public function update()
	{
		$update_product = array(
								
								
								'date'               =>    date('Y-m-d',strtotime($this->input->post('date'))),
								'updated_by'         =>    $this->session->userdata('id'),
								'updated_at'         =>    date('Y-m-d H:i:s')
								);
								//echo"<pre>"; print_r($update_product); die;
		$this->db->where('id', $this->input->post('id'));
		if($this->db->update('sell_product', $update_product))
		{
			$instal_pk = $this->input->post('install_packges');	// value (Yes / No) time
			$this->db->where('sell_product_id',$this->input->post('id'));
			$this->db->delete('sell_installment_detail');
			if($instal_pk == 'Yes')
			{
				$date 		= $this->input->post('date');
				$time 		= $this->input->post('time');	// Time(montyly, quertly etc..)
				$plus_time;
				if($time=='Monthly')
				{
					$plus_time = '1';
				}
				else if($time=='Quarterly')
				{
					$plus_time = '3';
				}
				else if($time=='Half Yearly')
				{
					$plus_time = '6';
				}
				else if($time=='Yearly')
				{
					$plus_time = '12';
				}
				$no_install 	= $_POST['no_of_installment'];	
				$instal_pk 		= $_POST['instal_amount'];	
				$installment 	= $instal_pk / $no_install;
				$new_date 		= strtotime($date);
				$rem_amount 	= floatval($this->input->post('deal_amount'));
				
				/*for($i=1; $i <= $no_install; $i++)
				{
					$rem_amount -= $installment;
					$new_date = strtotime("+".$plus_time." months", $new_date);
				
					$instal_detail =  array(
											'install_packges'   =>	$this->input->post('install_packges'),				
											'no_of_installment' =>	$i,
											'time'   			=>	$this->input->post('time'),					
											'deal_amount'   	=>	$this->input->post('deal_amount'),					
											'adva_payment'   	=>	$this->input->post('adva_payment'),					
											'instal_amount'   	=>	$installment,				
											'remaining_amount'  =>	$rem_amount,				
											'date'   	        =>	date('Y-m-d',$new_date),				
											'sell_product_id'   =>	$this->input->post('id')
											);
					$insert = $this->db->insert('sell_installment_detail', $instal_detail);
				}*/
		/*		if($insert = TRUE)
				{
					$this->session->set_flashdata('msg', 'Sell Product Successfully Added');
					redirect(base_url().'sell_product');
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Sell Product Try Again');
					redirect(base_url().'num_sellers/edit');
				}
			}
			else
			{		
				$this->session->set_flashdata('msg', 'Sell Product Successfully Save');
				redirect(base_url().'sell_product');	
			}
		}
	} */	
	/*/////////////////////////////////////////////////////////////////////////////////////////////////////
									DELETE Sell Product 
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/

	public function delete($id = false)
	{	
		if($id)
		{
			if($this->sel_product->get_payments($id) == 0)
			{
				$this->db->where('id',$id);
				if($this->db->update('sell_product',array('updated_by'  => 	$this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
				{
					
					$this->db->where('sell_product_id',$id);
					$this->db->delete('sell_installment_detail');

					$this->db->where('type','commission');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');

					$this->db->where('type','direct_income');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');
					
					$this->db->where('type','indirect_income');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');
					
					$this->db->where('type','bonus_income');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');

					$this->db->where('type','promotion');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');

					$this->db->where('type','sales');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');

					$this->db->where('type','profit');
					$this->db->where('investment_id',$id);
					$this->db->delete('transaction');

					$pd_id = $this->sel_product->get_product($id)[0]['product_id'];

					$add_p = ['status'	=>	0];
					$this->db->where('id',$pd_id);
					$this->db->update('create_product', $add_p);
					$this->session->set_flashdata('msg', 'Sell Product Successfully Deleted');
	        		redirect(base_url().'sell_product');
				}
				else
				{
					$this->session->set_flashdata('error', 'Sell Product Not Deleted Try Again');
	        		redirect(base_url().'sell_product');
				}
			}
			else
			{
				$this->session->set_flashdata('error', 'Please Delete Installments');
	        	redirect(base_url().'sell_product');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product');
		}
	}	
	
	public function cancel($id = false)
	{
		if($id)
		{
			$this->db->where("id",$id);
			$this->db->update("sell_product",['cancel' => '1','updated_at' => date('Y-m-d H:i:s')]);
			$sales = $this->sel_product->get_product($id);
			$this->db->where("id",$sales[0]['product_id']);
			$this->db->update("create_product",['status' => '0']);

			$name 		= $this->sel_product->coust_detail($this->sel_product->get_product($id)[0]['coust_name'])['fi_name'];
			$mobile 	= $this->sel_product->coust_detail($this->sel_product->get_product($id)[0]['coust_name'])['mobile'];
			cancle_plan($mobile,$name,$id);
			$this->session->set_flashdata('msg', 'Plan Successfully Removed');
        	redirect(base_url().'sell_product');
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product');
		}
	}	


	public function change_status($id)
	{
		if($id)
		{
			$this->db->where("id",$id);
			$this->db->update("sell_product",['sell_status' => '1']);
			$this->session->set_flashdata('msg', 'Request Sended To Admin');
        	redirect(base_url().'sell_product');
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product');
		}
	}

	public function request_sale()
	{
		$data['page_title']	= 'Sell Requests';
		$data['sell'] = $this->sel_product->get_product_all_panding();
		$this->load->template('sell_product/request_list',$data);
	}

/*	public function reject_req($id)
	{
		if($id)
		{
			$this->db->where("id",$id);
			$this->db->update("sell_product",['sell_status' => '2']);
			$this->session->set_flashdata('msg', 'Request Rejected');
        	redirect(base_url().'sell_product/request_sale');
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product/request_sale');
		}
	} 
	



	public function apporve_req($id)
	{
		if($id)
		{
			$this->db->where("id",$id);
			$this->db->update("sell_product",['sell_status' => '0']);
			$sell_insert_id = $id;
			$selll 			= $this->sel_product->get_main_sell($id)[0];
			$selling_amount = $selll['adva_payment'];
			$date 			= $selll['date'];
			
			// ////////////// payments

			$commission_agent 		= $this->user_genaral->commission_agent($sell_insert_id,floatval($selling_amount),$date,'');
			$promotio_agent 		= $this->user_genaral->promotion_agent($sell_insert_id,floatval($selling_amount),$date,'');
			$commission_parterner 	= $this->user_genaral->commission_parterner($sell_insert_id,floatval($selling_amount),$date,'');
			$after_shares_amount 	= $commission_agent + $promotio_agent + $commission_parterner;
			$new_due 				= $selling_amount - $after_shares_amount;
			$sales_profit 			= $this->user_genaral->share_company_after_all($sell_insert_id,floatval($new_due),$date,'');
			$this->sel_product->agent_promotion();
			// /////////////  payments end
			$this->session->set_flashdata('msg', 'Request Apporved');
        	redirect(base_url().'sell_product/request_sale');

		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product/request_sale');
		}
	} */
	
	public function reject_req()
	{
		$id = $this->input->post('withdraw_id');
		if($id)
		{
			
			//echo"<pre>"; print_r($id); die;
			$data['getvalue']	= $this->sel_product->getselliddata($id);
			$sellid = $data['getvalue'][0]['product_id'];
			$this->db->where("id",$sellid);
			$this->db->update("create_product",['status' => '0']);
			//echo"<pre>"; print_r($sellid); die;
			$this->db->where("id",$id);
			$this->db->update("sell_product",['sell_status' => '2','cancel' => '1' , 'response_remarks' => $this->input->post('remark')]);
			
			
			$this->session->set_flashdata('msg', 'Request Rejected');
        	redirect(base_url().'sell_product/request_sale');
		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product/request_sale');
		}
	}

	public function apporve_req()
	{
		
    	$id = $this->input->post('withdraw_id');
		$selll 			= $this->sel_product->get_main_sell($id)[0];
		$mode = $selll['payment_mode'];
		if($id)
		{
			$this->db->where("id",$id);
			$posted_data = [
			'sell_status' => '0' ,
			'response_remarks' => $this->input->post('remark'),
			];
			
			//echo"<pre>"; print_r($posted_data); die;
			$this->db->update("sell_product", $posted_data);
			
			$sell_insert_id = $id;
			$selll 			= $this->sel_product->get_main_sell($id)[0];
			$selling_amount = $selll['adva_payment'];
			$date 			= $selll['date'];
			
			$data['getvalue']	= $this->sel_product->getselliddata($id);
			$sellid = $data['getvalue'][0]['product_id'];
			$this->db->where("id",$sellid);
			$this->db->update("create_product",['status' => '1']);
			
			// ////////////// payments

			$commission_agent 		= $this->user_genaral->commission_agent($sell_insert_id,floatval($selling_amount),$date,'',$mode);
			$promotio_agent 		= $this->user_genaral->promotion_agent($sell_insert_id,floatval($selling_amount),$date,'',$mode);
			$commission_parterner 	= $this->user_genaral->commission_parterner($sell_insert_id,floatval($selling_amount),$date,'',$mode);
			$after_shares_amount 	= $commission_agent + $promotio_agent + $commission_parterner;
			$new_due 				= $selling_amount - $after_shares_amount;
			$sales_profit 			= $this->user_genaral->share_company_after_all($sell_insert_id,floatval($new_due),$date,'',$mode);
			$this->sel_product->agent_promotion();
			// /////////////  payments end
			$this->session->set_flashdata('msg', 'Request Apporved');
        	redirect(base_url().'sell_product/request_sale');

		}
		else
		{
			$this->session->set_flashdata('error', 'Sell Product Not Found');
	        redirect(base_url().'sell_product/request_sale');
		}
	}



}
?>