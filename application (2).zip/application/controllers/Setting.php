<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->auth->check_session();
        $this->load->model('validate');
        $this->load->model('users');
        $this->load->model('setting_model');
    }


	public function plan_codes()
	{
		//$this->load->model('users');
		$data['page_title']	= 'Product Plans';
		$data['plan_code'] = $this->setting_model->get_plan_code();
		$this->load->template('setting/plan_codes',$data);
	}
	
	
		/*//////////////////////////////////////////////////////////////////////////////////////////////////////
		  								location for circlerate
	//////////////////////////////////////////////////////////////////////////////////////////////////////*/
	
	public function locations()
	{
		
		$data['page_title']	= 'Locations';
		$data['locations'] = $this->setting_model->get_locations_for_circlerate();
		//echo"<pre>"; print_r($data['locations']); die;
		$this->load->template('setting/location_circle',$data);
	}

	public function add_locations()
	{	
	    $data['page_title']	= 'Add Locations';
	    $this->load->template('setting/add_locations',$data);
	}

	public function add_locations_save()
	 {
		//$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		$this->form_validation->set_rules('title', 'Title', 'trim|required|is_unique[late_charges.title]|min_length[3]|max_length[240]');
		$this->form_validation->set_rules('charge', 'Charge', 'trim|required|integer');
		$this->form_validation->set_rules('codep', 'Code P charges', 'trim|required');
	    
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add location with amount';
			$this->load->template('setting/add_locations',$data);
		}
		else
		{
			
			$add_lands = array(
		        'title'           => 	$this->input->post('title'),
		        'charge'               => 	$this->input->post('charge'),
				'codep'               => 	$this->input->post('codep'),
		        'created_by'		  => 	$this->session->userdata('id'),
		        'updated_by'		  => 	$this->session->userdata('id'),
		        'created_at' 		  => 	date('Y-m-d H:i:s'),
		        'updated_at' 		  => 	date('Y-m-d H:i:s')
		        
			);

			if($this->db->insert('locations_for_circlerate', $add_lands))
			{
				$this->session->set_flashdata('msg', 'Locations Successfully Saved');
	        	redirect(base_url().'setting/locations');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In add locations Try Again');
	        	redirect(base_url().'setting/add_locations');
			}

		}	
	}
    

     public function lands_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);

			if($this -> db -> delete('locations_for_circlerate'))
			{
				$this->session->set_flashdata('msg', 'Lands Successfully Deleted');
        		redirect(base_url().'setting/locations');
			}
			else{
				$this->session->set_flashdata('error', 'Lands Not Deleted Try Again');
        		redirect(base_url().'setting/locations');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Lands Not Found');
	        redirect(base_url().'setting/locations');
		}
	}

	 public function Lands_edit($id = false)
	{	
		if($id)
		{
			$data['page_title']	= 'Edit lands details';
			$data['land_single'] = $this->setting_model->edit_lands_for_circele_rate($id);
			$this->load->template('setting/edit_lands',$data);

			
		}
		else
		{
			$this->session->set_flashdata('error', 'land Not Found Try Again');
	        redirect(base_url().'setting/locations');
		}
	    
	}


public function lands_update()
	{
	   
	       
		    $this->form_validation->set_rules('title', 'Title', 'required|min_length[3]|max_length[70]');
			$this->form_validation->set_rules('charge', 'charge', 'trim|required');
			$this->form_validation->set_rules('codep', 'Code P charges', 'trim|required');
			
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit Lands details';
				$data['land_single'] = $this->setting_model->edit_lands_for_circele_rate($this->input->post('id'));
				$this->load->template('setting/edit_lands',$data);
			}
			else
			{
				$lands = array(
					'title'  		     =>    $this->input->post('title'),
					'charge'   		     =>    $this->input->post('charge'),
					'codep'   		     =>    $this->input->post('codep'),
					'updated_by'   		 =>    $this->session->userdata('id'),
					'updated_at'   	     =>    date('Y-m-d H:i:s')
				);

				$this->db->where('id', $this->input->post('id'));

				if($this->db->update('locations_for_circlerate', $lands)){
					
					$this->session->set_flashdata('msg', 'lands Successfully Updated');
		        	redirect(base_url().'setting/locations');

		        }
		        else
		        {
		        	$this->session->set_flashdata('error', 'Problem In Lands Try Again');
				    redirect(base_url().'setting/Lands_edit');
		        }
		    }
    }
		/*//////////////////////////////////////////////////////////////////////////////////////////////////////
		  								location for circlerate
	//////////////////////////////////////////////////////////////////////////////////////////////////////*/
	
	 public function circlerate_list()
	{
		//$this->load->model('users');
		$data['page_title']	= 'Circle rate list';
		$data['list'] = $this->setting_model->get_circleratelist();
		//echo"<pre>"; print_r($data['list']); die;
		$this->load->template('setting/circleratelist',$data);
	}
	

   public function add_circlerate()
	{	
	    $data['page_title']	= 'Calculate circle rate';
	    $data['locations'] = $this->setting_model->get_locations_for_circlerate();
		$data['customer'] = $this->setting_model->get_customer(array('user_type'=> 'customer','block_status'=> '1'));
	     //echo"<pre>"; print_r($data['customer']); die; 
		 $data['dynamicdata'] = $this->setting_model->get_master();
	   
	    $this->load->template('setting/calculate_circlerate',$data);
	}

	  public function add_circlerate_save(){
		//$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		$this->form_validation->set_rules('size', 'Size', 'trim|required|min_length[2]|max_length[15]|integer');
		$this->form_validation->set_rules('land', 'Land', 'trim|required');
		//$this->form_validation->set_rules('customer', 'Customer', 'trim|required');
		$this->form_validation->set_rules('corner', 'Corner', 'trim|required');
		$this->form_validation->set_rules('park_face', 'Park face', 'trim|required');
	    $this->form_validation->set_rules('behalfoff', 'Behalf-off', 'trim|required');
		
		if ($this->form_validation->run() == FALSE)
		{
			 $data['locations'] = $this->setting_model->get_locations_for_circlerate();
			 $data['dynamicdata'] = $this->setting_model->get_master();
			 $data['customer'] = $this->setting_model->get_customer(array('user_type'=> 'customer','block_status'=> '1'));
	         $data['page_title']	= 'Calculate circle rate';
			$this->load->template('setting/calculate_circlerate',$data);
		}
		else
		{
		   
            $land_id = explode("/",$this->input->post('land'));
			$behalfoffvalue = explode("/",$this->input->post('behalfoff'));
			$land_id_main = $land_id[1];
			$behalfvalue = $behalfoffvalue[0];
			$behalfstatic = $behalfoffvalue[1];
			$size_in_gaj = $this->input->post('size');
			$size_in_square_meter = $size_in_gaj * 0.8361;
			$government_value = $size_in_square_meter * $this->input->post('land');
			$data['dynamicdata'] = $this->setting_model->get_master();
			$corner = $this->input->post('corner');
			if($corner == '1')
			{
			$corner_value =	 ($government_value * $data['dynamicdata']['corner_charge'])/100;
				
			}else{
			$corner_value =	 '0';	
			}
			
			$park = $this->input->post('park_face');
			if($park == '1')
			{
			$parkface =	 ($government_value * $data['dynamicdata']['park_charge'])/100;
				
			}else{
			$parkface =	 '0';	
			}
				
		    $stamp_charge     = ($government_value * $behalfvalue)/100;
			$whole = explode('.', $stamp_charge);
            $final =  $whole[0];
			// print_r($final); die;
			$lasttwo = substr($final, -2);
			$subtract= (100-($lasttwo));
			$finalstamp_charge = $final+$subtract;
            		
		     
			 $data['codepp'] = $this->setting_model->get_codep($land_id_main);
			 $codep_percentage  = $data['codepp'][0]['codep'];
           	 $codep_registy_charge  = $government_value * $codep_percentage/100;		 
		     //$codep_registy_charge     = $government_value * $data['dynamicdata']['registry_charge']/100;
		     $totals = $government_value + $finalstamp_charge +  $codep_registy_charge + $parkface + $corner_value;
			 $who = explode('.', $totals);
             $finall =  $who[0];
			 // print_r($final); die;
			 $lasttwoval = substr($finall, -2);
			 $subtracts= (100-($lasttwoval));
			 $total = $finall+$subtracts;
			
			
			
			$add_lands = array(
		        'size'                     => 	$this->input->post('size'),
				'size_sq_meter'            => 	$size_in_square_meter,
				'customer'                 =>   $this->input->post('customer'),
				'corner'                   => 	$corner_value,
				'parkface'                 => 	$parkface,
				'land'                     => 	$land_id_main,
		        'behalfoff'                => 	$behalfstatic,
		        'governmentvalue'          => 	$government_value,
		        'stamp_charge'             => 	$finalstamp_charge,
		        'codep_registry_charge'    => 	$codep_registy_charge,
		        'total_amount'             =>   $totals,
				'total_amount_rountoff'    =>   $total,
                'created_by'		       => 	$this->session->userdata('id'),
		        'updated_by'		       => 	$this->session->userdata('id'),
		        'created_at' 		       => 	date('Y-m-d H:i:s'),
		        'updated_at' 		       => 	date('Y-m-d H:i:s')
		        
			);

           //echo"<pre>"; print_r($add_lands); die;	
			if($this->db->insert('circle_rate_list', $add_lands))
			{
				$this->session->set_flashdata('msg', 'Circle Rate Successfully Saved');
	        	redirect(base_url().'setting/circlerate_list');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In create Circle rate Try Again');
	        	redirect(base_url().'setting/add_circlerate');
			}

		}	
	}


	  public function circlerate_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);

			if($this -> db -> delete('circle_rate_list'))
			{
				$this->session->set_flashdata('msg', 'Circle rate Successfully Deleted');
        		redirect(base_url().'setting/circlerate_list');
			}
			else{
				$this->session->set_flashdata('error', 'Circle rate Not Deleted Try Again');
        		redirect(base_url().'setting/circlerate_list');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Lands Not Found');
	        redirect(base_url().'setting/locations');
		}
	}

     
	
	/*//////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Add Paln Number
	//////////////////////////////////////////////////////////////////////////////////////////////////////*/


	public function add_plan_code()
	{	
	    $data['page_title']	= 'Add Plan';
		$this->load->template('setting/add_plan_code',$data);
	}

	public function plan_code_save(){
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		$this->form_validation->set_rules('plan_code', 'Plan Name', 'trim|required|is_unique[plan_code.plan_code]|min_length[3]|max_length[240]');
		$this->form_validation->set_rules('month', 'Month', 'trim|required|integer|min_length[1]|max_length[240]');
		$this->form_validation->set_rules('year', 'Year', 'trim|required|max_length[240]');



		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add Plan';
			$this->load->template('setting/add_plan_code',$data);
		}
		else
		{
			
			$plan_code_insert = array(
		        'plan_code'           => 	$this->input->post('plan_code'),
		        'month'               => 	$this->input->post('month'),
		        'year'        		  => 	$this->input->post('year'),
		        'created_by'		  => 	$this->session->userdata('id'),
		        'updated_by'		  => 	$this->session->userdata('id'),
		        'created_at' 		  => 	date('Y-m-d H:i:s'),
		        'updated_at' 		  => 	date('Y-m-d H:i:s')
		        
			);

			if($this->db->insert('plan_code', $plan_code_insert))
			{
				$this->session->set_flashdata('msg', 'Plan Successfully Saved');
	        	redirect(base_url().'setting/plan_codes');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Plan Try Again');
	        	redirect(base_url().'setting/add_plan_code');
			}

		}	
	}
	
	public function lateinstalment_charge()
	{
		//$this->load->model('users');
		$data['page_title']	= 'Late installment charges';
		$data['late_installment'] = $this->setting_model->get_late_charges();
		//echo"<pre>"; print_r($data['late_installment']); die;
		$this->load->template('setting/late_fees',$data);
	}

	public function add_installment()
	{	
	    $data['page_title']	= 'Add late installment charges';
	    $this->load->template('setting/add_installment_charge',$data);
	}

	 public function add_installment_save(){
		//$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		$this->form_validation->set_rules('title', 'Title', 'trim|required|is_unique[late_charges.title]|min_length[3]|max_length[240]');
		$this->form_validation->set_rules('charge', 'Charge', 'trim|required|integer|numeric|less_than[100]');
	    
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add late installment charges';
			$this->load->template('setting/add_installment_charge',$data);
		}
		else
		{
			
			$plan_code_insert = array(
		        'title'           => 	$this->input->post('title'),
		        'charge'               => 	$this->input->post('charge'),
		        'created_by'		  => 	$this->session->userdata('id'),
		        'updated_by'		  => 	$this->session->userdata('id'),
		        'created_at' 		  => 	date('Y-m-d H:i:s'),
		        'updated_at' 		  => 	date('Y-m-d H:i:s')
		        
			);

			if($this->db->insert('late_charges', $plan_code_insert))
			{
				$this->session->set_flashdata('msg', 'Installment charges Successfully Saved');
	        	redirect(base_url().'setting/lateinstalment_charge');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In installment charges Try Again');
	        	redirect(base_url().'setting/add_installment');
			}

		}	
	}


	/*/////////////////////////////////////////////////////////////////////////////////////////////////////
		  								 Edit Plan Number
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/  

	
	public function plan_code_edit($id = false)
	{	
		if($id)
		{
			$data['page_title']	= 'Edit Plan';
			$data['plan_code'] = $this->setting_model->edit_plan_code($id);
			$this->load->template('setting/edit_plan_code',$data);

			
		}
		else
		{
			$this->session->set_flashdata('error', 'Plan Not Found Try Again');
	        redirect(base_url().'setting/instllment_charge_edit');
		}
	    
	}

	public function plan_code_update(){
			$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
			if($this->setting_model->get_plan_code_single($this->input->post('id'))['plan_code'] != $this->input->post('plan_code') )
			{
				$_is_unique = '|is_unique[plan_code.plan_code]';
			}
			else
			{
				$_is_unique = '';
			}
			$this->form_validation->set_rules('plan_code', 'Plan Name', 'trim'.$_is_unique.'|required|min_length[3]|max_length[240]');
			$this->form_validation->set_rules('month', 'Month', 'trim|required|integer|min_length[1]|max_length[240]');
			$this->form_validation->set_rules('year', 'Year', 'trim|required|max_length[240]');
			
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit Plan';
				$data['plan_code'] = $this->setting_model->edit_plan_code($this->input->post('id'));
				$this->load->template('setting/edit_plan_code',$data);
			}
			else
			{
				$plan_code_update = array(
					'plan_code'  		 =>    $this->input->post('plan_code'),
					'month'   		     =>    $this->input->post('month'),
					'year'               =>    $this->input->post('year'),
					'updated_by'   		 =>    $this->session->userdata('id'),
					'updated_at'   	     =>    date('Y-m-d H:i:s')
				);

				$this->db->where('id', $this->input->post('id'));

				if($this->db->update('plan_code', $plan_code_update)){
					
					$this->session->set_flashdata('msg', 'Plan Successfully Updated');
		        	redirect(base_url().'setting/plan_codes');

		        }
		        else
		        {
		        	$this->session->set_flashdata('error', 'Problem In Edit Plan Try Again');
				    redirect(base_url().'setting/edit_plan_code');
		        }
		    }
    }

    /*/////////////////////////////////////////////////////////////////////////////////////////////////////
		  								DELETE Plan Number
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/

	public function plan_code_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('plan_code',array('updated_by'  => $this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
			{
				$this->session->set_flashdata('msg', 'Plan Successfully Deleted');
        		redirect(base_url().'setting/plan_codes');
			}
			else{
				$this->session->set_flashdata('error', 'Plan Not Deleted Try Again');
        		redirect(base_url().'setting/plan_codes');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Plan Not Found');
	        redirect(base_url().'setting/plan_codes');
		}
	}
	
	public function visit_report()
	{
		//$this->load->model('users');
		$data['page_title']	= 'Visit Report';
		$data['visit_report'] = $this->setting_model->get_visit_report();
		//echo"<pre>"; print_r($data['visit_report']); die;
		$this->load->template('setting/visit_report',$data);
	}
	
	public function attendance()
	{
		
		$data['page_title']	= 'Attendance';
		$data['visit_attend'] = $this->setting_model->get_attendance();
		$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
		//echo"<pre>"; print_r($data['visit_attend']); die;
		$this->load->template('setting/visit_attendance',$data);
	}
	
	public function sallary()
	{
		
		$data['page_title']	= 'Sallary';
		$data['sallary'] 		= $this->setting_model->get_sallary(array('delete_flag'=>'0'));
		//echo"<pre>"; print_r($data['sallary']); die;
		$this->load->template('setting/visit_sallary',$data);
	}
	
	
	public function delete_report()
	{
		
		$data['page_title']	= 'Deleted Visiting Reports';
		$data['delete_visit_report'] = $this->setting_model->get_delete_report();
		//echo"<pre>"; print_r($data['delete_visit_report']); die;
		$this->load->template('setting/delete_visiting_report',$data);
	}
	
	
	
	
	
	/*//////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Add visit report
	//////////////////////////////////////////////////////////////////////////////////////////////////////*/
    public function get_user()
	{
		$user_type 			= $this->input->get_post('user_type');
		$agents	= $this->setting_model->get_usr_agent(array('user_type'=>$user_type));?>
		<option value="">Select User</option>
		<?php
		if(is_array($agents) && !empty($agents))
		{
			
		
			foreach ($agents as $value) {
				
		?>
		<option value="<?php echo $value["user_name"]; ?>"><?php echo $value["user_name"]; ?></option>
		<?php
		}
		
		}
		
	}
	
		
	
	 public function get_user_edit()
	{
		$user_type 			= $this->input->get_post('user_type');
		$agents	= $this->setting_model->get_usr_agent(array('user_type'=>$user_type));?>
		<option value="">Select User</option>
		<?php
		if(is_array($agents) && !empty($agents))
		{
			
		
			foreach ($agents as $value) {
				
		?>
		<option  value="<?php echo $value["user_name"]; ?>"><?php echo $value["user_name"]; ?></option>
		<?php
		}
		
		}
		
	}
	
	
	public function request()
	{
		$id 			= $this->input->get_post('agent_id');
		$total_amount 	= $this->setting_model->get_balance($id);
		$balance 		= $total_amount['balance'];
		echo $balance;
	}
	
	public function mobile()
	{
		$id 			= $this->input->get_post('agent_id');
		$mobile_number 	= $this->setting_model->get_mobile($id);
		$phone 		= $mobile_number['mobile'];
		echo $phone;
	}
	
	public function get_sallary()
	{
		$id 			= $this->input->get_post('user_type');
		$fullsal 	= $this->setting_model->get_sallaryy(array('user_id'=> $id));
		$sallary 		= $fullsal[0]['sallary'];
		echo $sallary;
	}
	
	public function total_addendence()
	{
		$month_type 			= $this->input->get_post('month_type');
		$year 			        = $this->input->get_post('year');
		$emptype 			    = $this->input->get_post('emptype');
		$fulldayscount 	= $this->setting_model->get_total_days($emptype,$month_type,$year);
	    $fulldays 		= $fulldayscount[0]['total_num'];
		$num['fulldayy'] = $fulldays;
		$cal_sallary 	= $this->setting_model->get_data_emp(array('user_id'=> $emptype));
	    $num['fullsallary'] 		= ($cal_sallary[0]['sallary_per_day'] * $fulldays);
		echo json_encode($num);
		
	}



	public function add_visit_report()
	{	
	    $data['page_title']	= 'Add Visit report';
		$data['agents'] 		= $this->setting_model->get_usr_agent(array('user_type'=>'agent'));
		//echo"<pre>"; print_r($data['agents']); die;
		$this->load->template('setting/add_visit_report',$data);
	}
	
	public function add_attendance()
	{	
	    $data['page_title']	= 'Add Attendance';
		$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
		//echo"<pre>"; print_r($data['employees']); die;
		$this->load->template('setting/add_attendance',$data);
	}
	
	public function add_sallary()
	{	
	    $data['page_title']	= 'Add Sallary';
		$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
		//echo"<pre>"; print_r($data['employees']); die;
		$this->load->template('setting/add_sallary',$data);
	}
	
	public function sallary_save()
	{
	
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
        $this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|max_length[240]');
        if ($this->form_validation->run() == FALSE)
		{
			 $data['page_title']	= 'Add Sallary';
		     $data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
		     $this->load->template('setting/add_sallary',$data);
		}
		else
		{
			
			$sallary = array(
		        'emp_id'          		 => 	$this->input->post('emp_type'),
				'total_sallary'          => 	$this->input->post('total_sallary'),
				'year_type'              => 	$this->input->post('year_type'),
				'month_type'             => 	$this->input->post('month_type'),
				'total_days'             => 	$this->input->post('total_days'),
				'paid_sallary'           => 	$this->input->post('paid_sallary'),
				'visit_date'                   => 	date("Y-m-d", strtotime($this->input->post('visit_date'))),
				'remarks'                => 	$this->input->post('remarks'),
				'created_by'		     => 	$this->session->userdata('id'),
		        'created_at' 		     => 	date('Y-m-d H:i:s')
		    );
            //echo"<pre>"; print_r($sallary); die;
			if($this->db->insert('sallary', $sallary))
			{
				$this->session->set_flashdata('msg', 'Sallary Successfully Saved');
	        	redirect(base_url().'setting/sallary');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Sallary Try Again');
	        	redirect(base_url().'setting/add_sallary');
			}

		}	
	}
	
	


	public function attendance_save()
	{
	
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
        $this->form_validation->set_rules('emp_type', 'Employee type', 'required');
		$this->form_validation->set_rules('visit_date', 'visit_date', 'trim|required');
		$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|max_length[240]');
        $this->form_validation->set_rules('att_type', 'Attendence type', 'required');
       

		if ($this->form_validation->run() == FALSE)
		{
			$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
			$data['page_title']	= 'Add attendence';
			$this->load->template('setting/add_attendance',$data);
		}
		else
		{
			
			$attendence = array(
		        'Emp_id'          		 => 	$this->input->post('emp_type'),
				'attendence_type'        => 	$this->input->post('att_type'),
				'visit_date'             => 	date("Y-m-d", strtotime($this->input->post('visit_date'))),
				'remarks'                => 	$this->input->post('remarks'),
				'intime'                 => 	$this->input->post('intime'),
				'outtime'                => 	$this->input->post('outtime'),
				'created_by'		     => 	$this->session->userdata('id'),
		        'updated_by'		     => 	$this->session->userdata('id'),
		        'created_at' 		     => 	date('Y-m-d H:i:s')
		    );
            //echo"<pre>"; print_r($attendence); die;
			if($this->db->insert('attendance', $attendence))
			{
				$this->session->set_flashdata('msg', 'Attendence Successfully Saved');
	        	redirect(base_url().'setting/attendance');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In attendence Try Again');
	        	redirect(base_url().'setting/add_visit_report');
			}

		}	
	}
	
	
	public function visit_report_save()
	{
	
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');

		$this->form_validation->set_rules('user_type', 'user type', 'required');
		$this->form_validation->set_rules('user_id', 'user name', 'trim|required');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|max_length[10]');
		$this->form_validation->set_rules('visit_site', 'Visit site', 'trim|required|min_length[3]|max_length[240]');
		$this->form_validation->set_rules('visit_date', 'visit_date', 'trim|required');
		$this->form_validation->set_rules('promise_date', 'promise_date', 'trim|required');
		$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|max_length[240]');
        $this->form_validation->set_rules('branchname', 'branchname', 'trim|max_length[100]');


		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add Visit report';
			$this->load->template('setting/add_visit_report',$data);
		}
		else
		{
			
			$visit_report_insert = array(
		        'name'          		 => 	$this->input->post('user_type'),
				'agent_name'           	 => 	$this->input->post('user_id'),
				'mobile'                 => 	$this->input->post('mobile'),
				'visit_site'             => 	$this->input->post('visit_site'),
			    'visit_date'             => 	date("Y-m-d", strtotime($this->input->post('visit_date'))),
				'promise_date'           => 	$this->input->post('promise_date'),
				'remarks'                => 	$this->input->post('remarks'),
				'time'                   => 	$this->input->post('intime'),
				'branchname'             => 	$this->input->post('branchname'),
				'created_by'		     => 	$this->session->userdata('id'),
		        'updated_by'		     => 	$this->session->userdata('id'),
		        'created_at' 		     => 	date('Y-m-d H:i:s'),
		       // 'updated_at' 		     => 	date('Y-m-d H:i:s')
		        
			);
            //echo"<pre>"; print_r($visit_report_insert); die;
			if($this->db->insert('visit_report', $visit_report_insert))
			{
				$this->session->set_flashdata('msg', 'Visiting report Successfully Saved');
	        	redirect(base_url().'setting/visit_report');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Plan Try Again');
	        	redirect(base_url().'setting/add_attendance');
			}

		}	
	}
	
	
	
	public function visit_report_edit($id = false)
	{	
		if($id)
		{
			$data['page_title']	= 'Edit visit report';
			$data['visit_report'] = $this->setting_model->edit_visit_report($id);
			//echo"<pre>"; print_r($data['visit_report']); die;
			$this->load->template('setting/edit_visit_report',$data);

			
		}
		else
		{
			$this->session->set_flashdata('error', 'Plan Not Found Try Again');
	        redirect(base_url().'setting/edit_visit_report');
		}
	    
	}
	
	

	public function visit_report_update(){
		
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('user_type', 'User_type', 'trim|required');
		$this->form_validation->set_rules('user_id', 'User name', 'trim|required');
		$this->form_validation->set_rules('mobile', 'mobile', 'trim|required|max_length[10]');
		$this->form_validation->set_rules('visit_site', 'Visit site', 'trim|required|min_length[3]|max_length[240]');
		$this->form_validation->set_rules('visit_date', 'visit_date', 'trim|required');
		$this->form_validation->set_rules('promise_date', 'promise_date', 'trim|required');
		$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|max_length[240]');
		$this->form_validation->set_rules('branchname', 'Branch name', 'trim|max_length[240]');
			
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit visit report';
				$data['plan_code'] = $this->setting_model->edit_visit_report($this->input->post('id'));
				$this->load->template('setting/edit_visit_report',$data);
			}
			else
			{
				
				
				$visit_report_insert = array(
		        'name'          		 => 	$this->input->post('user_type'),
				'agent_name'           	 => 	$this->input->post('user_id'),
				'mobile'                 => 	$this->input->post('mobile'),
				'visit_site'             => 	$this->input->post('visit_site'),
				'visit_date'             => 	$this->input->post('visit_date'),
				'promise_date'           => 	$this->input->post('promise_date'),
				'time'                   => 	$this->input->post('intime'),
				'branchname'             => 	$this->input->post('branchname'),
				'remarks'                => 	$this->input->post('remarks'),
				'updated_by'		     => 	$this->session->userdata('id'),
		        'updated_at' 		     => 	date('Y-m-d H:i:s')
		        
			);
			//echo"<pre>"; print_r($visit_report_insert); die;
			
			$this->db->where('id', $this->input->post('id'));

				if($this->db->update('visit_report', $visit_report_insert)){
					
					$this->session->set_flashdata('msg', 'Visit report Successfully Updated');
		        	redirect(base_url().'setting/visit_report');

		        }
		        else
		        {
		        	$this->session->set_flashdata('error', 'Problem In Edit Plan Try Again');
				    redirect(base_url().'setting/visit_report_edit');
		        }
		    }
    }
	
	public function attendence_edit($id = false)
	{	
		if($id)
		{
			$data['page_title']	= 'Edit Attendence';
			$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
			$data['edit_attend'] = $this->setting_model->edit_attendence($id);
			//echo"<pre>"; print_r($data['edit_attend']); die;
			$this->load->template('setting/edit_attendence',$data);

			
		}
		else
		{
			$this->session->set_flashdata('error', 'Plan Not Found Try Again');
	        redirect(base_url().'setting/edit_attendence');
		}
	    
	}
	
	public function attendence_update(){
		
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('emp_type', 'Name', 'trim|required');
		$this->form_validation->set_rules('att_type', 'Attendence type', 'trim|required');
		$this->form_validation->set_rules('visit_date', 'visit_date', 'trim|required');
		$this->form_validation->set_rules('remarks', 'Remarks', 'trim|required|max_length[240]');
		
			
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit Attendence ';
				$data['employees'] 		= $this->setting_model->get_employees(array('user_type'=>'employee','delete_flag'=>'0'));
			    $data['edit_attend'] = $this->setting_model->edit_attendence($this->input->post('id'));
				$this->load->template('setting/edit_attendence',$data);
			}
			else
			{
				
				
				$attendence_insert = array(
		        'Emp_id'          		 => 	$this->input->post('emp_type'),
				'attendence_type'        => 	$this->input->post('att_type'),
				'visit_date'             => 	date("Y-m-d", strtotime($this->input->post('visit_date'))),
				'remarks'                => 	$this->input->post('remarks'),
				'intime'                 => 	$this->input->post('intime'),
				'outtime'                => 	$this->input->post('outtime'),
				'created_by'		     => 	$this->session->userdata('id'),
		        'updated_by'		     => 	$this->session->userdata('id'),
		        'updated_at' 		     => 	date('Y-m-d H:i:s')
		   );
			//echo"<pre>"; print_r($attendence_insert); die;
			
			$this->db->where('id', $this->input->post('id'));

				if($this->db->update('attendance', $attendence_insert)){
					
					$this->session->set_flashdata('msg', 'Attendance report Successfully Updated');
		        	redirect(base_url().'setting/attendance');

		        }
		        else
		        {
		        	$this->session->set_flashdata('error', 'Problem In Edit Attendance Try Again');
				    redirect(base_url().'setting/attendence_edit');
		        }
		    }
    }


    /*/////////////////////////////////////////////////////////////////////////////////////////////////////
		  								DELETE Plan Number
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/

	public function visit_report_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('visit_report',array('updated_by'  => $this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
			{
				$this->session->set_flashdata('msg', 'Visit report Successfully Deleted');
        		redirect(base_url().'setting/visit_report');
			}
			else{
				$this->session->set_flashdata('error', 'Visit report Not Deleted Try Again');
        		redirect(base_url().'setting/visit_report');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Plan Not Found');
	        redirect(base_url().'setting/plan_codes');
		}
	}
	
	public function attendence_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('attendance',array('updated_by'  => $this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
			{
				$this->session->set_flashdata('msg', 'Attendence Successfully Deleted');
        		redirect(base_url().'setting/attendance');
			}
			else{
				$this->session->set_flashdata('error', 'Attendence Not Deleted Try Again');
        		redirect(base_url().'setting/attendance');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Attendence Not Found');
	        redirect(base_url().'setting/attendance');
		}
	}
	
	public function sallary_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);
			if($this->db->update('sallary',array('updated_by'  => $this->session->userdata('id'),'delete_flag' => '1','deleted_at' => date('Y-m-d H:i:s'))))
			{
				$this->session->set_flashdata('msg', 'Sallary Successfully Deleted');
        		redirect(base_url().'setting/sallary');
			}
			else{
				$this->session->set_flashdata('error', 'Sallary Not Deleted Try Again');
        		redirect(base_url().'setting/sallary');
			}

		}
		else{
			$this->session->set_flashdata('error', 'Sallary Not Found');
	        redirect(base_url().'setting/sallary');
		}
	}
	
	
	
	
	
	public function installment_delete($id = false)
	{	
		if($id)
		{
			$this->db->where('id',$id);

			if($this -> db -> delete('late_charges'))
			{
				$this->session->set_flashdata('msg', 'Late charges Successfully Deleted');
        		redirect(base_url().'setting/lateinstalment_charge');
			}
			else{
				$this->session->set_flashdata('error', 'Charges Not Deleted Try Again');
        		redirect(base_url().'setting/lateinstalment_charge');
			}

		}
		else{
			$this->session->set_flashdata('error', 'transaction Not Found');
	        redirect(base_url().'setting/lateinstalment_charge');
		}
	}


    public function instllment_charge_edit($id = false)
	{	
		if($id)
		{
			$data['page_title']	= 'Edit Installment Charges';
			$data['late_charges'] = $this->setting_model->edit_installment_charge($id);
			$this->load->template('setting/edit_installment_charges',$data);

			
		}
		else
		{
			$this->session->set_flashdata('error', 'Installment Not Found Try Again');
	        redirect(base_url().'setting/instllment_charge_edit');
		}
	    
	}


   public function installment_update(){
	   
	       
		    $this->form_validation->set_rules('title', 'Title', 'required|min_length[3]|max_length[70]');
			$this->form_validation->set_rules('charge', 'charge', 'trim|required|numeric|less_than[100]');
			
			
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Edit late charges';
				$data['late_charges'] = $this->setting_model->edit_installment_charge($this->input->post('id'));
				$this->load->template('setting/edit_installment_charges',$data);
			}
			else
			{
				$plan_code_update = array(
					'title'  		     =>    $this->input->post('title'),
					'charge'   		     =>    $this->input->post('charge'),
					'updated_by'   		 =>    $this->session->userdata('id'),
					'updated_at'   	     =>    date('Y-m-d H:i:s')
				);

				$this->db->where('id', $this->input->post('id'));

				if($this->db->update('late_charges', $plan_code_update)){
					
					$this->session->set_flashdata('msg', 'Late charges Successfully Updated');
		        	redirect(base_url().'setting/lateinstalment_charge');

		        }
		        else
		        {
		        	$this->session->set_flashdata('error', 'Problem In late Charges Try Again');
				    redirect(base_url().'setting/instllment_charge_edit');
		        }
		    }
    }
	



	/*/////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Insert Bank
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/




	public function bank(){
		$data['page_title']	= 'Company Details';
		$data['bank'] = $this->setting_model->get_bank();
		$this->load->template('setting/bank',$data);
	}

	public function save_bank()
	{
				$bank = array(
					'name'  		 =>    $this->input->post('com_name'),
					'mobile'  		 =>    $this->input->post('mobile'),
					'terms'  		 =>    $this->input->post('terms'),
					'email'  		 =>    $this->input->post('email'),
					'website'  		 =>    $this->input->post('website'),
					'cin'  		 	 =>    $this->input->post('cin'),
					'bank'  		 =>    $this->input->post('bank'),
					'ac_name'   	 =>    $this->input->post('ac_name'),
					'ac_no'          =>    $this->input->post('ac_no'),
					'ifsc'   		 =>    strtoupper($this->input->post('ifsc'))
				);

				$this->db->where('id', '1');

				if($this->db->update('bank', $bank)){
					$this->session->set_flashdata('msg', 'Company Detail Successfully Save');
        			redirect(base_url().'setting/bank');
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Save Company Detail');
	        		redirect(base_url().'setting/bank');
				}

	} // End Insert Bank


	/*/////////////////////////////////////////////////////////////////////////////////////////////////////
		  								Insert Agent Deactivation
	/////////////////////////////////////////////////////////////////////////////////////////////////////*/

	public function agent_deactivation()
	{
		$data['page_title']	= 'Agent Deactivation';
		$data['deactivation'] = $this->setting_model->get_agent_deactivation();
		$this->load->template('setting/agent_deactivation',$data);
	}



	public function save_agent_deactivation()
	{
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		
		$this->form_validation->set_rules('agent', 'Number Of Agents', 'trim|required|is_natural|min_length[1]|max_length[240]');
		$this->form_validation->set_rules('saller', 'Number Of Sale', 'trim|required|is_natural|min_length[1]|max_length[240]');		

		if($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Agent Deactivation';
			$data['deactivation'] = $this->setting_model->get_agent_deactivation();
			$this->load->template('setting/agent_deactivation',$data);
		}
		else
		{

			$agent = array(
				'agent'  		 =>    $this->input->post('agent'),
				'saller'   	 	 =>    $this->input->post('saller'),
			);

			$this->db->where('id', '1');

			if($this->db->update('agent_deactivation', $agent)){
				$this->session->set_flashdata('msg', 'Agent Deactivation Successfully Save');
    			redirect(base_url().'setting/agent_deactivation');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Save Agent Deactivation');
        		redirect(base_url().'setting/agent_deactivation');
			}
		}

	} // End Agent Deactivation






	public function promotion(){
		$data['page_title']	= 'Agent Promotion';
		$data['percent'] = $this->setting_model->get_promotion();
		$this->load->template('setting/promotion',$data);
	}


	public function save_promotion()
	{
			$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
			
			$this->form_validation->set_rules('silver', 'Silver Personality', 'trim|required|numeric');
			$this->form_validation->set_rules('gold', 'Gold Personality', 'trim|required|numeric');
			$this->form_validation->set_rules('diamond', 'Diamond Personality', 'trim|required|numeric');
			$this->form_validation->set_rules('super', 'Superb Personality', 'trim|required|numeric');
			$this->form_validation->set_rules('silver_commission', 'Silver Commission', 'trim|required|numeric');
			$this->form_validation->set_rules('gold_commission', 'Gold Commission', 'trim|required|numeric');
			$this->form_validation->set_rules('diamond_commission', 'Diamond Commission', 'trim|required|numeric');
			$this->form_validation->set_rules('super_commission', 'Superb Commission', 'trim|required|numeric');
				
			if ($this->form_validation->run() == FALSE)
			{
				$data['page_title']	= 'Agent Promotion';
				$data['percent'] = $this->setting_model->get_promotion();
				$this->load->template('setting/promotion',$data);
			}
			else
			{
				$promotion = array(
					'silver'   	 		 =>    $this->input->post('silver') * 100,
					'gold'         		 =>    $this->input->post('gold') * 100,
					'diamond'         	 =>    $this->input->post('diamond') * 100,
					'super'         	 =>    $this->input->post('super') * 100,
					'silver_commission'  =>    $this->input->post('silver_commission'),
					'gold_commission'    =>    $this->input->post('gold_commission'),
					'diamond_commission' =>    $this->input->post('diamond_commission'),
					'super_commission' =>    $this->input->post('super_commission')
				);

				$this->db->where('id', '1');

				if($this->db->update('agent_promotion', $promotion)){
					$this->session->set_flashdata('msg', 'Partner Promotion Successfully Save');
        			redirect(base_url().'setting/promotion');
				}
				else
				{
					$this->session->set_flashdata('error', 'Problem In Save Partner Promotion');
	        		redirect(base_url().'setting/promotion');
				}
			}
	}




	public function location()
	{
		$data['page_title']	= 'Plot Locations';
		$data['location'] = $this->setting_model->get_locations();
		$this->load->template('setting/locations',$data);
	}

	public function add_location()
	{
		$data['page_title']	= 'Add Plot Locations';
		$this->load->template('setting/add_location',$data);
	}

	public function save_location()
	{
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
			
		$this->form_validation->set_rules('location', 'Location Name', 'trim|required|max_length[240]|is_unique[locations.name]');

		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Add Plot Locations';
			$this->load->template('setting/add_location',$data);
		}
		else
		{
			$this->db->insert('locations',['name' => $this->input->post('location')]);
			$this->session->set_flashdata('msg', 'Location Successfully Saved');
        	redirect(base_url().'setting/location');
		}
	} 


	public function auth_code()
	{
		$data['page_title']	= 'Authentication Code';
		$data['code'] = $this->setting_model->get_authcode();
		
		$this->load->template('setting/authcode',$data);
	}

	public function save_code()
	{
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('admin', 'Admin Code', 'trim|required|numeric|min_length[4]|max_length[4]');
		$this->form_validation->set_rules('investor', 'Investor Code', 'trim|required|numeric|min_length[4]|max_length[4]');
		$this->form_validation->set_rules('agent', 'Agent Code', 'trim|required|numeric|min_length[4]|max_length[4]');
		$this->form_validation->set_rules('customer', 'Customer Code', 'trim|required|numeric|min_length[4]|max_length[4]');
		
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title']	= 'Authentication Code';
			$data['code'] = $this->setting_model->get_authcode();
			
			$this->load->template('setting/authcode',$data);
		}
		else
		{
			$this->db->where('for','subadmin');
			$this->db->update('auth_key',['code' => $this->input->post('admin')]);

			$this->db->where('for','business');
			$this->db->update('auth_key',['code' => $this->input->post('investor')]);

			$this->db->where('for','agent');
			$this->db->update('auth_key',['code' => $this->input->post('agent')]);

			$this->db->where('for','customer');
			$this->db->update('auth_key',['code' => $this->input->post('customer')]);

			$this->session->set_flashdata('msg', 'Authentication Code Saved');
	       	redirect(base_url().'setting/auth_code');
	    }
	}

}	

?>