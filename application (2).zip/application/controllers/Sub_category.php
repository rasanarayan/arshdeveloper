<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Sub_category extends CI_Controller 
{

	function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
		$this->load->model(array('sub_category_model','category_model'));
    }


	public function index()
	{
		$data['page_title']		=   'Sub Category';
		$data['category']       =   $this->sub_category_model->get_sub_category();
		$this->load->template('sub_category/index',$data);
	}

    public function add()
    {
        $data['page_title'] =   'Add Sub Category';
	    $data['category']       = $this->category_model->get_category_active(array('status' => '1'));
        $this->load->template('sub_category/add',$data);
    }

    public function save()
    {
		$this->form_validation->set_error_delimiters('<div class="my_text_error">','</div>');
		$this->form_validation->set_rules('category_id','Category Name','trim|required|max_length[30]');
		$this->form_validation->set_rules('sub_category_name','Category Name', 'trim|required|min_length[3]|max_length[30]');
		if ($this->form_validation->run() == FALSE)
		{
			$data['page_title'] =   'Add Sub Category';
			$data['category']   = $this->category_model->get_category();
			$this->load->template('sub_category/add',$data);
		}
		else
		{ 
			$data = array(
						'category_id'     		=>$this->input->post('category_id'),
						'sub_category_name'     =>$this->input->post('sub_category_name'),
						'created_by' 			=>$this->session->userdata('id'),
						'created_at' 			=>date('Y-m-d H:i:s'),
						);
			if($this->db->insert('document_sub_category',$data))
			{
				$this->session->set_flashdata('msg','Sub Category Successfully Uploaded');
				redirect(base_url().'sub_category');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Insert Data ');
				redirect(base_url().'sub_category');
			}
		}	
    }
	
	public function edit($id = false)
	{	
		if($id)
		{
			if($this->sub_category_model->get_sub_category_by_id($id))
			{
				$data['page_title']		= 'Edit Sub Category';
				$data['sub_category'] 	= $this->sub_category_model->get_sub_category_by_id($id)[0];
				$data['category']       = $this->category_model->get_category_active(array('status' => '1'));
				$this->load->template('sub_category/edit',$data);
			}	
			else
			{
				$this->session->set_flashdata('error', 'Sub Category Not Found');
	        	redirect(base_url().'sub_category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sub Category Not Found');
	        redirect(base_url().'sub_category');
		}
	}	
	
	public function update()
	{	
		$id = $this->input->get_post('sub_category_id');
		if($this->sub_category_model->get_sub_category_by_id($id))
		{
			$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
			$this->form_validation->set_rules('category_id','Category Name', 'trim|required|max_length[30]');
			$this->form_validation->set_rules('sub_category_name','Sub Category Name', 'trim|required|min_length[3]|max_length[30]');
			if ($this->form_validation->run() == FALSE)
			{	
				$data['page_title']		= 'Edit Sub Category';
				$data['sub_category'] 	= $this->sub_category_model->get_sub_category_by_id($id)[0];
				$data['category']       = $this->category_model->get_category();
				$this->load->template('sub_category/edit',$data);
			}
			else
			{	
				
				$category_update = array(
									'category_id'       =>$this->input->post('category_id'),
									'sub_category_name' =>$this->input->post('sub_category_name'),
									'updated_by'		=>$this->session->userdata('id'),
									'updated_at' 		=>date('Y-m-d H:i:s')
									);
				$this->db->where('sub_category_id',$this->input->post('sub_category_id'));
				if($this->db->update('document_sub_category', $category_update))
				{
					$this->session->set_flashdata('msg','Sub Category Successfully Saved');
					redirect(base_url().'sub_category');
				}
				else
				{
					$this->session->set_flashdata('error','Sub Category Is Not Save Please Try Again');
					redirect(base_url().'sub_category');
				}
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sub Category Not Found');
	        redirect(base_url().'sub_category');
		}
	}
	
    public function delete($id)
	{
		if($id)
		{
			$data = $this->db->get_where('document_sub_category',['sub_category_id'=>$id])->result_array()[0];
			$this->db->where('sub_category_id',$id);
			$this->db->delete('document_sub_category');
			$this->session->set_flashdata('msg', 'Sub Category Successfully Deleted');
			redirect(base_url().'sub_category');
		}
		else
		{
			$this->session->set_flashdata('error', 'Sub Category is Not Found');
	        redirect(base_url().'sub_category');
		}
    }
	
	public function active($id = false)
	{	
		if($id)
		{
			$this->db->where('sub_category_id',$id);
			if($this->db->update('document_sub_category',array('updated_by'=>$this->session->userdata('id'),'status'=>'1')))
			{
				$this->session->set_flashdata('msg', 'Sub Category Successfully Activeted');
				redirect(base_url().'sub_category');
			}
			else{
				$this->session->set_flashdata('error', 'Sub Category is Not Activeted Try Again');
				redirect(base_url().'sub_category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sub Category is Not Found');
	        redirect(base_url().'sub_category');
		}
	}

	public function deactive($id = false)
	{	
		if($id)
		{
			$this->db->where('sub_category_id',$id);
			if($this->db->update('document_sub_category',array('updated_by'=>$this->session->userdata('id'),'status'=>'2')))
			{	
				$this->session->set_flashdata('msg', 'Sub Category Successfully Deactiveted');
				redirect(base_url().'sub_category');
			}
			else{
				$this->session->set_flashdata('error', 'Sub Category Not Deactiveted Try Again');
				redirect(base_url().'sub_category');
			}
		}
		else
		{
			$this->session->set_flashdata('error', 'Sub Category Not Found');
	        redirect(base_url().'sub_category');
		}
	}	
}