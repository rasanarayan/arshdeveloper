<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH."/third_party/vendor/autoload.php";
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Transaction extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->model(array('transaction_model','dash_model'));
    }

    public function credit_id(){
    	pre_print($this->transaction_model->balance());
    } 


    public function get_balance()
    {
    	echo json_encode($this->transaction_model->get_parterner_balance($_POST['id']));
    }
	
	
public function filter_transaction_data()
	{
	 $pagesize               =  (int) $this->input->get_post('pagesize');	
		$config['limit']	    =  ( $pagesize > 0 ) ? $pagesize : 10;	 
		//$config['limit']		=  ( $pagesize > 0 ) ? $pagesize : $this->config->item('pagesize');		
		$offset                 =  ( $this->input->get_post('per_page') > 0 ) ? $this->input->get_post('per_page') : 0;		
		$base_url               =  current_url_query_string(array('filter'=>'result'),array('per_page'));
		$res_array              =  $this->transaction_model->get_transaction_recent_limit($config['limit'],$offset);
		$config['total_record']   =  get_found_rows();
		//echo "<pre>"; print_r($config['base_url']); die;
		$data['page_links']     =  admin_pagination("$base_url",$config['total_record'],$config['limit'],$offset);			
		
		$data['recent_transcation'] 	= $res_array;
        $data['page_title'] =  'Recent Transaction';	  		
		//echo"<pre>"; print_r($data['recent_transcation']); die;	
		
		$this->load->template('report/transaction/show_report_one',$data);
	}
	
	public function filter_ca_data()
	{
	 $pagesize               =  (int) $this->input->get_post('pagesize');	
		$config['limit']	    =  ( $pagesize > 0 ) ? $pagesize : 10;	 
		//$config['limit']		=  ( $pagesize > 0 ) ? $pagesize : $this->config->item('pagesize');		
		$offset                 =  ( $this->input->get_post('per_page') > 0 ) ? $this->input->get_post('per_page') : 0;		
		$base_url               =  current_url_query_string(array('filter'=>'result'),array('per_page'));
		$res_array              =  $this->transaction_model->get_transaction_ca_recent_limit($config['limit'],$offset);
		$config['total_record']   =  get_found_rows();
		//echo "<pre>"; print_r($config['base_url']); die;
		$data['page_links']     =  admin_pagination("$base_url",$config['total_record'],$config['limit'],$offset);			
		
		$data['recent_transcation'] 	= $res_array;
        $data['page_title'] =  'Transactions for CA Records';	  		
		//echo"<pre>"; print_r($data['recent_transcation']); die;	
		
		$this->load->template('report/transaction/show_report_ca',$data);
	}
	
	public function createProductsReportsExcel()
	{
		$productsData 		= $this->transaction_model->get_products(10,0,array(),$excel="1");
		//echo"<pre>"; print_r($productsData); die;
		$headers 			= array("Sr. No","Date","Details","Mode","Detail payment","Credit","Debit");
		$title 				= "";
		$data 				= "";
		$filename 			= 'CA_reports';
		foreach($headers as $value) 
		{
			$title .= $value . "\t";
		}
		$headers = trim($title). "\n";

		if (!empty($productsData))
		{	
			$i=1;
			foreach ($productsData as $pageVal)
			{
				
				//if($pageVal['createdby']=='')
				//{ 
				//	$createdby = "Admin"; 
				//}
				//else
				//{  
				//	$createdby = vendors_name($pageVal['createdby']); 
				//}
				$line = '';
				$line 			.= $i."\t";
				$line 			.= _vdate($pageVal['date']) . "\t";
				
				$line 			.= $this->dash_model->get_user_id_trans_ca($pageVal['credit_by'],$pageVal['debit_by'])."\t";
				//$line 		.= $pageVal['credit_by']."\t";
				$line 			.= $pageVal['mode']."\t";
				$line 			.= $pageVal['type']."\t";
				$line 			.= $pageVal['credit']."\t";
				$line 			.= $pageVal['debit']."\t";
				$data           .= trim($line). "\n";
			$i++;
			}
		}

		$export = array(
						'filename' => $filename,
						'headers' => $headers,
						'data' => $data
						);
		$filename 	= $export['filename'];
		$headers 	= $export['headers'];
		$data 		= $export['data'];
		header("Content-disposition: attachment; filename=".$filename.".xls");
		header("Content-Type: application/vnd.ms-excel");

		print "$headers\n$data";
	} 


}
?>