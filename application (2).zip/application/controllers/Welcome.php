<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function index()
	{
		if($this->session->userdata('id')){
			redirect(base_url('dashboard'));
		}
		else
		{
			$this->load->helper('cookie');
			$this->load->view('login');
		}
	}

	public function sms()
	{
		//cancle_plan(9099998171,"Kava",12);
		//installment_payment(9099998171,"Kava",1000,"23-01-20","30:00","01",10000);
		//agent_indirect_installment(9099998171,"Kava","AG1",10000,"23-01-20","10:00","12","5000");
		//agent_right_leg(9099998171,"ABC","03",100);
		//agent_withdraw_reject(9099998171,"ABC");
		//seller_sell_detail(9099998171,"abxc",10000,"P01",5000,5000);substr($big, 0, 100);
		//seller_sell_installment(9099998171,"ABC",1000,"P01","10-02-20","00:00","10000");
		//investor_installment_credit(9099998171,"ABC","ABC",10000,"10-02-03","00:00","sale",12000);
	}
}
