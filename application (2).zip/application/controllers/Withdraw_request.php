<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Withdraw_request extends CI_Controller
{
	function __construct()
	{
        parent::__construct();
        $this->auth->check_session();
        $this->load->model('validate');
        $this->load->model('users');
        $this->load->model('withdraw_req');
        $this->load->model('all_model');
    }


	public function index()
	{
		$data['page_title']	= 'Withdraw Request';
		$data['request'] = $this->withdraw_req->all_request();
		$this->load->template('withdraw_request/index',$data);
	}
	
	public function history()
	{
		$data['page_title']	= 'Withdraw History';
		$request_id 		=  $this->uri->segment(3);
		$data['request']	=  $this->withdraw_req->get_amount($request_id);
		if(is_array($data['request']) && !empty($data['request']))
		{
			$data['request_history'] 	= $this->withdraw_req->get_withdraw_history(array('withdraw_id'=>$request_id));
		}
		else
		{
			redirect('withdraw_request','');
		}
		$this->load->template('withdraw_request/history_index',$data);
	}
	
	public function get_user()
	{
		$user_type 			= $this->input->get_post('user_type');
		$agents	= $this->withdraw_req->get_usr_agent(array('user_type'=>$user_type));?>
		<option value="">Select User</option>
		<?php
		if(is_array($agents) && !empty($agents))
		{
			foreach ($agents as $value) {
		?>
		<option value="<?php echo $value["id"]; ?>"><?php echo $value["user_name"]; ?></option>
		<?php
		}
		}
	}
	
	public function get_tds()
	{
		$withdraw_amount 	= $this->input->get_post('withdraw_amount');
		$total_amount 		= $this->input->get_post('total_amount');
		$master				= $this->withdraw_req->get_masterpass(array('id'=>'1'));
		$tds				= $master['tds']*$withdraw_amount/100;
		echo $tds;
	}
	
	public function request()
	{
		$id 			= $this->input->get_post('agent_id');
		$total_amount 	= $this->withdraw_req->get_balance($id);
		$balance 		= $total_amount['balance'];
		echo $balance;
	}

	public function add()
	{	
	    $data['page_title']		= 'Withdraw Request';
		$data['total_amount'] 	= $this->withdraw_req->get_balance($this->session->userdata('id'));
		$data['agents'] 		= $this->withdraw_req->get_usr_agent(array('user_type'=>'agent'));
		$this->load->template('withdraw_request/add',$data);
	}
	
	public function check_available_withdraw($user_id,$withdraw_amount)
	{	
		$master				= $this->withdraw_req->get_masterpass(array('id'=>'1'));
		$tds				= $master['tds']*$withdraw_amount/100;
		$total_request		= $withdraw_amount+$tds;
		$total_amount 		= $this->withdraw_req->get_balance($user_id);
		if($total_request>$total_amount['balance'])
		{
			echo "1";
		}
		
	}
	public function save()
	{
		
		if($this->withdraw_req->check_pending_rquist($this->input->get_post('user_id')))
		{
			$this->session->set_flashdata('error', 'You cannot Add Withdraw Request Because Your Past Request Is In Process');
	        redirect(base_url().'withdraw_request');
		}
		if($this->check_available_withdraw($this->input->get_post('user_id'),$this->input->get_post('withdraw_amount')))
		{
			$this->session->set_flashdata('error', 'You cannot Add Withdraw Request Because Your Past Request Is In Process');
	        redirect(base_url().'withdraw_request');
		}
		$this->form_validation->set_error_delimiters('<div class="my_text_error">', '</div>');
		$this->form_validation->set_rules('withdraw_amount', 'Withdraw Amount', 'trim|integer|required|max_length[30]');

		if ($this->form_validation->run() == FALSE)
		{	
	    	$data['page_title']		= 'Withdraw Request';
			if($this->session->userdata('id')!='1')
			{
				$data['total_amount'] 	= $this->withdraw_req->get_balance($this->session->userdata('id'));
			}
			else
			{
				$data['total_amount'] 	= $this->withdraw_req->get_balance($this->input->get_post('user_id'));
			}
			$this->load->template('withdraw_request/add',$data);
		}
		else
		{ 
			if($this->session->userdata('id')=='1')
			{
				$withdraw_insert = array(
										'user_type'           		=> 	$this->input->post('user_type'),
										'date'  			        => 	date('Y-m-d'),
										'withdraw_amount'           => 	$this->input->post('withdraw_amount'),
										'tds_amount'           		=> 	$this->input->post('tds_amount'),
										'created_by'		  		=> 	$this->input->get_post('user_id'),
										'request_type'		  		=> 	'1',
										'created_at' 		  		=> 	date('Y-m-d H:i:s'),
										'req_remarks' 		  		=> 	$this->input->get_post('req_remarks'),
										);
			}
			else
			{
				$withdraw_insert = array(
										'user_type'           		=> 	$this->session->userdata('user_type'),
										'date'  			        => 	date('Y-m-d'),
										'withdraw_amount'           => 	$this->input->post('withdraw_amount'),
										'tds_amount'           		=> 	$this->input->post('tds_amount'),
										'created_by'		  		=> 	$this->input->get_post('user_id'),
										'created_at' 		  		=> 	date('Y-m-d H:i:s'),
										'req_remarks' 		  		=> 	$this->input->get_post('req_remarks'),
										);
			}
			if($this->db->insert('withdraw_request', $withdraw_insert))
			{
					$insert_id = $this->db->insert_id();
					if($this->session->userdata('id')=='1')
					{
						$user_type = $this->input->post('user_type');
					}
					else
					{
						if($this->session->userdata('user_type')=='agent')
						{
							$user_type = 'Agent';
						}
						else
						{
							$user_type = 'Business Partner';	
						}
					}

					$notification = [
									'user_id'        			=>    $this->session->userdata('id'),
									'message'          			=>    $this->session->userdata('user_type_id').' Withdraw Request',
									'notification_type'		  	=> 	  'withdraw',
									'main_id'          			=>    $insert_id,
									'for'          				=>    '1',
									'created_at' 		  		=> 	  date('Y-m-d H:i:s')
									];	
					
					$this->db->insert('notification', $notification);
					$this->session->set_flashdata('msg', 'Withdraw Request Successfully Sent');
	        		redirect(base_url().'withdraw_request');
			}
			else
			{
				$this->session->set_flashdata('error', 'Problem In Withdraw Request Try Again');
	        	$this->db->delete('user', array('id' => $insert_id));
	        	redirect(base_url().'withdraw_request/add');
			}
		}

	}	// Save Function



	/************************************************************************************************************************
												Confirm Request
	************************************************************************************************************************/
	
	public function confirm()
	{	
		$id = $this->input->post('withdraw_id');
		$withdraw_confirm = [ 
							'confirm'   => '1',
							'remark' 	=> $this->input->post('remark') 
							];
		
		$this->db->where('id',$id);
		if($this->db->update('withdraw_request', $withdraw_confirm))
		{
			$withdraw_history = [
								'withdraw_id'        		=>    $id,
								'remark'          			=>    $this->input->post('remark'),
								'confirm'   				=> 	  '1',
								'request_type'				=>    '1',
								'created_at' 		  		=> 	  date('Y-m-d H:i:s'),
								];	
			$this->db->insert('withdraw_request_history',$withdraw_history);
			
			$notification = ['read' =>'1'];	
			$this->db->where('main_id',$id);
			$this->db->where('notification_type','withdraw');
			$this->db->update('notification', $notification);
			
			$transaction = [
							'type'        				=>    'withdraw',
							'debit'          			=>    $this->withdraw_req->get_request_amount($id)[0]['withdraw_amount']+$this->withdraw_req->get_request_amount($id)[0]['tds_amount'],
							'debit_by'		  			=> 	  $this->withdraw_req->get_request_amount($id)[0]['created_by'],
							'date'          			=>    date('Y-m-d'),
							'mode' 	                    =>    $this->input->post('payment_mode'), 
							'investment_id'          	=>    $id,
							'created_at' 		  		=> 	  date('Y-m-d H:i:s'),
							'created_by' 		  		=> 	  $this->session->userdata('id')
							];	
			
			$this->db->insert('transaction', $transaction);
			$notification = [
							'user_id'        			=>    $this->session->userdata('id'),
							'message'          			=>    'Approved Withdraw Request',
							'notification_type'		  	=> 	  'withdraw',
							'for'          				=>    $this->withdraw_req->get_request_amount($id)[0]['created_by'],
							'created_at' 		  		=> 	  date('Y-m-d H:i:s')
							];	
			$this->db->insert('notification', $notification);
			$user = $this->users->get_user($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
			if($user['user_type'] == "agent")
			{
				$agent 		= $this->users->agent_detail($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
				$agent_id 	= $this->users->get_user($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0]['user_type_id'];
				$balance 	= $this->all_model->agent_balance($this->withdraw_req->get_request_amount($id)[0]['created_by']);
			}
			else
			{
				$agent 		= $this->users->business_detail($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
				$agent_id 	= $this->users->get_user($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0]['user_type_id'];
				$balance 	= $this->all_model->business_balance($this->withdraw_req->get_request_amount($id)[0]['created_by']);
			}
			agent_withdraw_accept($agent['mobile'],$agent_id,$this->withdraw_req->get_request_amount($id)[0]['withdraw_amount'],date('d-m-y'),date('H:i'),$balance);
			$this->session->set_flashdata('msg', 'Withdraw Request Successfully Approved');
			redirect(base_url().'withdraw_request');
		}
		else
		{
			$this->session->set_flashdata('error', 'Problem In Approve Request Try Again');
			redirect(base_url().'withdraw_request');
		}
	}


	/************************************************************************************************************************
												Reject Request
	************************************************************************************************************************/
	public function reject()
	{
		$id 				= $this->input->post('withdraw_id');
		
		$withdraw = $this->withdraw_req->get_amount($id);
		if($withdraw[0]['confirm']=='1')
		{
			$this->db->where('investment_id',$id);
			$this->db->delete('transaction');
			
		}
		$withdraw_confirm 	= [ 
								'confirm'   => 	'2',
								'remark' 	=> $this->input->post('remark') 
							   ];
		$this->db->where('id',$id);
		$this->db->update('withdraw_request', $withdraw_confirm);
		
		$withdraw_history = [
							'withdraw_id'        		=>    $id,
							'remark'          			=>    $this->input->post('remark'),
							'confirm'   				=> 	  '2',
							'request_type'				=>    '1',
							'created_at' 		  		=> 	  date('Y-m-d H:i:s'),
							];	
		$this->db->insert('withdraw_request_history',$withdraw_history);
		
		$notification = [ 'read' => '1' ];			
		$this->db->where('main_id',$id);
		$this->db->where('notification_type','withdraw');
		$this->db->update('notification', $notification);

		$notification = [
			'user_id'        			=>    $this->session->userdata('id'),
			'message'          			=>    'Rejected Withdraw Request',
	        'notification_type'		  	=> 	  'withdraw',
			'for'          				=>    $this->withdraw_req->get_request_amount($id)[0]['created_by'],
			'created_at' 		  		=> 	  date('Y-m-d H:i:s')
		];	
		
		$this->db->insert('notification', $notification);
		$user = $this->users->get_user($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
		if($user['user_type'] == "agent")
		{
			$agent = $this->users->agent_detail($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
	    }
		else
		{
	    	$agent = $this->users->business_detail($this->withdraw_req->get_request_amount($id)[0]['created_by'])[0];
	    }
        agent_withdraw_reject($agent['mobile'],$agent['fi_name']);
		$this->session->set_flashdata('msg', 'Withdraw Request Rejected.');
		redirect(base_url().'withdraw_request');	
	}
}
?>