<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function pre_print($array)
{   
    echo count($array);
    echo "<pre>";
    print_r($array);
}

function _name($id)
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get_where('user',['id' => $id]);
    return $query->result_array()[0]['user_name'];
}

function circlerate($id)
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get_where('locations_for_circlerate',['id' => $id]);
    return $query->result_array()[0]['title'];
}

function customer_name($id)
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get_where('customer_detail',['user_id' => $id])->result_array()[0];
    return $query['fi_name'].' '.$query['la_name'];
 }

function image_thumb($image_name, $width, $height)
{
	// Get the CodeIgniter super object
	$CI =& get_instance();
	// Path to image thumbnail
	$image_thumb = dirname('uploads/thumb/' . $image_name) . '/' .$image_name;
	//print_r($image_thumb); die;
	if( ! file_exists($image_thumb))
	{
		// LOAD LIBRARY
		$CI->load->library('image_lib');
		// CONFIGURE IMAGE LIBRARY
		$config['image_library'] = 'gd2';
		$config['source_image'] = 'uploads/'.$image_name;
		$config['new_image'] = $image_thumb;
		$config['maintain_ratio'] = TRUE;
		$config['height'] = $height;
		$config['width'] = $width;
		$CI->image_lib->initialize($config);
		$CI->image_lib->resize();
		$CI->image_lib->clear();
	}
	//returning new image path name
	return 'uploads/thumb/' .$image_name;
}

function get_employee_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 

                 
        
                 $ci->db->where('user_id',$user_id);
        $query = $ci->db->get('employee_details');
        return $query->result_array()[0];
}


function dy_sms($mobile,$message)
{
    $url = "http://198.24.149.4/API/pushsms.aspx?loginID=champs786&password=CHAMPS786&mobile=$mobile&text=$message&senderid=CHPSMS&route_id=2&Unicode=0";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
    //curl_setopt($ch, CURLOPT_RETURNTRANSFER,false);
    curl_exec($ch);
}

function master_pass()
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get_where('masterpass',['id' => '1']);
    return $query->result_array()[0]['pass'];
}

function user_profile_image($name)
{
    if(file_exists(FCPATH.'uploads/thumb/'.$name)){
        return base_url().'uploads/thumb/'.$name;
    }
    else{
        return base_url().'uploads/thumb/user.png';   
    }
}
// Get Proof Data For All Module
    
function proof_type()
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get('proof');
    return $query->result_array();
}


	function get_found_rows()
	{	
		$ci = get_instance();
		//$ci = CI();
		$query=$ci->db->query('SELECT FOUND_ROWS() AS total');
		$row=$query->row();
		return $row->total;
	}


function get_agent_details($user_id)
{ 
    $ci=& get_instance();
    $ci->load->database(); 
	$ci->db->where('user_id',$user_id);
    $query = $ci->db->get('agent_details');
    return $query->row_array();
}

function land_det($id)
{
    $ci=& get_instance();
    $ci->load->database();
    $query = $ci->db->get_where('create_product',['id' => $id]);
    return $query->result_array()[0]['product_id'];
}



function get_subadmin_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 

   				 
		
				 $ci->db->where('user_id',$user_id);
    	$query = $ci->db->get('subadmin_details');
    	return $query->result_array()[0];
}

function get_business_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 

                 
        
                 $ci->db->where('user_id',$user_id);
        $query = $ci->db->get('business_partners');
        return $query->result_array()[0];
}



function get_sallary_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 
    $ci->db->where('user_id',$user_id);
        $query = $ci->db->get('employee_details');
        return $query->result_array()[0];
}

function get_user_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 
    $ci->db->where('id',$user_id);
        $query = $ci->db->get('user');
        return $query->row_array();
}

function get_customer_details($user_id){
    $ci=& get_instance();
    $ci->load->database(); 

                 
        
                 $ci->db->where('user_id',$user_id);
        $query = $ci->db->get('customer_detail');
        return $query->result_array()[0];
}

function _vdate($date){
    return date('d-m-Y',strtotime($date));
}

function _ddate($date){
    return date('Y-m-d',strtotime($date));
}

function _suffix($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        echo $number. 'th';
    else
        echo $number. $ends[$number % 10];
}

function getIndianCurrency_inwords($number)
{
    $decimal = round($number - ($no = floor($number)), 2) * 100;
    $hundred = null;
    $digits_length = strlen($no);
    $i = 0;
    $str = array();
    $words = array(0 => '', 1 => 'One', 2 => 'Two',
        3 => 'Three', 4 => 'Four', 5 => 'Five', 6 => 'Six',
        7 => 'Seven', 8 => 'Eight', 9 => 'Nine',
        10 => 'Ten', 11 => 'Eleven', 12 => 'Twelve',
        13 => 'Thirteen', 14 => 'Fourteen', 15 => 'Fifteen',
        16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen',
        19 => 'Nineteen', 20 => 'Twenty', 30 => 'Thirty',
        40 => 'Forty', 50 => 'Fifty', 60 => 'Sixty',
        70 => 'Seventy', 80 => 'Eighty', 90 => 'Ninety');
    $digits = array('', 'Hundred','Thousand','Lakh', 'Crore');
    while( $i < $digits_length ) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += $divider == 10 ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
        } else $str[] = null;
    }
    $Rupees = implode('', array_reverse($str));
    $paise = ($decimal) ?  ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
    $_word = ($Rupees ? $Rupees . 'Rupees ' : '') ;
    if(!empty($paise))
    {
        return $_word. ' and '.$paise; 
    }
    else
    {
        return $_word;
    }
}


function moneyFormatIndia($num) {
    //$fmt = new NumberFormatter($locale = 'en_IN', NumberFormatter::CURRENCY);
    //return $fmt->format($num);
    return $num;
}



function binary_tree_row($id)
{
    $ci=& get_instance();
    $ci->load->database(); 

    $ci->db->where('agent_id',$id);
    return $ci->db->get('binary')->result_array()[0];
}

function _fuser($id)
{
    $ci=& get_instance();
    $ci->load->database();
            $ci->db->where('user_type_id',$id);
    return $ci->db->get('user')->result_array()[0];
    
}

function _fuserdt($id)
{
    $ci=& get_instance();
    $ci->load->database();
    $ci->db->where('user_type_id',$id['agent_id']);
    $user = $ci->db->get('user')->result_array()[0];

    $ci->db->where('user_id',$user['id']);
    if($user['id'] != 1){
        $detail = $ci->db->get('agent_details')->result_array()[0];
        return $detail['fi_name'].' '.$detail['la_name'];
    }
    else
    {
        $detail = $ci->db->get('subadmin_details')->result_array()[0];
        return $detail['first_name'].' '.$detail['last_name'];
    }
}

function _Bparent($main)
{
    if(!empty($main['parent']))
    {
        return "<br><small> Parent - ".$main['parent']."</small>";
    }
}

function _more_tree($main)
{
    return '<br><span><a href="'.base_url("tree/get/").$main["agent_id"].'"><i class="fa fa-plus"></i>More</a></span>';
}

function _whole_tree($main)
{
    return '<br><span><a href="'.base_url("tree/whole_tree/").$main["agent_id"].'"><i class="fa fa-plus"></i>More</a></span>';
}

function _Agstatus($status){
    if($status == '0')
    {
        return '</br><span class="badge badge-success">Active</span>';
    }
    else
    {
        return '</br><span class="badge badge-danger">In-Active</span>';
    }
} 

function _Deleted($status){
    if($status == '0')
    {
        return '';
    }
    else
    {
        return '</br><span class="badge badge-danger">Deleted</span>';
    }
} 



function read_more($string)
{
    if (strlen($string) > 15) {
        $trimstring = substr($string, 0, 15). '...';
    } else {
        $trimstring = $string;
    }
    return $trimstring;
}



function get_name_createdby($user_array){
    $ci=& get_instance();
    $ci->load->database();
    if($user_array['user_type'] == 'subadmin'){
        $admin = $ci->db->get_where('subadmin_details',['user_id' => $user_array['id']])->result_array()[0];
        return $admin['first_name'].' '.$admin['last_name']; 
    }
    else if($user_array['user_type'] == 'agent')
    {
        $admin = $ci->db->get_where('agent_details',['user_id' => $user_array['id']])->result_array()[0];
        return $admin['fi_name'].' '.$admin['la_name']; 
    }
}

function _my(){
    $ci=& get_instance();
    $ci->load->database();
    return $ci->db->get_where('bank',['id' => '1'])->result_array()[0];
}


function split_installments($installments){
    $ins = explode(', ', $installments);
    if(count($ins) > 1)
    {
        return $ins[0].' To '.array_values(array_slice($ins, -1))[0];
    }
    else{
        return $installments;
    }
}


// sms functions

function welcome($mobile,$username){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Welcome to Arsh Developers Pvt Ltd. Thank you for joining our growing family. You can log into your account using ".$username." as username and default password.");
}

function customer_sale($mobile,$customer,$sales,$total,$paid,$remaning){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.", %nHere are your plan details. %nSales ID: ".$sales."%nTotal Amount: Rs. ".$total."%nPaid Amount: Rs. ".$paid."%nRemaning Amount: Rs. ".$remaning);
}

function cancle_plan($mobile,$name,$sale_id){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$name.",%nAs per your request, we have cancelled purchase of your plan/plot with SalesID ".$sale_id.". You will get refund as per our agreement.%nThank you");
}

function plan_cancle_payment($mobile,$customer,$amount,$date,$time,$sale_id,$remaining){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nWe have paid Rs. ".$amount." on ".$date." at ".$time." for your cancelled purchase with sales ID ".$sale_id.". Remaining amount is Rs. ".$remaining);
}

function agent_direct_sale($mobile,$customer,$agent_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nYour account ".$agent_id." is credited for Rs. ".$amount." on ".$date." at ".$time." by direct sale ".$sale_id.". Available balance is Rs. ".$balance);
}

function agent_indirect_sale($mobile,$customer,$agent_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nYour account ".$agent_id." is credited for Rs. ".$amount." on ".$date." at ".$time." by indirect sale ".$sale_id.". Available balance is Rs. ".$balance);
}

function agent_direct_installment($mobile,$customer,$agent_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nYour account ".$agent_id." is credited for Rs. ".$amount." on ".$date." at ".$time." by direct installment ".$sale_id.". Available balance is Rs. ".$balance);
}

function agent_indirect_installment($mobile,$customer,$agent_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nYour account ".$agent_id." is credited for Rs. ".$amount." on ".$date." at ".$time." by indirect installment ".$sale_id.". Available balance is Rs. ".$balance);
}

function agent_left_leg($mobile,$customer,$left_agent,$count_group){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$mobile.",%nYou have successfully added ".$left_agent." on your left leg. Now you have ".$count_group." agents in you team. Keep growing high.%nThank you.");
}

function agent_right_leg($mobile,$customer,$right_agent,$count_group){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nYou have successfully added ".$right_agent." on your right leg. Now you have ".$count_group." agents in you team. Keep growing high.%nThank you");
}

function agent_withdraw_accept($mobile,$agent_id,$amount,$date,$time,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "We have accepted your withdraw request. Your account ".$agent_id." is debited for Rs. ".$amount." on ".$date." at ".$time.". Available balance is Rs. ".$balance."%nThank you");
}

function agent_withdraw_reject($mobile,$customer){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nWe have rejected your withdraw request for some reasons. For more information, kindly call us or visit your nearest branch. %nThank you");
}

function seller_sell_detail($mobile,$seller,$amount,$purchase_id,$paid,$remaining){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$seller.",%nWe are happy to inform you that we agreed on Rs. ".$amount." for ".$purchase_id.". We have paid Rs. ".$paid.". Remaining amount is Rs. ".$remaining);
}

function seller_sell_installment($mobile,$seller,$amount,$purchase_id,$date,$time,$remaining){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$seller.",%nWe have paid Rs. ".$amount." for ".$purchase_id." on ".$date." at ".$time.". Your remaining amount is Rs. ".$remaining.".%nThank you");
}

function investor_sell_credit($mobile,$seller,$investor_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$seller.",%nYour account ".$investor_id." is credited for Rs. ".$amount." on ".$date." at ".$time." by sale ".$sale_id.". Available balance is Rs. ".$balance."%nThank you");
}

function investor_installment_credit($mobile,$seller,$investor_id,$amount,$date,$time,$sale_id,$balance){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$seller.",%nYour account ".$investor_id." credited for Rs. ".$amount." on ".$date." at ".$time." by sale ".$sale_id.". Available balance is Rs. ".$balance."%nThank you");
}

function installment_payment($mobile,$customer,$amount,$date,$time,$sale_id,$remaining){
    $ci =& get_instance();
    $ci->load->library('setupfile'); 
    return $ci->setupfile->send($mobile, "Dear ".$customer.",%nWe have received Rs. ".$amount." on ".$date." at ".$time." for your purchase with sales ID ".$sale_id.", Your remaining amount is ".$remaining."%nThank you");
}
function device_info()
{
	$tablet_browser = 0;
	$mobile_browser = 0;
		 
	if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i', strtolower($_SERVER['HTTP_USER_AGENT']))) 
	{
		$tablet_browser++;
	}
		 
	if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) 
	{
		$mobile_browser++;
	}	 
	if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') > 0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) 
	{
		$mobile_browser++;
	}
		 
	$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
	$mobile_agents = array(
			'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
			'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
			'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
			'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
			'newt','noki','palm','pana','pant','phil','play','port','prox',
			'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
			'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
			'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
			'wapr','webc','winw','winw','xda ','xda-');
		 
	if (in_array($mobile_ua,$mobile_agents)) 
	{
			$mobile_browser++;
	}
		 
	if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'opera mini') > 0) 
	{
		$mobile_browser++;
		//Check for tablets on opera mini alternative headers
		$stock_ua = strtolower(isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])?$_SERVER['HTTP_X_OPERAMINI_PHONE_UA']:(isset($_SERVER['HTTP_DEVICE_STOCK_UA'])?$_SERVER['HTTP_DEVICE_STOCK_UA']:''));
		if (preg_match('/(tablet|ipad|playbook)|(android(?!.*mobile))/i', $stock_ua)) 
		{
		  $tablet_browser++;
		}
	}
		 
	if ($tablet_browser > 0) 
	{
	   // do something for tablet devices
	   return 'tablet';
	}
	else if ($mobile_browser > 0) 
	{
	   // do something for mobile devices
	   return 'mobile';
	}
	else 
	{
	   // do something for everything else
	  return 'desktop';
	}  
}

?>