<?php

class Add_product extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
        $this->load->model('users');
	}


	// product dashboard
	public function get_product_dash($location)
	{


        	//	$this->db->order_by('id','asc');
                if($this->users->get_user($this->session->userdata('id'))[0]['user_type'] == 'agent')
                {
                    $where = ['delete_flag' => '0','purchase_id' => $location,'status !=' => 1];
                }
                else
                {
                    $where = ['delete_flag' => '0','purchase_id' => $location];
                }
                	//$this->db->order_by('id','desc');
				 $this->db->order_by('status','asc');
		return $this->db->get_where('create_product',$where)->result_array();
	}
	// product dashboard

    public function get_created($idvalue)
	{
        $this->db->select('create_product.*,purchase.purchase_id as purid');
		$this->db->from('create_product');
		$this->db->join('purchase', 'create_product.purchase_id = purchase.purchase_id', 'left');
		$this->db->where('purchase.id',$idvalue);
		$this->db->where('create_product.delete_flag','0');
		$query = $this->db->get();
    	return $query->result_array();
	}
    
    
    public function get_product_detail($id)
	{
		$this->db->where('id',$id);
		$this->db->where('delete_flag','0');
		$query = $this->db->get('sell_product');
    	return $query->result_array();
	}
	
	public function get_product_name($product_id)
	{
		$this->db->where('id',$product_id);
		$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}


    public function get_product_all_sales_plot($selling_amount,$size)
	{
				$this->db->where('selling_amount',$selling_amount);
				$this->db->where('ploat_size_sqft',$size);
				$this->db->where('status','0');
				$this->db->where('type','1');
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}
	
	public function get_product_all_sales_plan($selling_amount,$size)
	{
				$this->db->where('selling_amount',$selling_amount);
				$this->db->where('ploat_size_sqft',$size);
				$this->db->where('status','0');
				$this->db->where('type','0');
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}
    
	public function get_product_all($id)
	{

				//$this->db->where('id',$id);
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}

    public function get_product_used()
	{
		$this->db->where('delete_flag','0');
		$query = $this->db->get('sell_product');
    	return $query->result_array();
	}


	public function get_product_for_index()
	{

				$this->db->order_by('id','desc');
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}

	// for Sales
	public function get_product_all_sales($id)
	{
				$this->db->where('status','0');
				$this->db->where('type','0');
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}

	// for book
	public function get_product_all_book()
	{
				$this->db->where('status','0');
				$this->db->where('type','1');
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}



	public function booked_product($id)
	{
			$this->db->where('id',$id);
			$query = $this->db->get('create_product');
		    if($query->result_array())
		    {
		    	return $query->result_array()[0];
		    }
		    else
		    {
		    	return $query->result_array();	
		    }
		    
	}

	public function get_product($id)
	{

				$this->db->where('id',$id);
				$this->db->where('delete_flag','0');
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}

	/*************  Get Lan Size Hecter And Sq.Ft ***********/



	public function get_land_detail($id)
	{
				$this->db->where('purchase_id',$id);
				$this->db->where('rem_land_ht >',0.00);
		$query = $this->db->get('purchase');
    	return $query->result_array();
	}

	public function get_purchase($id)
	{
		$this->db->select('purchase.*,purchase_land_detail.lan_size');
		$this->db->from('purchase');
		$this->db->join('purchase_land_detail', 'purchase.purchase_id = purchase_land_detail.purchase_id', 'left');
		$this->db->where('purchase.purchase_id',$id);
		$query = $this->db->get();
    	return $query->result_array();
	}

	/**************************************************/


	public function get_product_del($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('create_product');
    	return $query->result_array();
	}

	// Get Purchase Id
	
	public function all_purchase(){
			
		 		$this->db->where('delete_flag','0');
				$this->db->where('rem_land_sqft >','0.00');
		$query = $this->db->get('purchase');
    	return $query->result_array();
	}
	
	
}


	
?>