<?php
class Category_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_category()
	{
		$this->db->select('document_category.*,user.user_name');
		$this->db->join('user','user.id=document_category.created_by','left');
		return $this->db->get('document_category')->result_array();
	}	
	
	public function get_category_by_id($id)
	{
		$this->db->where('category_id',$id);
		$query = $this->db->get('document_category');
    	return $query->result_array();
	}
	
	public  function get_category_active($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('document_category',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}



}
?>