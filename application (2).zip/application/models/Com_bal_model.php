<?php

class Com_bal_model extends CI_Model
{
    
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


    public function company_balance()
    {
        return $this->db->get_where('transaction',['type' => 'investment','investment_id' => 0])->result_array();
    }

    public function company_balance_where($id)
    {
        return $this->db->get_where('transaction',['id' => $id])->result_array();
    }    
}