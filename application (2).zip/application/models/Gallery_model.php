<?php
class Gallery_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_document()
	{
		if($this->session->userdata('user_type')=='subadmin' && $this->session->userdata('id')!='1')
		{	
			$visibilty= '1';
			$this->db->where("(visibilty LIKE '%".$visibilty."%' )");
		}
		else if($this->session->userdata('user_type')=='business')
		{
			$visibilty= '2';
			$this->db->where("(visibilty LIKE '%".$visibilty."%' )");
		}
		
		else if($this->session->userdata('user_type')=='business')
		{
			$visibilty= '2';
			$this->db->where("(visibilty LIKE '%".$visibilty."%' )");
		}
		else if($this->session->userdata('user_type')=='agent')
		{
			$visibilty= '4';
			$this->db->where("(visibilty LIKE '%".$visibilty."%' )");
		}
		else if($this->session->userdata('user_type')=='customer')
		{
			$visibilty= '5';
			$this->db->where("(visibilty LIKE '%".$visibilty."%' )");
		}
		$this->db->select('gallery.*,user.user_name');
		$this->db->join('user','user.id=gallery.created_by','left');
		return $this->db->get('gallery')->result_array();
	}	
	
	public function update_visibility()
	{	
	    $arr_ids          = $this->input->post('arr_ids',TRUE);
		$visibilty_type   = implode(',', $this->input->post('visibilty_type',TRUE));
		if(is_array($arr_ids) )
		{	
			$str_ids = implode(',', $arr_ids);
			foreach($arr_ids as $k=>$v )
			{
				$data = 	array(
								  'visibilty'	=>$visibilty_type
								  );
				$this->db->where('id',$v);
				$this->db->update('gallery',$data);
				$this->session->set_userdata(array('msg_type'=>'success'));
				$this->session->set_flashdata('success','Record has been Updated successfully.');
			}
        }
		redirect($_SERVER['HTTP_REFERER'], '');
	}
	
	public  function get_category($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{	
			$this->db->select('category_id,category_name');
			$result =  $this->db->get_where('document_category',$page)->result_array();
			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public  function get_sub_category($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('document_sub_category',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}

}
?>