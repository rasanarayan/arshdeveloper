<?php
class Login_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

    public function login_Ath($user,$pass,$code)
	{	
		$user = $this->db->escape($user);
		$select = $this->db->query("SELECT * FROM `user` WHERE user_name = $user AND `delete_flag` = '0'" );
		if($select->num_rows() > 0)
		{	
			$data = $select->result_object();
			$current_time = explode(' ',date('Y-m-d H:i'))[1];
			
			if($data[0]->pass === $pass)
			{
				if($data[0]->user_type=='subadmin' && $data[0]->id!='1')
				{	
					if($data[0]->block_status=='1')
					{
						if(strtotime($data[0]->logintime) < strtotime($current_time) &&  strtotime($data[0]->logouttime) >  strtotime($current_time))
						{
							if($this->auth_code($data[0]->user_type) === $code)
							{
								return array(0,'Login Successfull...','dashboard',$data[0]->id,$data[0]->user_type,$data[0]->user_type_id,$data[0]->user_type);
							}
							else
							{
								return array(1,'Please Enter Valid Authentication Code','');
							}
						}
						else
						{
							return array(1,'Sorry, You can login in '.$data[0]->logintime.' to '.$data[0]->logouttime.' specific time in 24 hours! ','');
						}
					}
					else
					{
						return array(1,$this->block_message(),'');
					}
				}
				else
				{	
					if($data[0]->block_status=='1')
					{
						if($this->auth_code($data[0]->user_type) === $code)
						{
							return array(0,'Login Successfull...','dashboard',$data[0]->id,$data[0]->user_type,$data[0]->user_type_id,$data[0]->user_type);
						}
						else
						{
							return array(1,'Please Enter Valid Authentication Code','');
						}
					}
					else
					{
						return array(1,$this->block_message(),'');
					}
				}
			}
			else
			{
				return array(1,'Username And Password Not Match','');
			}
		}
		else
		{
			return array(1,'Username Not Registered','');
		}
	}

	public function auth_code($for)
	{
		return $this->db->get_where('auth_key',['for' => $for])->result_array()[0]['code'];
	}
	
	public function block_message()
	{
		return $this->db->get_where('masterpass',['id' =>'1'])->result_array()[0]['block_message'];
	}
}

?>