<?php
class Manual_receipt_model extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function manual_receipt()
    {   
        
        return $this->db->order_by('id','DESC')->get('manual_receipt')->result_array();
    }

    public function manual_receipt_where($id)
    {   
        return $this->db->get_where('manual_receipt',['id' => $id])->result_array()[0];
    }
}