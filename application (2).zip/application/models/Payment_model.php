<?php
class Payment_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
    
    public function sale_installment($month)
	{
		$today = strtotime(date('Y-m-d'));
		$subone = date("Y-m-d", strtotime("-".$month." month", $today));
        $this->db->order_by('date','ASC');
		$this->db->where('status','0');
		$this->db->where('date >=',$subone);
		$this->db->where('date <=',date('Y-m-d'));
		$this->db->group_by('sell_product_id');
		return $this->db->get('sell_installment_detail')->result_array();
	}
	
	
	public function saless_installment()
	{
		$today = strtotime(date('Y-m-d'));
		$plusone = date("Y-m-d", strtotime("+6 month", $today));
        $this->db->order_by('date','ASC');
		$this->db->where('status','0');
		$this->db->where('date >=',date('Y-m-d'));
		$this->db->where('date <=',$plusone);
		$this->db->group_by('sell_product_id');
		$query= $this->db->get('sell_installment_detail');
		$result = $query->result_array();	
		return $result;
		//return $this->db->get('sell_installment_detail')->result_array();
	}
	
	public function purcahse_installment($month)
	{
		$today = strtotime(date('Y-m-d'));
		$subone = date("Y-m-d", strtotime("-".$month." month", $today));
        $this->db->order_by('date','ASC');
		$this->db->where('status','0');
		$this->db->where('date >=',$subone);
		$this->db->where('date <=',date('Y-m-d'));
		$this->db->group_by('purchase_main_id');
		return $this->db->get('purchase_installment_detail')->result_array();
	}
	
	public function purchase_installment()
	{
		$today    = strtotime(date('Y-m-d'));
		$plusone  = date("Y-m-d", strtotime("+3 month", $today));
		
        $this->db->order_by('date','ASC');
        $this->db->where('status','0');
		$this->db->where('date >=',date('Y-m-d'));
		$this->db->where('date <=',$plusone);
		$this->db->group_by('saller_id');
		$query = $this->db->get('purchase_installment_detail');
		$result = $query->result_array();	
		return $result;
		//return $this->db->get('purchase_installment_detail')->result_array();
	}
	
	
	public function get_promise_alert($id, $installment_id)
	{
		$this->db->order_by('id','DESC');
		$this->db->where('sell_product_id',$id);
        $this->db->where('installment_id',$installment_id);		
		$query = $this->db->get('promise_tbl');
    	return $query->row_array();
	}
	
	public function get_promise($id)
	{
		$this->db->order_by('id','DESC');
		$this->db->where('sell_product_id',$id);		
		$query = $this->db->get('promise_tbl');
    	return $query->row_array();
	}
	
	public  function get_user_admin($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$this->db->select('*');
			$result =  $this->db->get_where('user',$page)->result_array();
			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public function get_promise_details()
	{
		$keyword = $this->db->escape_str($this->input->get_post('keyword',TRUE));
		if($keyword!='')
		{			
			$this->db->where("(customer_detail.fi_name LIKE '%".$keyword."%' )");	
		}
		$query = $this->db->select('promise_tbl.*,sell_installment_detail.no_of_installment,sell_product.coust_name,sell_product.product_id, customer_detail.fi_name ,customer_detail.la_name,user.user_type_id, create_product.product_id')
		->from('promise_tbl')
		->join('sell_installment_detail', 'sell_installment_detail.id = promise_tbl.installment_id', 'left')
		->join('sell_product', 'sell_product.id = promise_tbl.sell_product_id', 'left')
		->join('customer_detail', 'customer_detail.user_id = sell_product.coust_name', 'left')
		->join('user', 'user.id = customer_detail.user_id', 'left')
		->join('create_product', 'create_product.id = sell_product.product_id', 'left')
		->get();
		return ($query->num_rows() < 1) ? null : $query->result_array();
    }
	
	public function get_installment_yes_all()
	{
		$this->db->where('install_packges','Yes');
		$this->db->where('cancel','0');
		$this->db->where('delete_flag','0');
		if($this->session->userdata('user_type') == 'agent')
		{
		 	$this->db->where('created_by',$this->session->userdata('id'));
		}
		$this->db->where('rem_amount >','0.00');
		$query = $this->db->get('sell_product');
    	$data = $query->result_array();
    	
    	$result = [];
    	foreach ($data as $key => $value) 
		{
    		$this->db->where('user_id',$data[$key]['coust_name']);
    		$query = $this->db->get('customer_detail')->result_array();

			$this->db->where('id',$data[$key]['coust_name']);
    		$query2 = $this->db->get('user')->result_array()[0];    		


    		$this->db->where('id',$data[$key]['product_id']);
    		$product = $this->db->get('create_product')->result_array();

    		$result[] = [$data[$key]['id'],$query[0]['fi_name'].' '.$query[0]['la_name'].' - '.$query2['user_type_id'].' - '.$product[0]['product_id']];
    	}
    	return $result;
	}

	public function get_sell_for_payment($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('sell_product');
    	return $query->result_array();
	}

	public function get_sell_paid_installment($id)
	{
		$query = $this->db->query("SELECT SUM(instal_amount) AS `sum_paid` FROM `sell_installment_detail` WHERE `sell_product_id` = '".$id."' AND `status` =  '1'");

		if(empty($query->result_array()[0]['sum_paid']))
		{
			return 0.00;
		}
		else
		{
    		return $query->result_array()[0]['sum_paid'];
		}
	}
	
	public function get_sell_installment($id,$time)
	{
		$query = $this->db->query("SELECT * FROM `sell_installment_detail` WHERE `sell_product_id` = '".$id."' AND `time` = '".$time."' AND `status` =  '0'  ORDER BY `id` ASC LIMIT 1");

    	return $query->row_array();
	}

	public function get_sell_installment_by_id($id)
	{
		$query = $this->db->query("SELECT * FROM `sell_installment_detail` WHERE `id` = '".$id."'");

    	return $query->row_array();
	}

	public function get_sell_payments($type)
	{
	$pay_type		=	$this->input->get('pay_type');
		$cheque_status	=	$this->input->get('cheque_status');
		$from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
        $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
		$admintype		=   $this->db->escape_str(trim($this->input->get_post('admin_type',TRUE)));	
	if($pay_type!='')
		{
			$this->db->where('pay_type',$pay_type);	
		}
		if($admintype!='')
		{
			$this->db->where('created_by',$admintype);	
		}
		if($cheque_status!='')
		{
			$this->db->where('cheque_status',$cheque_status);	
		}
		if($from_date!='' )
		{
			$fromDate = date("Y-m-d", strtotime($from_date));
			$this->db->where("date>=",$fromDate);
		}
		if($to_date!='')
		{
			$toDate = date("Y-m-d", strtotime($to_date));
			$this->db->where("date<=",$toDate);
		}
		$this->db->order_by('id','DESC');
		$this->db->where('type',$type);
		if($this->session->userdata('id') != '1')
		{
			$this->db->where('created_by',$this->session->userdata('id'));			
		}
		$query = $this->db->get('payment');
    	return $query->result_array();
	}
	
	public function get_sell_payments_profile($type , $mode , $id)
	{
		$from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
        $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
		if($from_date!='' )
		{
			$fromDate = date("Y-m-d", strtotime($from_date));
			$this->db->where("payment.date>=",$fromDate);
		}
		if($to_date!='')
		{
			$toDate = date("Y-m-d", strtotime($to_date));
			$this->db->where("payment.date<=",$toDate);
		}
		
		$this->db->select('SQL_CALC_FOUND_ROWS payment.*,sell_product.coust_name , sell_product.product_id  , user.user_type_id , user.user_name',FALSE);
		$this->db->from('payment');
		$this->db->join('sell_product', 'sell_product.id  = payment.main_id', 'left');
		$this->db->join('user', 'user.id  = sell_product.coust_name', 'left');
	    $this->db->where('payment.type =',$type);
		$this->db->where('payment.pay_type !=',$mode);
		$this->db->where('sell_product.coust_name =',$id);
		$query=$this->db->get();
		//echo_sql();
		$result = $query->result_array();	
		return $result;
		
	}

    public function get_late_fee_profile($id)
	{	
		$this->db->select('sum(payment.late_charge) as total_late_charge',FALSE);
		$this->db->from('payment');
		$this->db->join('sell_product', 'sell_product.id  = payment.main_id', 'left');
		$this->db->where('sell_product.coust_name =',$id);
		$this->db->group_by("sell_product.coust_name"); 
		$query=$this->db->get();
		//echo_sql();
		$result = $query->row_array();	
		return $result;
		
	}
	
	public function get_sell_payment($id)
	{
		$this->db->where('id',$id);

		

		$query = $this->db->get('payment');
    	return $query->result_array();
	}

	public function get_sell_payments_byid($id)
	{
		$this->db->order_by('id','DESC');
		$this->db->where('type','sales');
		$this->db->where('created_by',$id);		
		$query = $this->db->get('payment');
    	return $query->result_array();
	}


	public function get_sell($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('sell_product');
    	return $query->result_array()[0];
	}

	public function get_paid_amount($sale_id,$payment_id)
	{
		$this->db->where('type','sales');
		$this->db->where('main_id',$sale_id);
		$this->db->where('id <=',$payment_id);
		$payments = $this->db->get('payment')->result_array();
		$paid_installments = 0;
		foreach ($payments as $key => $value) {
			$paid_installments += $value['amount_install'];
		}

		return $paid_installments;
	}
	
	public function get_plan($id){
		$plan_id = $this->get_sell($id)['plan_id'];
		$this->db->where('id',$plan_id);
		$query = $this->db->get('plan_code');
    	return $query->result_array()[0];
		
	}

	public function get_customer($id)
	{
		$this->db->where('user_id',$id);
		$query = $this->db->get('customer_detail');
    	$data = $query->result_array()[0];
    	return $data['fi_name'].' '.$data['mi_name'].' '.$data['la_name'];
	}

	public function _get_user($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('user');
    	return $query->result_array()[0];
	}

	public function get_product($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('create_product');
    	$data = $query->result_array()[0];
    	return $data['product_id'];
	}
	
	public function get_product_value($id)
	{
		//print_r($id); die;
		$this->db->where('id',$id);
		$query = $this->db->get('create_product');
    	$data = $query->result_array()[0];
		 $value =$data['product_id'];
		 return $value;
	}

	public function get_product_row($sell_id)
	{
		$id = $this->get_sell($sell_id)['product_id'];
		$this->db->where('id',$id);
		$query = $this->db->get('create_product');
    	return $query->result_array()[0];
	}


	public function get_next_due($sell_id,$install_id,$pay_id)
	{

		$this->db->select_sum('amount_install');
	    $this->db->from('payment');
	    $this->db->where('type','sales');
	    $this->db->where('main_id',$sell_id);
	    $this->db->where('id <=',$pay_id);
	    $query = $this->db->get();
	    $payment = $query->row()->amount_install;

	    $this->db->select('*');
	    $this->db->from('sell_installment_detail');
		$this->db->where('sell_product_id',$sell_id);
		$this->db->order_by('id','ASC');
		$query = $this->db->get()->result();
		
		foreach ($query as $key => $value) {
			if($payment > 0){
				if($value->instal_amount > $payment){
					$ret = _vdate($value->date);
					break;
				}
				else{
					$payment -= $value->instal_amount;
				}
			}else{
				$ret = _vdate($value->date);
				break;
			}
		}
		return $ret;
		// $this->db->where('sell_product_id',$sell_id);
		// $this->db->where('id >',$install_id);
		// $this->db->order_by('id','ASC');
		// $this->db->limit(1);
		// $query = $this->db->get('sell_installment_detail');
		// if($query->result_array())
		// {
		// 	return _vdate($query->result_array()[0]['date']);
		// }
		// else
		// {
		// 	return 'This Is Last Installment';
		// }
	}



	

	/*************************************************************************************************************
									Start Purchase Payment
	*************************************************************************************************************/


	public function get_purchase($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('purchase');
    	return $query->result_array()[0];
	}

	public function get_purchase_saller($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('purchase_seller_dynamic');
    	return $query->result_array()[0];
	}

	public function get_pruchase_install_yes_all()
	{

		
		$this->db->where('balance >','0.00');
		$query = $this->db->get('purchase_seller_dynamic');
    	return $data = $query->result_array();
    	
	}

	public function get_purchase_for_payment($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('purchase');
    	return $query->result_array();
	}

	public function find_saleer($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('purchase_seller_dynamic');
    	return $query->result_array();
	}

	public function get_purchase_paid_installment($id)
	{
		$query = $this->db->query("SELECT SUM(instal_amount) AS `sum_paid` FROM `purchase_installment_detail` WHERE `saller_id` = '".$id."' AND `status` =  '1'");

		if(empty($query->result_array()[0]['sum_paid']))
		{
			return 0.00;
		}
		else
		{
    		return $query->result_array()[0]['sum_paid'];
		}
	}

	public function get_purchase_installment($id)
	{
		$query = $this->db->query("SELECT * FROM `purchase_installment_detail` WHERE `saller_id` = '".$id."' AND `status` =  '0' ORDER BY `id` ASC LIMIT 1");

    	return $query->result_array()[0];
	}

	public function get_purchase_installment_by_id($id)
	{
		$query = $this->db->query("SELECT * FROM `purchase_installment_detail` WHERE `id` = '".$id."'");

    	return $query->result_array()[0];
	}




	/*************************************************************************************************************
									Edit Purchase Payment
	*************************************************************************************************************/

	



	public function _payment($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('payment');
    	return $query->result_array()[0];
	}


	public function sale_delete_off($payment_id,$type)
	{
		$payment = $this->_payment($payment_id);
		$this->db->where('main_id',$payment['main_id']);
		$this->db->where('type',$type);
		$a = 0;
		foreach($this->db->get('payment')->result_array() as $key => $value)
		{
			if($value['id'] > $payment['id'])
			{
				$a++;
			}
		}

		if($a > 0)
		{
			return false;
		}
		else
		{
			return true;			
		}
	}



}

?>