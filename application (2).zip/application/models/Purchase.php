<?php 
class Purchase extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_related_purchase($purchase_array){
		
		$products = $this->db->get_where('create_product',['purchase_id' => $purchase_array['purchase_id'],'delete_flag' => '0'])->num_rows();
		$expense = $this->db->get_where('expense',['purchase_id' => $purchase_array['id'],'delete_flag' => '0'])->num_rows();
		$sallers = $this->db->get_where('purchase_seller_dynamic',['p_id' => $purchase_array['purchase_id']])->result_array();
		$count = 0;
		foreach ($sallers as $key => $value) {	
			$payments = $this->db->get_where('payment',['main_id' => $value['id'],'type' => 'purchase'])->num_rows();
			$count += $payments;
		}

		return $products + $expense + $count;
	}
	
	public function purchase_land_detail($id){
				$this->db->where('purchase_main_id',$id);
		$query = $this->db->get('purchase_land_detail');
    	return $query->result_array();
	}
	
	public function expenses($id){
		$this->db->select_sum('amount');
		$this->db->where('purchase_id',$id);
		$query = $this->db->get('expense');
		return $query->row_array();
		}

	public function installment_purchase($id){

		$this->db->where('saller_id',$id);		 
		$this->db->order_by('id','ASC');		 
		$query = $this->db->get('purchase_installment_detail');
    	return $query->result_array();
	}
	

	public function all_purchase(){

		 		$this->db->order_by("id","desc");
				$this->db->where('delete_flag','0');
				 
		$query = $this->db->get('purchase');
    	return $query->result_array();
	}

    public function seller_land_detail($id){
				$this->db->where('main_id',$id);
		$query = $this->db->get('purchase_purchaser_dynamic');
    	return $query->result_array();
	}
	
	public function single_purchase($id)
	{

		 		$this->db->order_by("id","desc");
		 		$this->db->where('id',$id);
				$this->db->where('delete_flag','0');
				 
		$query = $this->db->get('purchase');
    	return $query->result_array();
	}

	public function seller_dynamic($id){
				$this->db->where('main_id',$id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_seller_dynamic',1);
    	return $query->result_array();
	}

	public function seller_dynamic_seller($id,$first_id){
				$this->db->where('main_id',$id);
				$this->db->where('id !=',$first_id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_seller_dynamic');
    	return $query->result_array();

	}
	
	/*------------------------------------------------ */
	public function purchaser_dynamic($id){
				$this->db->where('main_id',$id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_purchaser_dynamic',1);
    	return $query->result_array();
	}

	public function purchase_dynamic_purchaser($id){
				$this->db->where('main_id',$id);
				$this->db->where('id !=',$first_id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_purchaser_dynamic');
    	return $query->result_array();
	}
	
	public function purchase_dynamic_purchaser_all($id,$second_id){
				$this->db->where('main_id',$id);
				$this->db->where('id !=',$second_id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_purchaser_dynamic');
    	return $query->result_array();
	}
	
	/*------------------------------------------------ */

	

	

	public function installment_detail($id){
				$this->db->where('purchase_main_id',$id);
		 		$this->db->order_by("id","desc");
		$query = $this->db->get('purchase_installment_detail');
    	return $query->result_array();
	}

	// For View function	
	public function installment_detail_asc($id){
				$this->db->where('purchase_main_id',$id);
		 		$this->db->order_by("id","ASC");
		$query = $this->db->get('purchase_installment_detail');
    	return $query->result_array();
	}

	// For Print & Delete Iamge
	public function all_seller_dynamic($id){
				$this->db->where('main_id',$id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_seller_dynamic');
    	return $query->result_array();
	}

	public function all_purchaser_dynamic($id){
				$this->db->where('main_id',$id);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('purchase_purchaser_dynamic');
    	return $query->result_array();
	}

	public function get_expenses($id){
				$this->db->where('purchase_id',$id);
				$this->db->where('delete_flag',0);
				$this->db->order_by("id", "asc");
		$query = $this->db->get('expense');
    	return $query->result_array();
	}
	
	public  function get_sell_list($id)
	{		
		$this->db->select('create_product.*,sell_product.id as callid');
		$this->db->from('create_product');
		$this->db->join('sell_product', 'create_product.id = sell_product.product_id', 'left');
		$this->db->where('create_product.delete_flag',0);
		$this->db->where('create_product.status',1);
		$this->db->where('create_product.purchase_id',$id);
		$q=$this->db->get();
		$result = $q->result_array();	
		return $result;
		
	}

	

}

?>