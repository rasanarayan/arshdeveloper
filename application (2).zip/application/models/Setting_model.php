<?php
class Setting_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function find_customer($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('subadmin_details');
    	return $query->row_array()['first_name'];
	}
	
	 public function get_plan_code($id='')
	{
		$this->db->where('delete_flag','0');
		if($id!='')
		{
			$this->db->where('id',$id);
		}
		$this->db->order_by('id','DESC');
		$query = $this->db->get('plan_code');
    	return $query->result_array();
	}
	
	public  function get_customer($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('user',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	
	public function get_userinfo($id)
	{
		//echo"<pre>"; print_r($id); die;
		$this->db->where('user_id',$id);
		$usernam = $this->db->get('subadmin_details')->row_array['first_name'];
	    print_r($usernam); die;
	}
	
	public function get_balance($id)
	{
			//$id = $this->session->userdata('id');	
			
			$credit = $this->db->query("SELECT SUM(credit) AS `all_credit` FROM `transaction` WHERE `credit_by` = '".$id."' AND `type` != 'investment'")->result_array();

			$debit = $this->db->query("SELECT SUM(debit) AS `all_debit` FROM `transaction` WHERE `debit_by` = '".$id."'")->result_array();
			if($credit[0]['all_credit'] - $debit[0]['all_debit'] > 0){
				$ar = ['balance' => $credit[0]['all_credit'] - $debit[0]['all_debit']];
			}
			else
			{
				$ar = ['balance' => 0];
			}
			return $ar;
	}
	
	
	public function get_total_days($emptype,$month,$year)
	{
	    $firstdate = $year."-"."0".$month."-"."01";
		$lastdate = $year."-"."0".$month."-"."31"; 
		$this->db->select('count(emp_id) as total_num',FALSE);
		$this->db->where("attendance.visit_date>=",$firstdate);
		$this->db->where("attendance.visit_date<=",$lastdate);
		$this->db->where("attendance.emp_id=",$emptype);
		$this->db->where("attendance.attendence_type!=",'0');
		$this->db->from('attendance');
		$query=$this->db->get();
		return $query->result_array();	
			
	}
	
	public function get_all_cms_page($offset='0',$limit='10',$param=array())
	{		
		$status			    =   @$param['status'];
		$orderby		    =   @$param['orderby'];	
		$where		        =   @$param['where'];	
		
		$keyword = $this->db->escape_str($this->input->get_post('keyword',TRUE));
		$status = $this->db->escape_str($this->input->get_post('status',TRUE));
			
	    if($status!='')
		{
			$this->db->where("status","$status");
		}
		
	    if($where!='')
		{
			$this->db->where($where);
		}
		if($keyword!='')
		{
			$this->db->where("(page_name LIKE '%".$keyword."%' )");
		}
		if($orderby!='')
		{
			 $this->db->order_by($orderby);
		}
		else
		{
		  $this->db->order_by('page_name','asc');
		}
		$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS*',FALSE);
		$this->db->where("status!=","2");
		$this->db->from('tbl_cms_pages');
		$q=$this->db->get();
		$result = $q->result_array();	
		return $result;
	}
	
	
	public function get_mobile($id)
	{
			//$id = $this->session->userdata('id');	
			
			$mobile = $this->db->query("SELECT  `mobile` FROM `user` WHERE `user_name` = '".$id."' ")->row_array();
           return $mobile;
	}
	
	public function get_codep($id)
	{
       
		$this->db->where('id',$id);
		$query = $this->db->get('locations_for_circlerate');
    	return $query->result_array();
	}
	
	public function get_sal($id)
	{
			
			$sallary = $this->db->query("SELECT  'sallary' FROM 'employee_details' WHERE 'user_id' = '".$id."' ")->row_array();
           return $sallary;
	}
	
	public  function get_sallaryy($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('employee_details',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	
	
	
public function get_visit_report()
	{
    $from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
    $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
	//echo"<pre>"; print_r($from_date); die;
	if($from_date!='' )
	{
		$fromDate = date("Y-m-d", strtotime($from_date));
        $this->db->where("visit_date>=",$fromDate);
	}
	if($to_date!='')
	{
		$toDate = date("Y-m-d", strtotime($to_date));
		$this->db->where("visit_date<=",$toDate);
	}
	$this->db->where('delete_flag','0');
	$this->db->order_by('id','DESC');
	$query = $this->db->get('visit_report');
    return $query->result_array();
	}
	
	public function get_attendance()
	{
	$name_type		=	$this->input->get('name_type');
	$attendence_type	=	$this->input->get('attendence_type');
    $from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
    $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
	//echo"<pre>"; print_r($from_date); die;
	if($name_type!='')
	{
	$this->db->where('emp_id',$name_type);	
	}
	if($attendence_type!='')
	{
	$this->db->where('attendence_type',$attendence_type);	
	}
	if($from_date!='' )
	{
		$fromDate = date("Y-m-d", strtotime($from_date));
        $this->db->where("visit_date>=",$fromDate);
	}
	if($to_date!='')
	{
		$toDate = date("Y-m-d", strtotime($to_date));
		$this->db->where("visit_date<=",$toDate);
	}
	$this->db->where('delete_flag','0');
	$this->db->order_by('id','DESC');
	$query = $this->db->get('attendance');
    return $query->result_array();
	}
	
	public function get_delete_report()
	{
    $this->db->where('delete_flag','1');
	$this->db->order_by('id','DESC');
	$query = $this->db->get('visit_report');
    return $query->result_array();
	}
	
	public  function get_usr_agent($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('user',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public  function get_data_emp($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('employee_details',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	
	public  function get_employees($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('user',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public  function get_sallary($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('sallary',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public function get_user($id)
	{
		
		$this->db->where('id',$id);
		$sale = $this->db->get('user')->row_array()['user_name'];
	    return $sale;
	}
	
	public function get_late_charges()
	{

				$this->db->where('delete_flag','0');
				$this->db->order_by('id','asc');
		$query = $this->db->get('late_charges');
    	return $query->result_array();
	}

	public function edit_plan_code($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('plan_code');
    	return $query->row_array();
	}
	
	public function edit_visit_report($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('visit_report');
    	return $query->result_array();
	}
	
	public function edit_attendence($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('attendance');
    	return $query->result_array();
	}
	
	
	public function edit_installment_charge($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('late_charges');
    	return $query->result_array();
	}

	public function get_bank()
	{

				$this->db->where('id','1');
		$query = $this->db->get('bank');
    	return $query->result_array()[0];
	}

	public function get_promotion()
	{

				$this->db->where('id','1');
		$query = $this->db->get('agent_promotion');
    	return $query->result_array()[0];
	}


	public function get_plan_code_single($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('plan_code');
    	return $query->result_array()[0];
	}
	
	public function get_late_single($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('late_charges');
    	return $query->result_array()[0];
	}

	public function get_plan_code_single_by_code($id)
	{

				$this->db->where('plan_code',$id);
		$query = $this->db->get('plan_code');
    	return $query->result_array()[0];
	}

	
	public function get_agent_deactivation()
	{

		$query = $this->db->get('agent_deactivation');
    	return $query->result_array()[0];
	}

	public function get_locations()
	{
		return $this->db->get_where('purchase',['delete_flag' => '0'])->result_array();
	}


	public function get_authcode()
	{
		return $this->db->get('auth_key')->result_array();
	}
	
	
	public function edit_lands_for_circele_rate($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('locations_for_circlerate');
    	return $query->result_array();
	}
	
   public function get_circleratelist()
	{

		$query = $this->db->get('circle_rate_list');
    	return $query->result_array();
	}
	
	public function get_locations_for_circlerate()
	{

				$this->db->where('delete_flag','0');
				$this->db->order_by('id','asc');
		$query = $this->db->get('locations_for_circlerate');
    	return $query->result_array();
	}
	
	public function get_master()
	{

		$query = $this->db->get('masterpass');
    	return $query->row_array();
	}


	


}

?>