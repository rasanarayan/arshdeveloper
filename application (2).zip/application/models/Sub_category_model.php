<?php
class Sub_category_model extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_sub_category()
	{
		$this->db->select('document_sub_category.*,document_category.category_name,user.user_name');
		$this->db->join('user','user.id=document_sub_category.created_by','left');
		$this->db->join('document_category','document_category.category_id=document_sub_category.category_id','left');
		$this->db->group_by('document_sub_category.sub_category_id');
		return $this->db->get('document_sub_category')->result_array();
	}	
	
	public function get_sub_category_by_id($id)
	{
		$this->db->where('sub_category_id',$id);
		$query = $this->db->get('document_sub_category');
    	return $query->result_array();
	}


}
?>