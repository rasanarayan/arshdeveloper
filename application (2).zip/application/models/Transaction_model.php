
<?php
class Transaction_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

    public function get_transaction_invest($user_id)
	{	
		$this->db->select('transaction.*,purchase.purchase_id,purchase.id as purch_id');
		$this->db->order_by('transaction.date','desc');
		$this->db->where_in('transaction.type',array('purchase','expense'));
		if($user_id!=1)
		{
			$this->db->where('transaction.debit_by',$user_id);
		}
		else
		{
			$this->db->where('transaction.debit_by',0);
		}
		$this->db->join('purchase','purchase.id=transaction.investment_id','left');
		$query = $this->db->get('transaction');
		return $query->result_array();
	}
	
	
	public function get_land_name($id)
	{
		
		$this->db->where('id',$id);
		$sale = $this->db->get('purchase')->row_array()['purchase_id'];
	    return $sale;
	}
	
	public function get_plot_name($id)
	{
		
		$this->db->where('id',$id);
		$sale = $this->db->get('create_product')->row_array()['product_id'];
	    return $sale;
	}
	
	public function get_transaction_invests($user_id)
	{	
	
	    $this->db->select('transaction.*,purchase.purchase_id,purchase.id as purch_id');
		$this->db->order_by('transaction.date','desc');
		$this->db->where_in('transaction.type',array('purchase'));
		if($user_id!=1)
		{
			$this->db->where('transaction.debit_by',$user_id);
		}
		else
		{
			$this->db->where('transaction.debit_by',0);
		}
		$this->db->join('purchase','purchase.id=transaction.investment_id','left');
		$query = $this->db->get('transaction');
		return $query->result_array();
	}
	
	public function get_transaction_invest_expense($user_id)
	{	
	
	    $this->db->select('transaction.*,expense.purchase_id,expense.create_product_id as purch_id');
		$this->db->order_by('transaction.date','desc');
		$this->db->where_in('transaction.type',array('expense'));
		if($user_id!=1)
		{
			$this->db->where('transaction.debit_by',$user_id);
		}
		else
		{
			$this->db->where('transaction.debit_by',0);
		}
		$this->db->join('expense','expense.id=transaction.investment_id','left');
		$query = $this->db->get('transaction');
		return $query->result_array();
	}
	
	
	// For Business Partner Dashboard
	public function get_transaction_business()
	{
		$this->db->order_by('date','desc');
		$this->db->where('credit_by',$this->session->userdata('id'));
		$this->db->or_where('debit_by',$this->session->userdata('id'));
		$query = $this->db->get('transaction');
		return $query->result_array();
	}

	public function get_transaction_agent()
	{
		$this->db->order_by('date','desc');
		$this->db->where('credit_by',$this->session->userdata('id'));
		$this->db->or_where('debit_by',$this->session->userdata('id'));
		$query = $this->db->get('transaction');
		return $query->result_array();
	}
	/************************************/

	public function distinct_id_credit()
	{
		$this->db->select('credit_by');
		$this->db->distinct();
		$this->db->where('credit_by !=','');
		$query = $this->db->get('transaction');
		return $query->result_array();
	}


	public function all_business()
	{
		

    	$array  = ['id !=' => '1','delete_flag' => '0','user_type' => 'business','key_persons' => '0'];
		return $query = $this->db->get_where('user',$array)->result_array();

	}

	public function get_business_name($id)
	{
		

    	$this->db->where('user_id',$id);
    	$data = $this->db->get('business_partners')->result_array()[0];
    	return $data['fi_name'].' '.$data['mi_name'].' '.$data['la_name'];
	}

	

	public function balance()
	{
		$ar = [];
		foreach ($this->distinct_id_credit() as $key => $value) {

			$credit = $this->db->query("SELECT SUM(credit) AS `all_credit` FROM `transaction` WHERE `credit_by` = '".$this->distinct_id_credit()[$key]['credit_by']."'")->result_array();

			$debit = $this->db->query("SELECT SUM(debit) AS `all_debit` FROM `transaction` WHERE `debit_by` = '".$this->distinct_id_credit()[$key]['credit_by']."'")->result_array();
			if($credit[0]['all_credit'] - $debit[0]['all_debit'] > 0){
				$ar[] = [$this->distinct_id_credit()[$key]['credit_by'],$credit[0]['all_credit'] - $debit[0]['all_debit']];
			}
		}
		return $ar;
	}


	public function get_parterner_balance($id)
	{
		

			$credit = $this->db->query("SELECT SUM(credit) AS `all_credit` FROM `transaction` WHERE `credit_by` = '".$id."'")->result_array();

			$debit = $this->db->query("SELECT SUM(debit) AS `all_debit` FROM `transaction` WHERE `debit_by` = '".$id."'")->result_array();
			if($credit[0]['all_credit'] - $debit[0]['all_debit'] > 0){
				$ar = ['balance' => $credit[0]['all_credit'] - $debit[0]['all_debit']];
			}
			else
			{
				$ar = ['balance' => 0];
			}
			return $ar;
	}
	
	public function get_transaction_ca_recent_limit($limit='10',$offset='0',$param=array())
	 {		
		$status			    =   @$param['status'];
		$orderby		    =   @$param['orderby'];	
		$where		        =   @$param['where'];	
		$category_id		=   @$param['category_id'];
		//echo $category_id; die;
		$keyword = $this->db->escape_str($this->input->get_post('keyword',TRUE));
		$status = $this->db->escape_str($this->input->get_post('status',TRUE));
		$from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
        $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
		
		if($category_id!='')
		{
			$this->db->where("transaction.category","$category_id");
		}
	    if($where!='')
		{
			$this->db->where($where);
		}
		if($from_date!='' )
		{
			$fromDate = date("Y-m-d", strtotime($from_date));
			$this->db->where("date>=",$fromDate);
		}
		if($to_date!='')
		{
			$toDate = date("Y-m-d", strtotime($to_date));
			$this->db->where("date<=",$toDate);
		}
		
		if($keyword!='')
		{			
			$this->db->where("(type LIKE '%".$keyword."%' )");	
		}
		if($orderby!='')
		{
			 $this->db->order_by($orderby);
		}else
		{
		  $this->db->order_by('id','desc');
		}
		//echo $limit; die;
		$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS transaction.*,user.user_name',FALSE);
		$this->db->from('transaction');
		$this->db->join('user', 'transaction.credit_by  = user.id', 'left');
        $this->db->where('transaction.mode !=','cash');
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		return $result;		
	}
	
	public function get_products($limit='10',$offset='0',$param=array(),$excel="0")
	{
		//$status			    =   @$param['status'];
		$orderby		    =   @$param['orderby'];	
		$where		        =   @$param['where'];	
		$category_id		=   @$param['category_id'];
		
		//$status				=   $this->db->escape_str(trim($this->input->get_post('status',TRUE)));						
		$keyword			=   $this->db->escape_str(trim($this->input->get_post('keyword',TRUE)));
		$seller_retailer	=   $this->db->escape_str(trim($this->input->get_post('seller_retailer',TRUE)));
		$from_date			=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));		
		$to_date			=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));		
		//echo $keyword; die;
		if($category_id!='')
		{
			$this->db->where("transaction.category","$category_id");
		}
		
		 if($where!='')
		{
			$this->db->where($where);
		}
		if($from_date!='' )
		{
			$fromDate = date("Y-m-d", strtotime($from_date));
			$this->db->where("date>=",$fromDate);
		}
		if($to_date!='')
		{
			$toDate = date("Y-m-d", strtotime($to_date));
			$this->db->where("date<=",$toDate);
		}
		
		if($keyword!='')
		{			
			$this->db->where("(type LIKE '%".$keyword."%' )");	
		}
		if($orderby!='')
		{
			 $this->db->order_by($orderby);
		}else
		{
		  $this->db->order_by('id','desc');
		}
		
	    
		if($excel=='0')
		{
			$this->db->limit($limit,$offset);
		}
		$this->db->select('SQL_CALC_FOUND_ROWS transaction.*,user.user_name',FALSE);
		$this->db->from('transaction');
		$this->db->join('user', 'transaction.credit_by  = user.id', 'left');
		$this->db->where('transaction.mode !=','cash');
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		$result = ($limit=='1') ? @$result[0]: $result;	
		return $result;
	
	}  
	

	public function get_parterner_credit($id)
	{
		

			$credit = $this->db->query("SELECT SUM(credit) AS `all_credit` FROM `transaction` WHERE `credit_by` = '".$id."' AND `type` != 'investment'")->result_array();

			if($credit){
				$ar = ['balance' => $credit[0]['all_credit']];
			}
			else
			{
				$ar = ['balance' => 0];
			}
			return $ar;
	}

	public function get_parterner_debit($id)
	{
		

			$debit = $this->db->query("SELECT SUM(debit) AS `all_debit` FROM `transaction` WHERE `debit_by` = '".$id."'")->result_array();

			if($debit){
				$ar = ['balance' => $debit[0]['all_debit']];
			}
			else
			{
				$ar = ['balance' => 0];
			}
			return $ar;
	}

	public function get_parterner_total_investment($id)
	{
		
			$credit = $this->db->query("SELECT SUM(credit) AS `all_credit` FROM `transaction` WHERE `credit_by` = '".$id."' AND `type` = 'investment'")->result_array();

			if($credit){
				$ar = ['balance' => $credit[0]['all_credit']];
			}
			else
			{
				$ar = ['balance' => 0];
			}
			return $ar;
	}
	
public function get_transaction_recent_limit($limit='10',$offset='0',$param=array())
	 {		
		$status			    =   @$param['status'];
		$orderby		    =   @$param['orderby'];	
		$where		        =   @$param['where'];	
		$category_id		=   @$param['category_id'];
		$keyword = $this->db->escape_str($this->input->get_post('keyword',TRUE));
		$status = $this->db->escape_str($this->input->get_post('status',TRUE));
		$from_date		=   $this->db->escape_str(trim($this->input->get_post('from_date',TRUE)));	
        $to_date		=   $this->db->escape_str(trim($this->input->get_post('to_date',TRUE)));
		
		if($category_id!='')
		{
			$this->db->where("transaction.category","$category_id");
		}
	    if($where!='')
		{
			$this->db->where($where);
		}
		if($from_date!='' )
		{
			$fromDate = date("Y-m-d", strtotime($from_date));
			$this->db->where("date>=",$fromDate);
		}
		if($to_date!='')
		{
			$toDate = date("Y-m-d", strtotime($to_date));
			$this->db->where("date<=",$toDate);
		}
		
		if($keyword!='')
		{			
			$this->db->where("(type LIKE '%".$keyword."%' )");	
		}
		if($orderby!='')
		{
			 $this->db->order_by($orderby);
		}else
		{
		  $this->db->order_by('id','desc');
		}
		//echo $limit; die;
		$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS transaction.*,user.user_name',FALSE);
		$this->db->from('transaction');
		$this->db->join('user', 'transaction.credit_by  = user.id', 'left');
        //$this->db->where('transaction.status !=','2');
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		return $result;		
	}
	
	public function get_transaction_by_id($id)
	 {		
		
		$this->db->order_by('id','asc');
		//$this->db->limit($limit,$offset);
		$this->db->select('SQL_CALC_FOUND_ROWS transaction.*,user.user_name',FALSE);
		$this->db->from('transaction');
		$this->db->join('user', 'transaction.credit_by  = user.id', 'left');
        $this->db->where('transaction.credit_by=',$id);
		$q=$this->db->get();
		//echo_sql();
		$result = $q->result_array();	
		return $result;		
	}
	
}
?>