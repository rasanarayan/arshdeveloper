<?php
class User_genaral extends CI_Model
{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('add_product');
		$this->load->model('users');
		$this->load->model('all_model');
	}


	public function get_user($id)
	{

				$this->db->where('id',$id);
		$query = $this->db->get('user');
    	return $query->row_array();
	}
	
	public function users_status($user_type)
	{
		$this->db->select('user.*,COUNT(sell_product.id ) as sell_count');
		$this->db->order_by("user.id","desc");
		$this->db->where('user.id !=','1');
		if($this->session->userdata('user_type') == 'agent')
		{
			$this->db->where('user.created_by',$this->session->userdata('id'));
		}
		$this->db->where('user.delete_flag','0');
		$this->db->where('user_type',$user_type);
		$this->db->join('sell_product','sell_product.coust_name=user.id','left');
		$this->db->group_by('user.id');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function users($user_type)
	{
		
				 $this->db->order_by("id","desc");
				 $this->db->where('id !=','1');
				if($this->session->userdata('user_type') == 'agent'){
				 	$this->db->where('created_by',$this->session->userdata('id'));
				}
				 $this->db->where('delete_flag','0');
				 $this->db->where('user_type',$user_type);
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function customer_detail($id)
	{

				$this->db->where('user_id',$id);
		$query = $this->db->get('customer_detail');
		$data =  $query->result_array();
		//echo "<pre>"; print_r($data);
		if(is_array($data) && !empty($data))
		{
			return $data[0];
		}
		else
		{
			return array();
		}
	}



	public function commission_parterner($sales_id,$amount,$date,$type,$mode)
	{
		$commition = 0;
		if($this->get_partner())
		{
			foreach ($this->get_partner() as $key => $value) {
				if($this->get_percentage($value['id'])['persent'] != '0.00')
				{
					$persent = $this->get_percentage($value['id'])['persent'];
					$commission = $amount * $persent / 100;
					$commition += $commission;
					$transaction = [
	                    'type'              =>  $type.'commission',
	                    'credit'            =>  $commission,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  $value['id'],
	                    'date'              =>  $date,
	                    'mode'              =>  $mode,
	                    'investment_id'     =>  $sales_id,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];

               		$this->db->insert('transaction', $transaction);
				}
			}
		}
		return $commition;
	}

	public function commission_parterner_ins($sales_id,$amount,$date,$type,$payment_id,$mode)
	{
		$commition = 0;
		if($this->get_partner())
		{
			foreach ($this->get_partner() as $key => $value) {
				if($this->get_percentage($value['id'])['persent'] != '0.00')
				{
					$persent = $this->get_percentage($value['id'])['persent'];
					$commission = $amount * $persent / 100;
					if($commission > 0)
					{
					$commition += $commission;
					$transaction = [
	                    'type'              =>  $type.'commission',
	                    'credit'            =>  $commission,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  $value['id'],
	                    'date'              =>  $date,
	                    'mode'              =>  $mode,
	                    'investment_id'     =>  $payment_id,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];

               		$this->db->insert('transaction', $transaction);
					}
				}
			}
		}
		return $commition;
	}


	public function share_company_expence_etc($sales_id,$amount,$date)
	{
		$share = 0;
		if($this->get_share_product($sales_id))
		{
			foreach ($this->get_share_product($sales_id) as $key => $value) {
				
					
					$commission = $value['amount'];
					$share += $commission;
					$transaction = [
	                    'type'              =>  'sales',
	                    'credit'            =>  $commission,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  $value['parterner'],
	                    'date'              =>  $date,
	                    'investment_id'     =>  $sales_id,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];

               		$this->db->insert('transaction', $transaction);
				
			}
		}
		return $share;
	}

	public function share_company_after_all($sales_id,$amount,$date,$type,$mode)
	{
		$share = 0;
		if($this->get_share_product($sales_id))
		{
			foreach ($this->get_share_product($sales_id) as $key => $value) {
				
					$persent = $value['percent'];
					$commission = $amount * $persent / 100;

					$share += $commission;
					$transaction = [
	                    'type'              =>  $type.'profit',
	                    'credit'            =>  $commission,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  $value['parterner'],
	                    'date'              =>  $date,
	                    'mode'              =>  $mode,
	                    'investment_id'     =>  $sales_id,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];

               		$this->db->insert('transaction', $transaction);

               		if($value['parterner'] != 0){
               			$inv = $this->users->business_detail($value['parterner'])[0];
               			$user = $this->users->get_user($value['parterner'])[0];
               			$balance = $this->all_model->business_balance($value['parterner']);
               			investor_sell_credit($inv['mobile'],$inv['fi_name'],$user['user_type_id'],$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);
               		}
				
			}
		}
		return $share;
	}

	public function share_company_after_all_ins($sales_id,$amount,$date,$type,$payment,$mode)
	{
		$share = 0;
		if($this->get_share_product($sales_id))
		{
			foreach ($this->get_share_product($sales_id) as $key => $value) {
				
					$persent = $value['percent'];
					$commission = $amount * $persent / 100;
                    if($commission > 0){
					$share += $commission;
					$transaction = [
	                    'type'              =>  $type.'profit',
	                    'credit'            =>  $commission,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  $value['parterner'],
	                    'date'              =>  $date,
	                    'mode'              =>  $mode,
	                    'investment_id'     =>  $payment,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];
                    $this->db->insert('transaction', $transaction);
                    }
               		if($value['parterner'] != 0){
               			$inv = $this->users->business_detail($value['parterner'])[0];
               			$user = $this->users->get_user($value['parterner'])[0];
               			$balance = $this->all_model->business_balance($value['parterner']);
               			investor_installment_credit($inv['mobile'],$inv['fi_name'],$user['user_type_id'],$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);
               		}
				
			}
		}
		return $share;
	}

	public function profit_company($sales_id,$amount,$date)
	{
		
				
					
					$transaction = [
	                    'type'              =>  'profit',
	                    'credit'            =>  $amount,
	                    'debit'             =>  0, 
	                    'credit_by'         =>  0,
	                    'date'              =>  $date,
	                    'investment_id'     =>  $sales_id,
	                    'created_by'        =>  $this->session->userdata('id'),
	                    'created_at'        =>  date('Y-m-d H:i:s')
	                ];

               		$this->db->insert('transaction', $transaction);
				
	}



	

	public function get_share_product($sales)
	{
		$this->db->where('id',$sales);
		$query = $this->db->get('sell_product');
    	$product = $query->result_array()[0]['product_id'];

    	$this->db->where('product_id',$product);
    	$query = $this->db->get('share_parterner');
    	return $query->result_array();
	}

	public function get_partner()
	{
		$this->db->where('delete_flag','0');
		$this->db->where('key_persons','1');
		$this->db->where('user_type','business');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function get_percentage($user_id)
	{
		$this->db->where('user_id',$user_id);
		$query = $this->db->get('business_partners');
    	return $query->result_array()[0];
	}

	public function agent_id()
	{
				 $this->db->where('user_type_id',$this->session->userdata('user_type_id'));
		$query = $this->db->get('user');
    	return $query->result_array()[0]['id'];
	}

	public function promotion($column_name)
	{
				 $this->db->where('id','1');
				$percent = $this->db->get('agent_promotion');
    	return $percent->result_array()[0][$column_name];
	}

	public function promotion_agent($sales_id,$amount,$date,$type,$mode)
	{
		
		$promotion = 0;

			$user_data = $this->get_user($this->get_sale($sales_id)['created_by']);
		
		if($user_data['user_type'] == 'agent')
		{
			if($this->get_agent($user_data['user_type_id'])['promotion'] != 'none')
			{

				
		    	$column_name = $this->get_agent($this->session->userdata('user_type_id'))['promotion'];
		    	if($this->promotion($column_name) > 0){
					$commission = ($amount * floatval($this->promotion($column_name))) / 100;
					$transaction = [
			            'type'              =>  $type.'promotion',
			            'credit'            =>  $commission,
			            'debit'             =>  0, 
			            'credit_by'         =>  $this->get_sale($sales_id)['created_by'],
			            'date'              =>  $date,
			            'mode'              =>  $mode,
			            'investment_id'     =>  $sales_id,
			            'created_by'        =>  $this->session->userdata('id'),
			            'created_at'        =>  date('Y-m-d H:i:s')
			        ];

		            $this->db->insert('transaction', $transaction);
		            $promotion += $commission;
		        }
	        }
		}

		return $promotion;
	}

	public function promotion_agent_ins($sales_id,$amount,$date,$type,$payment_id,$mode)
	{
		
		$promotion = 0;

		$user_data = $this->get_user($this->get_sale($sales_id)['created_by']);
		
		if($user_data['user_type'] == 'agent')
		{

			if($this->get_agent($user_data['user_type_id'])['promotion'] != 'none')
			{

				
		    	$column_name = $this->get_agent($user_data['user_type_id'])['promotion'];
		    	if($this->promotion($column_name) > 0){
					$commission = ($amount * floatval($this->promotion($column_name))) / 100;
					if($$commission > 0) {
					$transaction = [
			            'type'              =>  $type.'promotion',
			            'credit'            =>  $commission,
			            'debit'             =>  0, 
			            'credit_by'         =>  $user_data['id'],
			            'date'              =>  $date,
			            'mode'              =>  $mode,
			            'investment_id'     =>  $payment_id,
			            'created_by'        =>  $this->session->userdata('id'),
			            'created_at'        =>  date('Y-m-d H:i:s')
			        ];

		            $this->db->insert('transaction', $transaction);
		            $promotion += $commission;
					}
		        }
	        }
		}

		return $promotion;
	}

	public function commission_agent($sales_id,$amount,$date,$type,$mode)
	{
		$remaining = 0;
		// if($this->session->userdata('user_type') == 'agent')
		// {
			$mainp 		= $this->get_agent_per($sales_id)['direct_agent']; 
			$parentp 	= $this->get_agent_per($sales_id)['parent_direct_agent']; 
			$otherp 	= $this->get_agent_per($sales_id)['other_parent']; 
			
			$commission = ($amount * $mainp) / 100;
			$transaction = [
							'type'           =>  $type.'direct_income',
							'credit'         =>  $commission,
							'debit'          =>  0, 
							'credit_by'      =>  $this->get_sale($sales_id)['created_by'],
							'date'           =>  $date,
							'mode'           =>  $mode,
							'investment_id'  =>  $sales_id,
							'created_by'     =>  $this->session->userdata('id'),
							'created_at'     =>  date('Y-m-d H:i:s')
						];


	        $agent = $this->users->agent_detail($this->get_sale($sales_id)['created_by'])[0];
	        $agent_id = $this->users->get_user($this->get_sale($sales_id)['created_by'])[0]['user_type_id'];
	        $balance = $this->all_model->agent_balance($this->get_sale($sales_id)['created_by']);
	        agent_direct_sale($agent['mobile'],$agent['fi_name'],$agent_id,$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);
            $this->db->insert('transaction', $transaction);
            $remaining += $commission;
            ///  parent 

            $user_data = $this->get_user($this->get_sale($sales_id)['created_by']);
            if(!empty($this->get_agent($user_data['user_type_id'])['parent']) && $this->get_agent($user_data['user_type_id'])['parent'] != 'ADMIN')
			{
	            if($this->parent_commission( $this->get_agent($user_data['user_type_id'])['parent'] ))
	            {

	            	$commission = ($amount * $parentp) / 100;
					$transaction = [
			            'type'              =>  $type.'indirect_income',
			            'credit'            =>  $commission,
			            'debit'             =>  0, 
			            'credit_by'         =>  $this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'],
			            'date'              =>  $date,
			            'mode'              =>  $mode,
			            'investment_id'     =>  $sales_id,
			            'created_by'        =>  $this->session->userdata('id'),
			            'created_at'        =>  date('Y-m-d H:i:s')
			        ];
			        $remaining += $commission;
		            $this->db->insert('transaction', $transaction);
		            $agent = $this->users->agent_detail($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'])[0];
			        $agent_id = $this->users->get_user($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'])[0]['user_type_id'];
			        $balance = $this->all_model->agent_balance($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id']);
			        agent_indirect_sale($agent['mobile'],$agent['fi_name'],$agent_id,$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);
	            }
	            /// other
            $after_parent = $this->get_agent($this->get_agent($user_data['user_type_id'])['parent'])['parent'];
           	
           	if($after_parent != 'ADMIN')
			{
            	$other_commision = $this->othe_commission($after_parent,$sales_id,$amount,$date,$type);	
           	}
           	else
			{
           		$other_commision = 0;
           	}
            $remaining += $other_commision;
            /// other
	        }
        ///  parent 
		//}
		return $remaining;
	}

	public function commission_agent_ins($sales_id,$amount,$date,$type,$payment_id,$mode)
	{
		$remaining = 0;

		$user_data = $this->get_user($this->get_sale($sales_id)['created_by']);

		if($user_data['user_type'] == 'agent')
		{
			$mainp = $this->get_agent_per($sales_id)['direct_agent']; 
			$parentp = $this->get_agent_per($sales_id)['parent_direct_agent']; 
			$otherp = $this->get_agent_per($sales_id)['other_parent']; 
			
			$commission = ($amount * $mainp) / 100;
		    if($commission > 0)
			{	
				$transaction = [
					'type'              =>  $type.'direct_income',
					'credit'            =>  $commission,
					'debit'             =>  0, 
					'credit_by'         =>  $user_data['id'],
					'date'              =>  $date,
					'mode'              =>  $mode,
					'investment_id'     =>  $payment_id,
					'created_by'        =>  $this->session->userdata('id'),
					'created_at'        =>  date('Y-m-d H:i:s')
				];
            $this->db->insert('transaction', $transaction);
			}
            $remaining += $commission;

            $agent = $this->users->agent_detail($user_data['id'])[0];
	        $agent_id = $this->users->get_user($user_data['id'])[0]['user_type_id'];
	        $balance = $this->all_model->agent_balance($user_data['id']);
	        //agent_direct_installment($agent['mobile'],$agent['fi_name'],$agent_id,$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);

            ///  parent 
            if(!empty($this->get_agent($user_data['user_type_id'])['parent']) && $this->get_agent($user_data['user_type_id'])['parent'] != 'ADMIN'){
	            if($this->parent_commission($this->get_agent($user_data['user_type_id'])['parent']))
	            {
	            	$commission = ($amount * $parentp) / 100;
					if($commission > 0)
			       {	
					$transaction = [
			            'type'              =>  $type.'indirect_income',
			            'credit'            =>  $commission,
			            'debit'             =>  0, 
			            'credit_by'         =>  $this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'],
			            'date'              =>  $date,
			            'mode'              =>  $mode,
			            'investment_id'     =>  $payment_id,
			            'created_by'        =>  $this->session->userdata('id'),
			            'created_at'        =>  date('Y-m-d H:i:s')
			        ];
			        $remaining += $commission;
		            $this->db->insert('transaction', $transaction);
				   }
		            $agent = $this->users->agent_detail($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'])[0];
			        $agent_id = $this->users->get_user($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id'])[0]['user_type_id'];
			        $balance = $this->all_model->agent_balance($this->is_agent($this->get_agent($user_data['user_type_id'])['parent'])['id']);
			        //agent_indirect_installment($agent['mobile'],$agent['fi_name'],$agent_id,$commission,date('d-m-y'),date('H:i'),$sales_id,$balance);
	            }

	            /// other
            
            $after_parent = $this->get_agent($this->get_agent($user_data['user_type_id'])['parent'])['parent'];
           	if($after_parent != 'ADMIN'){
            	$other_commision = $this->othe_commission_ins($after_parent,$sales_id,$amount,$date,$type,$payment_id);	
            }
           	else{
           		$other_commision = 0;
           	}
            $remaining += $other_commision;

            /// other
	            
	        }

            ///  parent 


            



		}

		return $remaining;
	}

	public function parent_commission($parent_agent)
	{
		
			
		if($this->get_agent($parent_agent)['active'] == '0')
		{

			if($this->get_twolags($parent_agent) >= 2)
			{

				return true;
			}
		}
				
	}

	public function is_agent($agent_id)
	{
		$this->db->where('user_type_id',$agent_id);
		$query = $this->db->get('user');
    	return $query->result_array()[0];
	}

	public function get_agent_per($sales_id)
	{
		$product_id = $this->get_sale($sales_id)['product_id'];
		$this->db->where('id',$product_id);
		$query = $this->db->get('create_product');
    	return $query->result_array()[0];
	} 

	public function get_sale($id)
	{

		$this->db->where('id',$id);
		$query = $this->db->get('sell_product');
    	return $query->result_array()[0];
    }



	public function othe_commission($agent,$sales_id,$amount,$date,$type)
	{
		$otherp 			= $this->get_agent_per($sales_id)['other_parent']; 
		$each_commission 	= 0;
		$array_ids 			= [];
		while($agent != '')
		{
			if($this->parent_commission($agent))
            {
            	$array_ids[] = $agent;
            	$agent = $this->get_agent($agent)['parent'];
            }
            else
            {
            	$agent = $this->get_agent($agent)['parent'];
            }
		}

		if(count($array_ids) > 0)
		{
			$each_commission 	= ($amount * $otherp) / 100;
			$each 				= $each_commission / floatval(count($array_ids));
			foreach ($array_ids as $key => $value) 
			{
				$transaction = [
		            'type'              =>  $type.'bonus_income',
		            'credit'            =>  $each,
		            'debit'             =>  0, 
		            'credit_by'         =>  $this->is_agent($value)['id'],
		            'date'              =>  $date,
		            'investment_id'     =>  $sales_id,
		            'created_by'        =>  $this->session->userdata('id'),
		            'created_at'        =>  date('Y-m-d H:i:s')
		        ];

	            $this->db->insert('transaction', $transaction);
			}
		}
		return $each_commission;
	}

	public function othe_commission_ins($agent,$sales_id,$amount,$date,$type,$payment_id)
	{
		$otherp = $this->get_agent_per($sales_id)['other_parent']; 
		
		$each_commission = 0;
		

		$array_ids = [];

		while($agent != '')
		{
			if($this->parent_commission($agent))
            {
            	$array_ids[] = $agent;
            	$agent = $this->get_agent($agent)['parent'];
            }
            else
            {
            	$agent = $this->get_agent($agent)['parent'];
            }
		}

		if(count($array_ids) > 0)
		{
			$each_commission = ($amount * $otherp) / 100;

			$each = $each_commission / floatval(count($array_ids));
			foreach ($array_ids as $key => $value) {
				$transaction = [
		            'type'              =>  $type.'bonus_income',
		            'credit'            =>  $each,
		            'debit'             =>  0, 
		            'credit_by'         =>  $this->is_agent($value)['id'],
		            'date'              =>  $date,
		            'investment_id'     =>  $payment_id,
		            'created_by'        =>  $this->session->userdata('id'),
		            'created_at'        =>  date('Y-m-d H:i:s')
		        ];

	            $this->db->insert('transaction', $transaction);
			}
		}
		return $each_commission;
	}

	public function get_agent($agent_id)
	{
		$this->db->where('agent_id',$agent_id);
		$query = $this->db->get('binary');
    	return $query->result_array()[0];
	}

	public function get_twolags($agent_id){
		$this->db->where('parent',$agent_id);
		$query = $this->db->get('binary');
    	return $query->num_rows();
	}

    public function get_customer_detail_using_agent_id($agent_id)
    {

        $this->db->where('created_by',$agent_id);
        $this->db->where('delete_flag','0');
        $this->db->select("*");
        $this->db->from('user');
        $this->db->join('customer_detail', 'user.id = customer_detail.user_id');
        
        $query = $this->db->get();

        
            return $query->result_array();
        

    }
}