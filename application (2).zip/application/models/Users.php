<?php
class Users extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
    
	/*****************************************/
	public function leg($agent_id)
	{
		$this->db->where('agent_id',$agent_id);
		$query = $this->db->get('binary');
		return $query->row_array();

	}
	
	public  function get_checked($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('user',$page)->result_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	
	public function all_agents_detail($array)
	{
        $ids = $array;
    	$this->db->where_in('user_id NOT', $ids);
	    $query = $this->db->get('agent_details');
    	return $query->result_array();
	}
	
	public function agent_pending_sell($month)
	{
		$today = strtotime(date('Y-m-d'));
		$subone = date("Y-m-d", strtotime("-".$month." month", $today));
        $this->db->order_by('date','ASC');
		$this->db->where('sell_status','0');
		$this->db->where('cancel','0');
		$this->db->where('date >=',$subone);
		$this->db->where('date <=',date('Y-m-d'));
		$this->db->group_by('created_by');
		return $this->db->get('sell_product')->result_array();
	}
	
	public function subadmin_detail_drop($id)
	{

				$this->db->where('user_type',$id);
				$this->db->where('delete_flag','0');
		$query = $this->db->get('user');
    	return $query->result_array();
	}
	
	public function agents_detail($id)
	{

				$this->db->where('user_id',$id);
		$query = $this->db->get('agent_details');
    	return $query->result_array();
	}




	public function get_withdraw()
	{
		
		$this->db->select('SQL_CALC_FOUND_ROWS withdraw_request.*,user.user_type_id',FALSE);
		//$this->db->where("tbl_complaints.status!=","1");
		$this->db->from('withdraw_request');
		$this->db->join('user','user.id = withdraw_request.created_by','left');
		$query=$this->db->get();
		return $query->result_array();	
	}
	
	public function get_withdrawall($id)
	{
		
		$this->db->select('SQL_CALC_FOUND_ROWS withdraw_request.*,user.user_type_id',FALSE);
		$this->db->where("withdraw_request.created_by=",$id);
		//$this->db->where("withdraw_request.status!=","1");
		$this->db->from('withdraw_request');
		$this->db->join('user','user.id = withdraw_request.created_by','left');
		$query=$this->db->get();
		return $query->result_array();	
	}


	/*****************************************/



	public function all_agents($user_type,$delete_flag=0)
	{
		$this->db->order_by("id","desc");
		if($this->session->userdata('user_type') == 'agent')
		{
			$this->db->where('created_by',$this->session->userdata('id'));
		}
		 $this->db->where('id !=','1');
		if($delete_flag==0)
		{
		 $this->db->where('delete_flag','0');
		}
		else
		{
			$this->db->where('delete_flag!=',$delete_flag);
		}
		$this->db->where('user_type',$user_type);
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function _all_agents($user_type)
	{
		$this->db->order_by("id","desc");
		if($this->session->userdata('user_type') == 'agent')
		{
			$this->db->where('created_by',$this->session->userdata('id'));
		}
		$this->db->where('id !=','1');
		$this->db->where('delete_flag','0');
		$this->db->where('key_persons','0');
		$this->db->where('user_type',$user_type);
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function get_user($id)
	{
		$this->db->where('id',$id);
		//$this->db->order_by("name", "asc");
		$query = $this->db->get('user');
		return $query->result_array();
    	//$data= $query->result_array();
		//echo"<pre>"; print_r($data); die;
	}
	
	public function get_user_details($id)
	{
		$this->db->where('user_type_id',$id);
		$query = $this->db->get('user');
		return $query->result_array();
	}

	public function get_user_by_ref($id)
	{
		$this->db->where('user_type_id',$id);
		$query = $this->db->get('user');
    	return $query->result_array()[0];
	}

	public function get_user_with_type($id,$type)
	{

				$this->db->where('id',$id);
				$this->db->where('user_type',$type);
				$this->db->where('delete_flag','0');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	

	public function get_agent($id)
	{
		$this->db->where('id',$id);
		$this->db->where('user_type','agent');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function agent_detail($id)
	{
		$this->db->where('user_id',$id);
		$query = $this->db->get('agent_details');
    	return $query->result_array();
	}

	public function active_agent($id)
	{
		$this->db->where('agent_id',$id);
		$query = $this->db->get('binary');
    	return $query->result_array();
	}
    

     public function get_users()
	{
		return $this->db->get_where('user',['delete_flag' => '0'])->result_array();
	}

	public  function get_usered($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{			
			$result =  $this->db->get_where('create_product',$page)->result_array();
			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}	
	}


	/*//////////////////////////////////////////////////////////////////////////////////////
								STRAT SUBADMIN
	//////////////////////////////////////////////////////////////////////////////////////*/
	
	public function subadmin_detail($id)
	{

				$this->db->where('user_id',$id);
		$query = $this->db->get('subadmin_details');
    	return $query->result_array();
	}

	public function employee_detail($id)
	{

				$this->db->where('user_id',$id);
		$query = $this->db->get('employee_details');
    	return $query->result_array();
	}

	/*//////////////////////////////////////////////////////////////////////////////////////
								START BUSINESS PARTNER
	//////////////////////////////////////////////////////////////////////////////////////*/
	
	// USE Business Partner Share
	public function business_detail($id)
	{

				$this->db->where('user_id',$id);
		$query = $this->db->get('business_partners');
    	return $query->result_array();
	}

	// USE Business Partner Share
	public function all_business()
	{
				$this->db->where('id !=','1');
				$this->db->where('key_persons','0');
				$this->db->where('delete_flag','0');
				$this->db->where('user_type','business');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	// USE Business Partner Share
	public function all_business_user_type($id)
	{
				$this->db->where('id',$id);
		$query = $this->db->get('user');
    	return $query->result_array();
	}
	

	public function business_partner()
	{
				$this->db->order_by('id','ASC');
				$this->db->where('user_type','business');
				$this->db->where('delete_flag','0');
				$this->db->where('key_persons','0');
		$query = $this->db->get('user');
    	return $query->result_array();
	}
	/*//////////////////////////////////////////////////////////////////////////////////////
								START COUSTMER
	//////////////////////////////////////////////////////////////////////////////////////*/
	
	public function customer_detail($id)
	{
				$this->db->where('user_id',$id);
		$query = $this->db->get('customer_detail');
    	return $query->result_array();
	}


	public function get_customer_id($id)
	{

				//$this->db->where('user_type_id',$id);
				$this->db->where('delete_flag','0');
				$this->db->where('user_type_id',$id);
				$this->db->where('user_type','customer');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

	public function get_agent_id($id)
	{

				$this->db->where('user_type_id',$id);
				$this->db->where('delete_flag','0');
				//$this->db->where('user_type_id',$id);
				$this->db->where('user_type','agent');
		$query = $this->db->get('user');
    	return $query->result_array();
	}
	

	/*//////////////////////////////////////////////////////////////////////////////////////
								KEY PERSONS
	//////////////////////////////////////////////////////////////////////////////////////*/

	public function key_persons()
	{
				$this->db->where('id !=','1');
				$this->db->where('delete_flag','0');
				$this->db->where('user_type','business');
				$this->db->where('key_persons','1');
		$query = $this->db->get('user');
    	return $query->result_array();
	}
	
	
	public function get_master($page=array())
	{		
		if( is_array($page) && !empty($page) )
		{
			$result =  $this->db->get_where('masterpass',$page)->row_array();

			if( is_array($result) && !empty($result) )
			{
				return $result;
			}
		}
	}
	public function get_key_persons($id)
	{

				$this->db->where('id',$id);
				$this->db->where('id !=','1');
				$this->db->where('delete_flag','0');
				$this->db->where('user_type','business');
				$this->db->where('key_persons','1');
		$query = $this->db->get('user');
    	return $query->result_array();
	}

}